import * as i0 from '@angular/core';
import { InjectionToken, Injectable, inject, Component, EventEmitter, Output, Input, ApplicationRef, createComponent, ViewChild, Pipe } from '@angular/core';
import Feature from 'ol/Feature';
import WKT from 'ol/format/WKT';
import { Geometry, Point, LineString as LineString$1, Polygon as Polygon$1, MultiPoint } from 'ol/geom';
import { defaults as defaults$1, ScaleLine } from 'ol/control';
import { defaults, Snap, Interaction, Modify, Translate, Select } from 'ol/interaction';
import VectorLayer from 'ol/layer/Vector';
import OlMap from 'ol/Map';
import { addProjection, get, transform } from 'ol/proj';
import Projection from 'ol/proj/Projection';
import VectorSource from 'ol/source/Vector';
import CircleStyle from 'ol/style/Circle';
import Fill from 'ol/style/Fill';
import Stroke from 'ol/style/Stroke';
import Style, { createEditingStyle, createDefaultStyle } from 'ol/style/Style';
import View from 'ol/View';
import { unByKey } from 'ol/Observable';
import { BehaviorSubject, Subject, ReplaySubject, firstValueFrom, noop, throwError, forkJoin } from 'rxjs';
import { distinctUntilChanged, filter, map, shareReplay, switchMap, catchError } from 'rxjs/operators';
import { ObservableMapWrapper, DEFAULT_MAPINDEX, MapComponentEvent as MapComponentEvent$1, MapComponentEventTypes as MapComponentEventTypes$1, LayerChangedEventTrigger, MapComponentDrawTypes, GGC_FEATURE_LAYERID, FeatureCollectionForCoordinate as FeatureCollectionForCoordinate$1, Webservice2DType, MapViewState as MapViewState$1 } from '@kadaster/ggc-models';
import { GeoJSON, MVT, WMTSCapabilities, WMSCapabilities } from 'ol/format';
import { Collection } from 'ol';
import { never, singleClick } from 'ol/events/condition';
import Draw, { DrawEvent, createBox } from 'ol/interaction/Draw';
import LineString from 'ol/geom/LineString';
import Polygon from 'ol/geom/Polygon';
import { Text, Icon, Style as Style$1, Fill as Fill$1 } from 'ol/style';
import { unlistenByKey, listen } from 'ol/events';
import GeoJSON$1 from 'ol/format/GeoJSON';
import Cluster from 'ol/source/Cluster';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import ImageLayer from 'ol/layer/Image';
import { ImageStatic, TileWMS } from 'ol/source';
import { applyStyle } from 'ol-mapbox-style';
import { getTopLeft } from 'ol/extent';
import VectorTileLayer from 'ol/layer/VectorTile';
import VectorTileSource from 'ol/source/VectorTile';
import TileGrid from 'ol/tilegrid/TileGrid';
import TileLayer from 'ol/layer/Tile';
import WMTS, { optionsFromCapabilities } from 'ol/source/WMTS';
import ImageWMS from 'ol/source/ImageWMS';
import { DEVICE_PIXEL_RATIO } from 'ol/has';
import WMTSTileGrid from 'ol/tilegrid/WMTS';
import { __decorate } from 'tslib';
import MousePosition from 'ol/control/MousePosition';

/**
 * InjectionToken voor optionele configuratie van de OpenLayers zoomcontrol.
 *
 * Kan worden gebruikt om standaard zoomopties te overschrijven bij
 * het initialiseren van de kaart.
 *
 * @see Options
 */
const ZOOM_OPTIONS = new InjectionToken("ZOOM_OPTIONS");
/**
 * InjectionToken voor optionele configuratie van de OpenLayers rotatecontrol.
 *
 * Hiermee kunnen instellingen zoals zichtbaarheid en gedrag van
 * de rotatieknop worden aangepast.
 *
 * @see Options
 */
const ROTATE_OPTIONS = new InjectionToken("ROTATE_OPTIONS");
/**
 * InjectionToken voor optionele configuratie van de OpenLayers attributioncontrol.
 *
 * Wordt gebruikt om attributie-instellingen (zoals collapsible of custom labels)
 * te configureren.
 *
 * @see Options
 */
const ATTRIBUTION_OPTIONS = new InjectionToken("ATTRIBUTION_OPTIONS");

/**
 * Geldige extent (bounding box) voor het RD New
 * coördinatenreferentiesysteem (EPSG:28992).
 *
 * Wordt gebruikt om de kaart- en tegelgrenzen te bepalen.
 */
const extent = [-285401.92, 22598.08, 595401.92, 903401.92];
/**
 * Resoluties per zoomniveau voor EPSG:28992.
 *
 * De index in deze array komt overeen met het zoomniveau.
 */
const resolutions = [
    3440.64, 1720.32, 860.16, 430.08, 215.04, 107.52, 53.76, 26.88, 13.44, 6.72,
    3.36, 1.68, 0.84, 0.42, 0.21, 0.105, 0.0525, 0.02625, 0.013125, 0.0065625,
    0.00328125, 0.001640625, 0.000820313, 0.000410156, 0.000205078, 0.000102539
];
/**
 * Matrixgroottes per zoomniveau voor tiles in EPSG:28992.
 *
 * Elke waarde vertegenwoordigt het aantal tegels
 * per richting (x en y) op dat zoomniveau.
 */
const matrixSizes = [
    1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768,
    65536, 131072, 262144, 524288, 1048576, 2097152, 4194304, 8388608, 16777216,
    33554432
];
/**
 * EPSG-code voor het RD New coördinatenreferentiesysteem.
 */
const epsg28992 = "EPSG:28992";
/**
 * Matrix-identifiers per zoomniveau.
 *
 * De identifiers zijn opgebouwd uit de EPSG-code en het bijbehorende zoomniveau.
 */
const matrixIds = resolutions.map((_, i) => `${epsg28992}:${i}`);
/**
 * Zet een resolutie voor EPSG:28992 om naar een zoomniveau.
 *
 * @param resolution resolutie voor EPSG:28992
 * @returns Zoomniveau behorend bij het resolutie
 */
function resolutionToZoomlevel(resolution) {
    return Math.log2(3440.64 / resolution);
}
/**
 * Zet een zoomniveau om naar een resolutie voor EPSG:28992.
 *
 * @param zoomlevel Zoomniveau
 * @returns Resolutie behorend bij het zoomniveau
 */
function zoomlevelToResolution(zoomlevel) {
    return 3440.64 / Math.pow(2, zoomlevel);
}
/**
 * Zet een kaartschaal om naar een resolutie.
 *
 * Gebaseerd op de standaard pixelgrootte van
 * 0.28 mm per pixel (diagonaal).
 *
 * @param scale Kaartschaal
 * @returns Resolutie
 */
function scaleToResolution(scale) {
    return scale * 0.00028;
}

/**
 * Service die configuratie levert voor het RD New
 * coördinatenreferentiesysteem (EPSG:28992).
 *
 * Deze service bouwt en cachet een {@link CrsConfig} die wordt gebruikt
 * voor kaartprojectie, resoluties en WMTS-matrixinstellingen.
 */
class GgcCrsConfigService {
    /**
     * Maximale ondersteunde zoomlevel voor RD New.
     */
    static { this.MAX_ZOOMLEVEL = 25; }
    /**
     * Geeft de configuratie voor het RD New coördinatenreferentiesysteem (EPSG:28992).
     *
     * De configuratie wordt lazy geïnitialiseerd en hergebruikt bij volgende aanroepen.
     *
     * @returns {@link CrsConfig} voor RD New
     */
    getRdNewCrsConfig() {
        if (this.rdNewCrsConfig === undefined) {
            this.rdNewCrsConfig = {
                projectionCode: epsg28992,
                extent,
                resolutions,
                matrixSet: epsg28992,
                matrixIds,
                matrixSizes,
                units: "m"
            };
        }
        return this.rdNewCrsConfig;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCrsConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCrsConfigService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCrsConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class CoreLoadingService {
    constructor() {
        this.eventsMap = new Map();
        this.loadCounter = new Map();
        this.loadStatesMap = new ObservableMapWrapper(() => new BehaviorSubject(false));
    }
    addMapLoaders(mapIndex, map) {
        const loadstart = map.on("loadstart", () => {
            this.loadStatesMap.getOrCreateSubject(mapIndex).next(true);
        });
        const loadend = map.on("loadend", () => {
            this.loadStatesMap.getOrCreateSubject(mapIndex).next(false);
        });
        this.eventsMap.set(mapIndex, [loadstart, loadend]);
    }
    removeMapLoaders(mapIndex) {
        const events = this.eventsMap.get(mapIndex);
        if (events) {
            events.forEach((key) => unByKey(key));
        }
    }
    destroyLoadersForMap(mapIndex) {
        this.loadCounter.delete(mapIndex);
        this.loadStatesMap.delete(mapIndex);
    }
    isLoading(mapIndex) {
        return this.loadStatesMap
            .getOrCreateObservable(mapIndex)
            .pipe(distinctUntilChanged());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreLoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreLoadingService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreLoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class CoreMapService {
    constructor() {
        this.GEOLOCATION_LAYER_ID = "geolocation";
        this.crsConfigService = inject(GgcCrsConfigService);
        this.coreLoadingService = inject(CoreLoadingService);
        this.zoomOptions = inject(ZOOM_OPTIONS, {
            optional: true
        });
        this.rotateOptions = inject(ROTATE_OPTIONS, { optional: true });
        this.attributionOptions = inject(ATTRIBUTION_OPTIONS, { optional: true });
        this.olMaps = new Map();
        this.extraLayers = ["selection", "highlight"];
        this.extraLayersMap = new Map();
        this.layerChangedSubject = new Subject();
        this.rdNewConfig = this.crsConfigService.getRdNewCrsConfig();
        this.rdNewProjection = new Projection({
            code: this.rdNewConfig.projectionCode,
            extent: this.rdNewConfig.extent,
            units: this.rdNewConfig.units,
            // workaround for showing correct scale in scaleLineComponent
            // https://github.com/openlayers/openlayers/issues/7309#issuecomment-343433613
            getPointResolution(resolution) {
                return resolution;
            }
        });
        addProjection(this.rdNewProjection);
    }
    getLayerChangedObservable() {
        return this.layerChangedSubject.asObservable();
    }
    emitLayerChangedEvent(layerId, mapIndex, eventTrigger) {
        this.layerChangedSubject.next({ layerId, mapIndex, eventTrigger });
    }
    createAndGetMap(mapIndex, minZoomLevel = 0, maxZoomLevel = 14) {
        // this method create a map and sets number of resolutions,
        // should only be called once from map.component.ts
        mapIndex = mapIndex ?? DEFAULT_MAPINDEX;
        if (!this.olMaps.has(mapIndex)) {
            // create a new map and drawlayer for this map
            const newMap = this.createNewOlMap(mapIndex);
            this.olMaps.set(mapIndex, newMap);
        }
        const map = this.olMaps.get(mapIndex);
        map.setView(new View({
            projection: this.rdNewProjection,
            resolutions: this.rdNewConfig.resolutions.slice(0, maxZoomLevel + 1),
            center: [160000, 455000]
        }));
        // call setMinZoom after the view is created, because according to the documentation minZoom is ignored
        // if resolutions is set in ViewOptions
        // see: https://openlayers.org/en/latest/apidoc/module-ol_View-View.html
        map.getView().setMinZoom(Math.floor(minZoomLevel));
        this.coreLoadingService.addMapLoaders(mapIndex, map);
        this.createExtraLayers(mapIndex);
        return map;
    }
    createLayerAndAddToMap(mapIndex, style) {
        const vectorSource = new VectorSource();
        const vectorLayer = new VectorLayer({
            source: vectorSource,
            style
        });
        // add layer as an un-managed layer, the un-managed layer will always be on top.
        // https://openlayers.org/en/v5.3.0/apidoc/module-ol_layer_Layer-Layer.html#setMap
        const map = this.getMap(mapIndex);
        vectorLayer.setMap(map);
        return vectorLayer;
    }
    getMap(mapIndex) {
        mapIndex = mapIndex ?? DEFAULT_MAPINDEX;
        if (!this.olMaps.has(mapIndex)) {
            this.olMaps.set(mapIndex, this.createNewOlMap(mapIndex));
        }
        return this.olMaps.get(mapIndex);
    }
    getLayer(layerId, mapIndex = DEFAULT_MAPINDEX) {
        const map = this.getMap(mapIndex);
        return map
            .getLayers()
            .getArray()
            .find((layer) => layer.get("ggc-layer-id") === layerId);
    }
    getExtraLayer(layer, mapIndex = DEFAULT_MAPINDEX) {
        let extraLayer = this.extraLayersMap.get(`${mapIndex}-${layer}`);
        if (!extraLayer && layer === this.GEOLOCATION_LAYER_ID) {
            extraLayer = this.createGeolocationLayer(mapIndex);
        }
        return extraLayer;
    }
    checkMapIndex(mapIndex = DEFAULT_MAPINDEX) {
        mapIndex = mapIndex ?? DEFAULT_MAPINDEX;
        return this.olMaps.has(mapIndex);
    }
    destroyMap(mapIndex) {
        this.olMaps.delete(mapIndex);
        this.extraLayers.forEach((layer) => {
            this.extraLayersMap.delete(`${mapIndex}-${layer}`);
        });
        this.coreLoadingService.removeMapLoaders(mapIndex);
    }
    decideMapComponentEventType(mapExists, mapIndex) {
        mapIndex = mapIndex ?? DEFAULT_MAPINDEX;
        if (mapExists) {
            return new MapComponentEvent$1(MapComponentEventTypes$1.SUCCESSFUL, mapIndex, "Methode succesvol uitgevoerd");
        }
        return new MapComponentEvent$1(MapComponentEventTypes$1.UNSUCCESSFUL, mapIndex, `Mapindex bestaat niet voor index: ${mapIndex}`);
    }
    addFeaturesToHighlightLayer(features, mapIndex) {
        if (this.checkMapIndex(mapIndex)) {
            // We know for sure that the selectionLayer exists; checkMapIndex indirectly checks this
            const highlightLayerSource = this.getHighlightLayerSource(mapIndex);
            highlightLayerSource.addFeatures(features);
            return this.decideMapComponentEventType(true, mapIndex);
        }
        return this.decideMapComponentEventType(false, mapIndex);
    }
    clearHighlightLayer(mapIndex) {
        if (this.checkMapIndex(mapIndex)) {
            const highlightLayerSource = this.getHighlightLayerSource(mapIndex);
            if (highlightLayerSource) {
                highlightLayerSource.clear();
            }
            return this.decideMapComponentEventType(true, mapIndex);
        }
        return this.decideMapComponentEventType(false, mapIndex);
    }
    changeHighlightLayerStyle(styleLike, mapIndex) {
        this.changeLayerStyle(styleLike, mapIndex, "highlight");
    }
    addFeaturesToSelectionLayer(features, mapIndex, selectIndex) {
        if (this.checkMapIndex(mapIndex)) {
            const source = this.getSelectionLayerSource(mapIndex, selectIndex);
            source?.addFeatures(features);
            return this.decideMapComponentEventType(true, mapIndex);
        }
        return this.decideMapComponentEventType(false, mapIndex);
    }
    /**
     * Controleert of een feature aanwezig is in de selectionlaag.
     *
     * Een feature wordt als aanwezig beschouwd wanneer:
     * - dezelfde feature‑referentie voorkomt in de selectionlaag, of
     * - een feature met hetzelfde id voorkomt in de selectionlaag
     *
     * @param feature OpenLayers feature die gecontroleerd wordt
     * @param mapIndex Index van de kaart (default: DEFAULT_MAPINDEX)
     * @param selectIndex Optionele index van de selectie
     * @returns `true` indien de feature in de selectionlaag zit, anders `false`
     */
    isFeatureInSelectionLayer(feature, mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        if (!this.checkMapIndex(mapIndex)) {
            return false;
        }
        const source = this.getSelectionLayerSource(mapIndex, selectIndex);
        if (!source) {
            return false;
        }
        const featureId = feature.getId();
        return source.getFeatures().some((selectionFeature) => {
            if (selectionFeature === feature) {
                return true;
            }
            if (featureId !== undefined) {
                return selectionFeature.getId() === featureId;
            }
            if (feature.values_?.id &&
                selectionFeature.values_?.id) {
                return (feature.values_?.id == selectionFeature.values_?.id);
            }
            return false;
        });
    }
    clearSelectionLayer(mapIndex, selectIndex) {
        if (this.checkMapIndex(mapIndex)) {
            if (selectIndex) {
                const key = `${mapIndex}-${selectIndex}-selection`;
                const layer = this.extraLayersMap.get(key);
                layer?.getSource()?.clear();
            }
            else {
                this.getSelectionLayerSource(mapIndex)?.clear();
            }
            return this.decideMapComponentEventType(true, mapIndex);
        }
        return this.decideMapComponentEventType(false, mapIndex);
    }
    changeSelectionLayerStyle(styleLike, mapIndex, selectIndex) {
        this.changeLayerStyle(styleLike, mapIndex, "selection", selectIndex);
    }
    changeLayerStyle(styleLike, mapIndex, layername, selectIndex) {
        const layer = selectIndex
            ? this.extraLayersMap.get(`${mapIndex}-${selectIndex}-${layername}`)
            : this.extraLayersMap.get(`${mapIndex}-${layername}`);
        layer?.setStyle(styleLike);
    }
    setExtraLayers(layers) {
        this.extraLayers = [...this.extraLayers, ...layers];
    }
    createGeolocationLayer(mapIndex) {
        const layer = this.createLayerAndAddToMap(mapIndex, new Style());
        this.extraLayers.push(this.GEOLOCATION_LAYER_ID);
        this.extraLayersMap.set(`${mapIndex}-${this.GEOLOCATION_LAYER_ID}`, layer);
        return layer;
    }
    createNewOlMap(mapIndex) {
        const newMap = new OlMap({
            controls: this.getControls(),
            interactions: defaults({
                // Is always set to false because of the interaction with the tabindex if it's provided.
                // If no tabindex is provided, it does nothing.
                onFocusOnly: false
            }),
            layers: [],
            view: new View({
                projection: this.rdNewProjection
            })
        });
        newMap.getLayers().on("add", (event) => {
            this.layerChangedSubject.next({
                layerId: event.element.get("ggc-layer-id"),
                mapIndex,
                eventTrigger: LayerChangedEventTrigger.LAYER_ADDED
            });
        });
        return newMap;
    }
    addSelectLayer(mapIndex, selectIndex) {
        const key = `${mapIndex}-${selectIndex}-selection`;
        const layer = this.createLayerAndAddToMap(mapIndex);
        this.readdHighlightLayer(mapIndex);
        this.setDefaultSelectionLayerStyle(mapIndex, selectIndex);
        this.extraLayersMap.set(key, layer);
    }
    removeSelectLayer(mapIndex, selectIndex) {
        const key = `${mapIndex}-${selectIndex}-selection`;
        this.extraLayersMap.delete(key);
    }
    readdHighlightLayer(mapIndex) {
        const highlightLayer = this.extraLayersMap.get(`${mapIndex}-highlight`);
        const map = this.getMap(mapIndex);
        if (highlightLayer && map) {
            highlightLayer.setMap(null);
            highlightLayer.setMap(map);
        }
    }
    getControls() {
        const zoomOptions = this.zoomOptions || undefined;
        const rotateOptions = this.rotateOptions || undefined;
        const attributionOptions = this.attributionOptions || undefined;
        if (zoomOptions?.zoomInLabel instanceof HTMLElement) {
            zoomOptions.zoomInLabel = this.clone(zoomOptions.zoomInLabel);
        }
        if (zoomOptions?.zoomOutLabel instanceof HTMLElement) {
            zoomOptions.zoomOutLabel = this.clone(zoomOptions.zoomOutLabel);
        }
        if (rotateOptions?.label instanceof HTMLElement) {
            rotateOptions.label = this.clone(rotateOptions.label);
        }
        if (attributionOptions?.label instanceof HTMLElement) {
            attributionOptions.label = this.clone(attributionOptions.label);
        }
        if (attributionOptions?.collapseLabel instanceof HTMLElement) {
            attributionOptions.collapseLabel = this.clone(attributionOptions.collapseLabel);
        }
        return defaults$1({ rotateOptions, zoomOptions, attributionOptions });
    }
    clone(element) {
        return element.cloneNode(true);
    }
    getHighlightLayerSource(mapIndex) {
        return this.extraLayersMap.get(`${mapIndex}-highlight`)?.getSource();
    }
    getSelectionLayerSource(mapIndex, selectIndex) {
        return selectIndex
            ? this.extraLayersMap
                .get(`${mapIndex}-${selectIndex}-selection`)
                ?.getSource()
            : this.extraLayersMap.get(`${mapIndex}-selection`)?.getSource();
    }
    createExtraLayers(mapIndex) {
        // Order in which the selection- and highlightlayer are created is important!
        // The selection layer should be added to the map before the highlight layer is added.
        this.extraLayers.forEach((layername) => {
            const layer = this.createLayerAndAddToMap(mapIndex, new Style());
            this.extraLayersMap.set(`${mapIndex}-${layername}`, layer);
        });
        this.setDefaultHighlightLayerStyle(mapIndex);
        this.setDefaultSelectionLayerStyle(mapIndex);
    }
    setDefaultHighlightLayerStyle(mapIndex) {
        const highlightStyle = new Style({
            fill: new Fill({
                color: "rgba(0, 115, 149, 0.5)"
            }),
            stroke: new Stroke({
                color: "#007395",
                width: 5
            }),
            image: new CircleStyle({
                radius: 7,
                fill: new Fill({
                    color: "rgba(0, 115, 149, 0.5)"
                }),
                stroke: new Stroke({
                    color: "#007395",
                    width: 5
                })
            })
        });
        const layer = this.extraLayersMap.get(`${mapIndex}-highlight`);
        layer?.setStyle(highlightStyle);
    }
    setDefaultSelectionLayerStyle(mapIndex, selectIndex) {
        const fill = new Fill({
            color: "rgba(255,255,255,0.5)"
        });
        const stroke = new Stroke({
            color: "#0093be",
            width: 4
        });
        const selectionStyle = new Style({
            fill,
            stroke,
            image: new CircleStyle({
                fill,
                stroke,
                radius: 5
            })
        });
        const layer = selectIndex
            ? this.extraLayersMap.get(`${mapIndex}-${selectIndex}-selection`)
            : this.extraLayersMap.get(`${mapIndex}-selection`);
        layer?.setStyle(selectionStyle);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }], ctorParameters: () => [] });

/**
 * Ondersteunde formaten voor het aanleveren van geometrieën.
 *
 * Wordt gebruikt om te bepalen hoe string-geometrieën
 * geïnterpreteerd en geparsed moeten worden.
 */
var FormatType;
(function (FormatType) {
    /** Well-Known Text (WKT) formaat */
    FormatType[FormatType["WKT"] = 0] = "WKT";
    /** GeoJSON formaat */
    FormatType[FormatType["GEOJSON"] = 1] = "GEOJSON";
})(FormatType || (FormatType = {}));

/**
 * Service die kaartfunctionaliteit aanbiedt voor:
 *
 * - Opvragen van kaarten en lagen
 * - Zoomen naar coördinaten, geometrieën en extensies
 * - Highlight- en selection-lagen beheren
 * - Interactie met (PDOK) zoekresultaten
 *
 * Deze service abstraheert OpenLayers-details en zorgt voor consistente
 * {@link MapComponentEvent}-afhandeling.
 */
class GgcMapService {
    constructor() {
        this.coreMapService = inject(CoreMapService);
    }
    /**
     * Geeft een observable die notificaties uitstuurt wanneer lagen wijzigen.
     *
     * @returns Observable met {@link LayerChangedEvent}
     */
    getLayerChangedObservable() {
        return this.coreMapService.getLayerChangedObservable();
    }
    /**
     * Haalt een OpenLayers map op, op basis van mapIndex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns OpenLayers {@link OlMap}
     */
    getMap(mapIndex) {
        return this.coreMapService.getMap(mapIndex);
    }
    /**
     * Haalt een kaartlaag op, op basis van layerID en mapIndex.
     *
     * @param layerId Unieke laag-id
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns De kaartlaag of `undefined` indien niet gevonden
     */
    getLayer(layerId, mapIndex = DEFAULT_MAPINDEX) {
        return this.coreMapService.getLayer(layerId, mapIndex);
    }
    /**
     * Haalt een extra vectorlaag op (bijvoorbeeld highlight- of selectionlaag),
     * op basis van een layerName en mapIndex.
     *
     * @param layer Naam van de extra laag
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns VectorLayer of `undefined`
     */
    getExtraLayer(layer, mapIndex = DEFAULT_MAPINDEX) {
        return this.coreMapService.getExtraLayer(layer, mapIndex);
    }
    /**
     * Bepaalt de hoogste z-index van zichtbare lagen binnen een kaart.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns Hoogste z-index
     */
    getMaxZIndex(mapIndex) {
        let maxZIndex = Number.MIN_SAFE_INTEGER;
        for (const layer of this.getMap(mapIndex).getAllLayers()) {
            if (layer.getVisible()) {
                const zIndex = layer.getZIndex() ?? 0;
                if (zIndex > maxZIndex) {
                    maxZIndex = zIndex;
                }
            }
        }
        return maxZIndex;
    }
    /**
     * Zoomt de kaart naar een specifieke coördinaat.
     * Wacht indien nodig tot de kaart volledig is gerenderd.
     *
     * @param coord Doelcoördinaat
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param maxZoom Optioneel maximum zoomniveau
     * @returns Promise met {@link MapComponentEvent}
     */
    zoomToCoordinate(coord, mapIndex = DEFAULT_MAPINDEX, maxZoom) {
        return new Promise((resolve) => {
            if (this.coreMapService.checkMapIndex(mapIndex)) {
                const map = this.coreMapService.getMap(mapIndex);
                const zoom = () => {
                    map.getView().fit([...coord, ...coord], { maxZoom });
                    resolve(this.coreMapService.decideMapComponentEventType(true, mapIndex));
                };
                if (map.isRendered()) {
                    zoom();
                }
                else {
                    map.once("loadend", () => {
                        zoom();
                    });
                }
            }
            resolve(this.coreMapService.decideMapComponentEventType(false, mapIndex));
        });
    }
    /**
     * Zoomt naar een geometrie met uitgebreide zoomopties.
     *
     * @param geometry Geometrie als WKT, GeoJSON of OpenLayers Geometry
     * @param zoomOptions Opties voor mapIndex en fit
     * @param formatType Formaat van string-geometrie
     * @returns {@link MapComponentEvent}
     */
    zoomToGeometryWithZoomOptions(geometry, zoomOptions, formatType = FormatType.WKT) {
        const mapIndex = zoomOptions?.mapIndex;
        if (this.coreMapService.checkMapIndex(mapIndex)) {
            const geom = geometry instanceof Geometry
                ? geometry
                : this.transformStringToGeometry(geometry, formatType);
            const extent = geom.getExtent();
            this.coreMapService
                .getMap(mapIndex)
                .getView()
                .fit(extent, zoomOptions?.fitOptions);
            return this.coreMapService.decideMapComponentEventType(true, mapIndex);
        }
        return this.coreMapService.decideMapComponentEventType(false, mapIndex);
    }
    /**
     * Zoomt naar een gegeven bounding box (extent).
     *
     * @param bbox Extent in kaartprojectie
     * @param zoomOptions Optioneel Zoom- en fitopties
     * @returns {@link MapComponentEvent}
     */
    zoomToExtent(bbox, zoomOptions) {
        const mapIndex = zoomOptions?.mapIndex ?? DEFAULT_MAPINDEX;
        if (this.coreMapService.checkMapIndex(mapIndex)) {
            this.coreMapService
                .getMap(mapIndex)
                .getView()
                .fit(bbox, zoomOptions?.fitOptions);
            return this.coreMapService.decideMapComponentEventType(true, mapIndex);
        }
        return this.coreMapService.decideMapComponentEventType(false, mapIndex);
    }
    /**
     * Markeert een geometrie op de highlightlaag.
     * Bestaande markeringen worden eerst verwijderd.
     *
     * @param geometry Geometrie als string of OpenLayers Geometry
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param formatType Formaat van de string-geometrie (enum FormatType)
     * @returns {@link MapComponentEvent}
     */
    markFeature(geometry, mapIndex = DEFAULT_MAPINDEX, formatType = FormatType.WKT) {
        if (this.coreMapService.checkMapIndex(mapIndex)) {
            const geom = geometry instanceof Geometry
                ? geometry
                : this.transformStringToGeometry(geometry, formatType);
            this.clearHighlightLayer(mapIndex);
            this.addFeaturesToHighlightLayer([new Feature({ geometry: geom })], mapIndex);
            return this.coreMapService.decideMapComponentEventType(true, mapIndex);
        }
        return this.coreMapService.decideMapComponentEventType(false, mapIndex);
    }
    /**
     * Voegt één of meerdere features toe aan de highlightlaag.
     * De features worden zichtbaar gemaakt met de huidige highlightstijl.
     *
     * @param features Array van OpenLayers features met geometrie
     * @param mapIndex Index van de kaart waarop de features worden
     * toegevoegd (default: DEFAULT_MAPINDEX)
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    addFeaturesToHighlightLayer(features, mapIndex = DEFAULT_MAPINDEX) {
        return this.coreMapService.addFeaturesToHighlightLayer(features, mapIndex);
    }
    /**
     * Verwijdert alle features uit de highlightlaag.
     *
     * @param mapIndex Index van de kaart waarvoor de highlightlaag wordt
     * geleegd (default: DEFAULT_MAPINDEX)
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    clearHighlightLayer(mapIndex = DEFAULT_MAPINDEX) {
        return this.coreMapService.clearHighlightLayer(mapIndex);
    }
    /**
     * Wijzigt de stijl die wordt gebruikt voor het renderen van features
     * in de highlightlaag.
     *
     * @param styleLike OpenLayers StyleLike
     * @param mapIndex Index van de kaart waarop de stijl wordt
     * aangepast (default: DEFAULT_MAPINDEX)
     */
    changeHighlightLayerStyle(styleLike, mapIndex = DEFAULT_MAPINDEX) {
        this.coreMapService.changeHighlightLayerStyle(styleLike, mapIndex);
    }
    /**
     * Voegt één of meerdere features toe aan de selectionlaag.
     * Deze laag wordt doorgaans gebruikt voor geselecteerde objecten.
     *
     * @param features Array van OpenLayers features met geometrie
     * @param mapIndex Index van de kaart waarop de features worden
     * toegevoegd (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    addFeaturesToSelectionLayer(features, mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        return this.coreMapService.addFeaturesToSelectionLayer(features, mapIndex, selectIndex);
    }
    /**
     * Controleert of een feature aanwezig is in de selectionlaag.
     *
     * Een feature wordt als aanwezig beschouwd wanneer:
     * - dezelfde feature‑referentie voorkomt in de selectionlaag, of
     * - een feature met hetzelfde id voorkomt in de selectionlaag
     *
     * @param feature OpenLayers feature die gecontroleerd wordt
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns `true` indien de feature in de selectionlaag zit, anders `false`
     */
    isFeatureInSelectionLayer(feature, mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        return this.coreMapService.isFeatureInSelectionLayer(feature, mapIndex, selectIndex);
    }
    /**
     * Verwijdert alle features uit de selectionlaag.
     *
     * @param mapIndex Index van de kaart waarvoor de selectionlaag wordt
     * geleegd (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    clearSelectionLayer(mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        return this.coreMapService.clearSelectionLayer(mapIndex, selectIndex);
    }
    /**
     * Past de stijl aan waarmee features in de selectionlaag
     * worden weergegeven.
     *
     * @param styleLike OpenLayers stijl of stijl-functie
     * @param mapIndex Index van de kaart waarop de stijl wordt
     * aangepast (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     */
    changeSelectionLayerStyle(styleLike, mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        this.coreMapService.changeSelectionLayerStyle(styleLike, mapIndex, selectIndex);
    }
    /**
     * Controleert of de kaart zich op het maximale zoomniveau bevindt.
     *
     * @param mapIndex Index van de kaart waarvoor het zoomniveau wordt
     * gecontroleerd (default: DEFAULT_MAPINDEX)
     * @returns `true` indien het huidige zoomniveau gelijk is aan het maximale
     * zoomniveau, anders `false`
     */
    isMaxZoomlevel(mapIndex = DEFAULT_MAPINDEX) {
        const view = this.coreMapService.getMap(mapIndex).getView();
        return view.getZoom() === view.getMaxZoom();
    }
    /**
     * Geeft de geometrie of – indien niet aanwezig – het centroïde
     * uit een PDOK zoekresultaat.
     *
     * @param pdokDoc PDOK zoekresultaatdocument
     * @returns WKT-representatie van geometrie of centroïde, of `undefined`
     */
    getGeometrieOrCentroide(pdokDoc) {
        if (pdokDoc.geometrie_rd) {
            return pdokDoc.geometrie_rd;
        }
        if (pdokDoc.centroide_rd) {
            return pdokDoc.centroide_rd;
        }
    }
    /**
     * Haalt het eerste {@link SearchResultDoc} object uit een event.
     *
     * @param evt Event met PDOK zoekresultaten
     * @returns Het eerste zoekresultaatdocument of `undefined`
     */
    getSearchResultDocFromEvent(evt) {
        let pdokDoc;
        if (evt.value?.docs && evt.value.docs.length > 0) {
            pdokDoc = evt.value.docs[0];
        }
        return pdokDoc;
    }
    /**
     * Zet een stringrepresentatie van een geometrie om naar een
     * OpenLayers Geometry.
     */
    transformStringToGeometry(geometry, formatType = FormatType.WKT) {
        switch (formatType) {
            case FormatType.GEOJSON:
                return new GeoJSON().readGeometry(geometry);
            case FormatType.WKT:
            default:
                return new WKT().readGeometry(geometry);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class CoreMapEventsService {
    constructor() {
        this.coreLoadingServiceService = inject(CoreLoadingService);
        this.singleclickMap = new ObservableMapWrapper(() => new Subject());
        // ReplaySubject for zoomend, because it doesn't have an initial value and emits the last value on subscribing
        this.zoomendMap = new ObservableMapWrapper(() => new ReplaySubject(1));
    }
    destroyEventsForMap(mapIndex) {
        this.destroySingleclickForMap(mapIndex);
        this.destroyZoomendForMap(mapIndex);
    }
    // should only be called from map.component.ts
    emitSingleclickEventForMap(evt, mapIndex) {
        this.singleclickMap.getOrCreateSubject(mapIndex).next(evt);
    }
    getSingleclickObservableForMap(mapIndex) {
        return this.singleclickMap.getOrCreateObservable(mapIndex);
    }
    destroySingleclickForMap(mapIndex) {
        this.singleclickMap.delete(mapIndex);
    }
    // should only be called from map.component.ts
    emitZoomendEventForMap(evt, mapIndex) {
        this.zoomendMap.getOrCreateSubject(mapIndex).next(evt);
    }
    getZoomendObservableForMap(mapIndex) {
        return this.zoomendMap.getOrCreateObservable(mapIndex);
    }
    destroyZoomendForMap(mapIndex) {
        this.zoomendMap.delete(mapIndex);
    }
    getLoadingObservableForMap(mapIndex) {
        return this.coreLoadingServiceService.isLoading(mapIndex);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapEventsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapEventsService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMapEventsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Service die kaartgerelateerde OpenLayers-events exposeert
 * via observables.
 *
 * Deze service fungeert als façade over {@link CoreMapEventsService}
 * en biedt een vereenvoudigde API voor het luisteren naar
 * kaartinteracties.
 */
class GgcMapEventsService {
    constructor() {
        this.coreMapEventsService = inject(CoreMapEventsService);
    }
    /**
     * Returned een observable die emit zodra een zoomactie
     * op de opgegeven kaart is beëindigd.
     *
     * @param mapName Index van de kaart
     * @returns Observable met {@link MapEvent} bij het einde van een zoomactie
     */
    getZoomendObservableForMap(mapName) {
        return this.coreMapEventsService.getZoomendObservableForMap(mapName);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapEventsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapEventsService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapEventsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

const white = [255, 255, 255, 1];
const svgColorWhite = "#fff";
const svgColorGrey = "#666666";
const labelTextStyle = new Text({
    fill: new Fill({
        color: white
    }),
    padding: [5, 6, 5, 5], // [top, right, bottom, left]
    offsetY: -25
});
const segmentLabelTextStyle = new Text({
    fill: new Fill({
        color: svgColorGrey
    }),
    padding: [5, 6, 5, 5], // [top, right, bottom, left]
    offsetY: -25
});
const labelImageStyle = new Icon({
    src: URL.createObjectURL(new Blob([getLabelSvg(svgColorGrey, svgColorGrey)], {
        type: "image/svg+xml"
    }))
});
const crossHairImageStyle = [
    new Style({
        image: new Icon({
            src: URL.createObjectURL(new Blob([getCrosshairSvg()], {
                type: "image/svg+xml"
            }))
        })
    }),
    new Style({
        image: new CircleStyle({
            radius: 2,
            fill: new Fill({ color: "#000000" })
        })
    })
];
const segmentLabelImageStyle = new Icon({
    src: URL.createObjectURL(new Blob([getLabelSvg(svgColorWhite, svgColorGrey)], {
        type: "image/svg+xml"
    }))
});
const segmentLengthStyle = new Style({
    text: segmentLabelTextStyle.clone(),
    image: segmentLabelImageStyle.clone()
});
const lengthStyle = new Style({
    text: labelTextStyle.clone(),
    image: labelImageStyle.clone()
});
const areaStyle = new Style({
    text: labelTextStyle.clone(),
    image: labelImageStyle.clone()
});
const styleLabelFunction = (feature, measureStyle, areaM2ToTextFunction) => {
    const point = feature.getGeometry()?.getType() === "Polygon"
        ? new Point(feature.getGeometry().getInteriorPoint().getCoordinates())
        : new Point(feature.getGeometry().getLastCoordinate());
    let labelText;
    if (areaM2ToTextFunction && feature.getGeometry() instanceof Polygon) {
        labelText = areaM2ToTextFunction(feature.getGeometry().getArea());
    }
    else {
        labelText = calculateAreaOrLength(feature);
    }
    const style = measureStyle.clone();
    style.getText()?.setText(labelText);
    style.setGeometry(point);
    return style;
};
const styleLengthLabelFunction = (feature, measureStyle) => {
    const geom = feature.getGeometry();
    let coord = geom.getLastCoordinate();
    let labelText;
    if (geom.getType() === "Polygon") {
        let length = 0;
        const coords = geom.getCoordinates()[0];
        coord = coords.reduce((previousValue, currentValue) => {
            if (previousValue) {
                const line = new LineString([previousValue, currentValue]);
                length += line.getLength();
            }
            return currentValue;
        }, coords[0]);
        if (coords.length > 1) {
            coord = coords[coords.length - 2];
        }
        labelText = lengthToString(length);
    }
    else {
        labelText = calculateLength(geom);
    }
    const point = new Point(coord);
    const style = measureStyle.clone();
    style.getText()?.setText(labelText);
    style.setGeometry(point);
    return style;
};
const styleAreaLabelFunction = (feature, measureStyle, areaM2ToTextFunction) => {
    const point = new Point([0, 0]);
    let labelText = "";
    if (feature.getGeometry()?.getType() === "Polygon") {
        const poly = feature.getGeometry();
        point.setCoordinates(poly.getInteriorPoint().getCoordinates());
        labelText = areaM2ToTextFunction
            ? areaM2ToTextFunction(poly.getArea())
            : calculateArea(poly);
    }
    else {
        point.setCoordinates(feature.getGeometry().getLastCoordinate());
    }
    const style = measureStyle.clone();
    style.getText()?.setText(labelText);
    style.setGeometry(point);
    return style;
};
const measuringStyleFunction = (feature) => {
    const defaultStyles = createEditingStyle();
    return defaultStyles[feature.getGeometry().getType()];
};
const finishedStyleFunction = (feature, resolution) => {
    return createDefaultStyle(feature, resolution);
};
const styleSegmentLabelFunction = (feature, segmentStyle) => {
    const geom = feature.getGeometry();
    const labels = [];
    if (geom instanceof LineString) {
        geom.forEachSegment((start, end) => {
            labels.push(getSegmentLabel(start, end, segmentStyle));
        });
    }
    else if (geom instanceof Polygon) {
        geom
            .getCoordinates()[0]
            .forEach((current, index, array) => {
            if (index > 0) {
                labels.push(getSegmentLabel(array[index - 1], current, segmentStyle));
            }
        });
    }
    return labels;
};
function calculateAreaOrLength(feature) {
    const drawingGeometry = feature.getGeometry();
    if (drawingGeometry instanceof LineString) {
        return calculateLength(drawingGeometry);
    }
    else if (drawingGeometry instanceof Polygon) {
        return calculateArea(drawingGeometry);
    }
    return "";
}
function calculateArea(drawingGeometry) {
    const area = drawingGeometry.getArea();
    let areaText;
    if (area > 10000) {
        areaText = `${Math.round((area / 1000000) * 100) / 100} km2`;
    }
    else {
        areaText = `${Math.round(area * 100) / 100} m2`;
    }
    return areaText;
}
function calculateLength(drawingGeometry) {
    return lengthToString(drawingGeometry.getLength());
}
function getLabelSvg(fillColor, strokeColor) {
    return `<svg width="80" height="75" xmlns="http://www.w3.org/2000/svg">
        <rect opacity="0.9" rx="5" id="svg_1" height="21.25" width="78" y="0" x="1" stroke="${strokeColor}" stroke-width="1" fill="${fillColor}"/>
        <path opacity="0.9" transform="rotate(-180, 40, 27.332)" id="svg_5"
          d="m33.12426,33.08272l6.87567,-11.50139l6.87567,11.50139l-13.75134,0z" fill-opacity="null" stroke-opacity="null"
          stroke-width="1" stroke="${strokeColor}" fill="${fillColor}"/>
       </svg>`;
}
function getSegmentLabel(start, end, segmentStyle) {
    const segment = new LineString([start, end]);
    const style = segmentStyle.clone();
    style.getText()?.setText(calculateLength(segment));
    style.setGeometry(new Point(segment.getFlatMidpoint()));
    return style;
}
function lengthToString(length = 0) {
    let lengthText;
    if (length > 1000) {
        lengthText = `${Math.round((length / 1000) * 100) / 100} km`;
    }
    else {
        lengthText = `${Math.round(length * 100) / 100} m`;
    }
    return lengthText;
}
function getCrosshairSvg() {
    return `<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="75" height="75" viewBox="-643.33 -643.33 300 300"><rect width="100%" height="100%" fill="transparent"/><path stroke-linecap="round" d="M50 92.875C26.358 92.875 7.125 73.642 7.125 50S26.358 7.125 50 7.125 92.875 26.358 92.875 50 73.642 92.875 50 92.875zm0-83.75C27.461 9.125 9.125 27.461 9.125 50c0 22.538 18.336 40.875 40.875 40.875 22.538 0 40.875-18.337 40.875-40.875C90.875 27.461 72.538 9.125 50 9.125z" style="stroke:#000;stroke-width:1.75;stroke-dasharray:none;stroke-linecap:butt;stroke-dashoffset:0;stroke-linejoin:miter;stroke-miterlimit:4;fill:#656565;fill-rule:nonzero;opacity:1" transform="matrix(1.48 0 0 1.48 -569.13 -566.6)" vector-effect="non-scaling-stroke"/><path d="M94.75 50c0 6.213-5.236 11.25-11.696 11.25H16.946C10.486 61.25 5.25 56.213 5.25 50s5.236-11.25 11.696-11.25h66.107c6.461 0 11.697 5.037 11.697 11.25z" style="stroke:#000;stroke-width:0;stroke-dasharray:none;stroke-linecap:butt;stroke-dashoffset:0;stroke-linejoin:miter;stroke-miterlimit:4;fill:#000;fill-rule:nonzero;opacity:1" transform="matrix(.65 0 0 .44 -465.34 -513.59)" vector-effect="non-scaling-stroke"/><path d="M94.75 50c0 6.213-5.236 11.25-11.696 11.25H16.946C10.486 61.25 5.25 56.213 5.25 50s5.236-11.25 11.696-11.25h66.107c6.461 0 11.697 5.037 11.697 11.25z" style="stroke:#000;stroke-width:0;stroke-dasharray:none;stroke-linecap:butt;stroke-dashoffset:0;stroke-linejoin:miter;stroke-miterlimit:4;fill:#000;fill-rule:nonzero;opacity:1" transform="matrix(.65 0 0 .44 -589.66 -513.59)" vector-effect="non-scaling-stroke"/><path d="M94.75 50c0 6.213-5.236 11.25-11.696 11.25H16.946C10.486 61.25 5.25 56.213 5.25 50s5.236-11.25 11.696-11.25h66.107c6.461 0 11.697 5.037 11.697 11.25z" style="stroke:#000;stroke-width:0;stroke-dasharray:none;stroke-linecap:butt;stroke-dashoffset:0;stroke-linejoin:miter;stroke-miterlimit:4;fill:#000;fill-rule:nonzero;opacity:1" transform="matrix(0 .65 -.44 0 -473.14 -585.61)" vector-effect="non-scaling-stroke"/><path d="M94.75 50c0 6.213-5.236 11.25-11.696 11.25H16.946C10.486 61.25 5.25 56.213 5.25 50s5.236-11.25 11.696-11.25h66.107c6.461 0 11.697 5.037 11.697 11.25z" style="stroke:#000;stroke-width:0;stroke-dasharray:none;stroke-linecap:butt;stroke-dashoffset:0;stroke-linejoin:miter;stroke-miterlimit:4;fill:#000;fill-rule:nonzero;opacity:1" transform="matrix(0 .65 -.44 0 -473.14 -462.21)" vector-effect="non-scaling-stroke"/></svg>`;
}

/**
 * Event types voor tekeninteracties.
 */
var DrawInteractionEventTypes;
(function (DrawInteractionEventTypes) {
    /** Wordt getriggerd wanneer een tekening wordt afgerond. */
    DrawInteractionEventTypes["DRAWEND"] = "drawend";
    /** Wordt getriggerd wanneer een tekening wordt afgerond. De eindstijl wordt
     * toegepast, worden validators gecontroleerd en wordt de berekende
     * meting als property op de feature gezet. */
    DrawInteractionEventTypes["DRAWSTART"] = "drawstart";
})(DrawInteractionEventTypes || (DrawInteractionEventTypes = {}));
/**
 * Event dat wordt uitgezonden bij teken-interacties op de kaart.
 *
 * @param type - Type van het tekeninteractie-event.
 * @param drawType - Type tekening dat getekend wordt of is afgerond.
 * @param mapIndex - Index van de kaart waarop het event plaatsvindt.
 * @param message - Beschrijvend bericht bij het event.
 * @param event - Het onderliggende OpenLayers `DrawEvent`.
 * @param valid - Geeft aan of de tekening geldig is conform de ingestelde validatiefuncties. Default: `true`.
 * @param measurement - Optioneel: de berekende oppervlakte of lengte als string.
 */
class DrawInteractionEvent {
    constructor(type, drawType, mapIndex, message, event, valid = true, measurement) {
        this.type = type;
        this.drawType = drawType;
        this.mapIndex = mapIndex;
        this.message = message;
        this.event = event;
        this.valid = valid;
        this.measurement = measurement;
    }
}

var ModifyInteractionEventTypes;
(function (ModifyInteractionEventTypes) {
    ModifyInteractionEventTypes["MODIFYEND"] = "modifyend";
    ModifyInteractionEventTypes["MOVEEND"] = "moveend";
})(ModifyInteractionEventTypes || (ModifyInteractionEventTypes = {}));
class ModifyInteractionEvent {
    constructor(type, mapIndex, message, event, valid = true) {
        this.type = type;
        this.mapIndex = mapIndex;
        this.message = message;
        this.event = event;
        this.valid = valid;
    }
}

/**
 * Converteert een OpenLayers feature naar een GeoJSON feature.
 *
 * De geometrie wordt getransformeerd van de kaartprojectie
 * (EPSG:28992) naar de opgegeven data-projectie.
 *
 * @param feature OpenLayers feature met geometrie
 * @param dataProjection Doelprojectie voor de GeoJSON output
 * (default "EPSG:4326")
 * @returns GeoJSON {@link Feature}
 */
const toGeoJSONFeature = (feature, dataProjection = "EPSG:4326") => {
    const geoJsonFormat = new GeoJSON();
    return geoJsonFormat.writeFeatureObject(feature, {
        dataProjection,
        featureProjection: epsg28992
    });
};
/**
 * Converteert een GeoJSON feature naar één of meerdere
 * OpenLayers features.
 *
 * De geometrie wordt getransformeerd van de data-projectie
 * naar de kaartprojectie (EPSG:28992).
 *
 * @param feature GeoJSON feature
 * @param dataProjection Projectie van de GeoJSON input
 *                       (default "EPSG:4326")
 * @returns Eén of meerdere OpenLayers features
 */
const fromGeoJSONFeature = (feature, dataProjection = "EPSG:4326") => {
    const geoJsonFormat = new GeoJSON();
    return geoJsonFormat.readFeature(feature, {
        dataProjection,
        featureProjection: epsg28992
    });
};
/**
 * Converteert een GeoJSON FeatureCollection naar
 * OpenLayers features.
 *
 * De geometrieën worden getransformeerd van de data-projectie
 * naar de kaartprojectie (EPSG:28992).
 *
 * @param features GeoJSON FeatureCollection
 * @param dataProjection Projectie van de GeoJSON input
 *                       (default "EPSG:4326")
 * @returns Array van OpenLayers features
 */
const fromGeoJSONFeatures = (features, dataProjection = "EPSG:4326") => {
    const geoJsonFormat = new GeoJSON();
    return geoJsonFormat.readFeatures(features, {
        dataProjection,
        featureProjection: epsg28992
    });
};
/**
 * Zet een draw-interactietype om naar een OpenLayers
 * geometrie-type.
 *
 * Wordt gebruikt bij het configureren van draw-interacties
 * en geometrie-afhankelijke logica.
 *
 * @param drawType Type van de draw-interactie
 * @returns OpenLayers geometrie-type
 */
const drawTypeToGeometryType = (drawType) => {
    switch (drawType) {
        case MapComponentDrawTypes.RECTANGLE:
        case MapComponentDrawTypes.POLYGON:
            return "Polygon";
        case MapComponentDrawTypes.CIRCLE:
            return "Circle";
        case MapComponentDrawTypes.LINESTRING:
            return "LineString";
        case MapComponentDrawTypes.POINT:
            return "Point";
    }
};

class DrawValidator {
    constructor(feature, validationFunctions) {
        this.feature = feature;
        this.ignoreNextChange = false;
        this.wasValid = true;
        this.eventsKey = this.feature.on("change", this.onDrawChange.bind(this));
        this.validators = validationFunctions;
    }
    destroy() {
        // Remove any references
        this._styleMap = undefined;
        this.validators = [];
        unByKey(this.eventsKey);
    }
    finish() {
        if (!this.validate(this.feature)) {
            this.feature.setStyle(this._styleMap?.invalidFinishDrawStyle);
            return false;
        }
        return true;
    }
    validate(feature) {
        // Make a copy with slice because the splice method wil alter the original array
        return this.validators
            .slice(0)
            .reduce((_prev, validator, _idx, validators) => {
            if (!validator(feature)) {
                // Stop further validation by emptying the array
                validators.splice(0, validators.length);
                return false;
            }
            return true;
        }, true);
    }
    onDrawChange() {
        if (this.ignoreNextChange) {
            this.ignoreNextChange = false;
            return;
        }
        const isValid = this.validate(this.feature);
        if (isValid !== this.wasValid) {
            // Ignore next change event to prevent event recursion
            this.ignoreNextChange = true;
            if (isValid) {
                this.feature.setStyle(this._styleMap?.drawingDrawStyle);
            }
            else if (this._styleMap?.invalidDrawStyle) {
                this.feature.setStyle(this._styleMap?.invalidDrawStyle);
            }
            this.wasValid = isValid;
        }
    }
    set styleMap(styleMap) {
        this._styleMap = styleMap;
    }
}

class CoreDrawValidationService {
    constructor() {
        this.validators = new Map();
    }
    addValidators(mapIndex, feature, validatorFunctions, styles) {
        if (validatorFunctions.length > 0) {
            const drawValidator = new DrawValidator(feature, validatorFunctions);
            const validators = this.validators.get(mapIndex) || [];
            drawValidator.styleMap = styles;
            validators.push(drawValidator);
            this.validators.set(mapIndex, validators);
        }
    }
    checkAndRemoveValidators(mapIndex) {
        let isValid = true;
        const validators = this.validators.get(mapIndex) || [];
        validators.forEach((drawValidator) => {
            isValid = isValid && drawValidator.finish();
            drawValidator.destroy();
        });
        this.validators.delete(mapIndex);
        return isValid;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawValidationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawValidationService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawValidationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class CoreMeasureDrawStyleService {
    getMeasureStyle(measureType, drawOptions, measureStyleMap, modifying = false) {
        const styleLikeMap = {};
        const measureStyles = {
            lengthLabelStyle: lengthStyle,
            segmentLengthLabelStyle: segmentLengthStyle,
            areaLabelStyle: areaStyle,
            drawingDrawStyle: modifying
                ? finishedStyleFunction
                : measuringStyleFunction,
            invalidDrawStyle: modifying
                ? finishedStyleFunction
                : measuringStyleFunction,
            finishDrawStyle: finishedStyleFunction,
            invalidFinishDrawStyle: finishedStyleFunction,
            ...measureStyleMap
        };
        const drawStyles = [
            "drawingDrawStyle",
            "invalidDrawStyle",
            "finishDrawStyle",
            "invalidFinishDrawStyle"
        ];
        drawStyles.forEach((drawStyle) => {
            styleLikeMap[drawStyle] = this.extendStyleFunctionWithLabels(drawStyle, measureStyles, measureType, drawOptions);
        });
        if (measureStyles.crossHairStyle) {
            styleLikeMap.crossHairStyle = measureStyles.crossHairStyle;
        }
        return styleLikeMap;
    }
    extendStyleFunctionWithLabels(drawStyle, measureStyleMap, measureType, drawOptions) {
        return (feature, resolution) => {
            const geometryType = feature.getGeometry().getType();
            // OpenLayers accepteert een pletora aan stijlen samengevoegd in StyleLike,
            // dit kan een Style zijn, een array van Styles, of een functie die een Style retourneert
            let style = measureStyleMap[drawStyle] instanceof Style ||
                Array.isArray(measureStyleMap[drawStyle])
                ? measureStyleMap[drawStyle]
                : measureStyleMap[drawStyle].call(this, feature, resolution);
            if (measureType === "Circle" || measureType === "Point") {
                // Circles en Points kunnen geen metingen bevatten
                return style;
            }
            // Voeg labels toe als de geometrietype hetzelfde is en je aan het tekenen bent of het een afgeronde tekening betreft en geen punt is
            if (geometryType === measureType ||
                ((drawStyle === "finishDrawStyle" ||
                    drawStyle === "invalidFinishDrawStyle") &&
                    geometryType !== "Point")) {
                // toon de segment lengte
                if (drawOptions.showSegmentLength) {
                    style = CoreMeasureDrawStyleService.addLabelCallbackToStyle(feature, style, measureStyleMap.segmentLengthLabelStyle, styleSegmentLabelFunction);
                }
                // toon de totale lengte
                if (drawOptions.showTotalLength) {
                    style = CoreMeasureDrawStyleService.addLabelCallbackToStyle(feature, style, measureStyleMap.lengthLabelStyle, styleLengthLabelFunction);
                }
                // vervolgens als je geen lijn tekent, dan toon ook de oppervlakte
                if (geometryType !== "LineString" && drawOptions.showArea) {
                    style = CoreMeasureDrawStyleService.addLabelCallbackToStyle(feature, style, measureStyleMap.areaLabelStyle, styleAreaLabelFunction, drawOptions.areaM2ToTextFunction);
                }
            }
            return style;
        };
    }
    // voeg aan de stijl de styling van het label en de callbackfunctie toe (voor het berekenen van lengte en oppervlakte)
    static addLabelCallbackToStyle(feature, style, measureStyle, callback, areaM2ToTextFunction) {
        if (Array.isArray(style)) {
            style = style.concat(callback(feature, measureStyle, areaM2ToTextFunction));
        }
        else if (style instanceof Style) {
            style = [style].concat(callback(feature, measureStyle, areaM2ToTextFunction));
        }
        return style;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMeasureDrawStyleService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMeasureDrawStyleService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreMeasureDrawStyleService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class CoreDrawLayerService {
    constructor() {
        this.coreMapService = inject(CoreMapService);
        this.drawLayers = new Map();
    }
    getDrawLayer(layerName, mapIndex, style) {
        const key = `${mapIndex}-${layerName}`;
        if (!this.drawLayers.has(key)) {
            const vectorLayer = this.coreMapService.createLayerAndAddToMap(mapIndex, style);
            this.drawLayers.set(key, vectorLayer);
        }
        return this.drawLayers.get(key);
    }
    getDrawLayers() {
        return this.drawLayers;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawLayerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawLayerService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawLayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

class SnapExtendedEvent {
}
function createSnapExtendedEvent(snapEvent) {
    const snapExtendedEvent = new SnapExtendedEvent();
    snapExtendedEvent.action = "snap";
    snapExtendedEvent.snappedTo = snapEvent.segment ? "line" : "vertex";
    snapExtendedEvent.snapEvent = snapEvent;
    return snapExtendedEvent;
}
function createUnsnapExtendedEvent(snapEvent) {
    const snapExtendedEvent = new SnapExtendedEvent();
    snapExtendedEvent.action = "unsnap";
    snapExtendedEvent.snapEvent = snapEvent;
    return snapExtendedEvent;
}

class CoreSnapService {
    constructor() {
        this.snapInteractions = new Map();
        this.coreMapService = inject(CoreMapService);
        this.coreDrawLayerService = inject(CoreDrawLayerService);
        this.snapFeatures = new Collection([], {
            unique: true
        });
        this.initializedLayers = [];
        this.snapExtendedEventsMap = new ObservableMapWrapper(() => new Subject());
    }
    startSnap(drawLayer, mapIndex, snapOptions) {
        this.stopSnap(mapIndex);
        this.snapFeatures.clear();
        // wanneer er geen snapLayers of snapDrawLayers zijn opgegeven
        // dan alleen snappen naar zichzelf (=default)
        if (!snapOptions.snapDrawLayers && !snapOptions.snapLayers) {
            if (!this.isInitialized(drawLayer)) {
                this.initializeSnap(drawLayer, mapIndex);
            }
            this.addToSnapFeatures(this.coreDrawLayerService.getDrawLayer(drawLayer, mapIndex));
        }
        //wanneer snaplayers bestaan de features toevoegen aan snapFeatures
        if (snapOptions.snapLayers) {
            snapOptions.snapLayers.forEach((snapLayer) => {
                this.addToSnapFeatures(this.coreMapService.getLayer(snapLayer, mapIndex));
            });
        }
        //als drawsnaplayers bestaan de features toevoegen aan snapfeatures
        if (snapOptions.snapDrawLayers) {
            snapOptions.snapDrawLayers.forEach((snapLayer) => {
                if (!this.isInitialized(snapLayer)) {
                    this.initializeSnap(snapLayer, mapIndex);
                }
                this.addToSnapFeatures(this.coreDrawLayerService.getDrawLayer(snapLayer, mapIndex));
            });
        }
        const snap = new Snap({
            features: this.snapFeatures,
            pixelTolerance: snapOptions.pixelTolerance ?? 10,
            vertex: snapOptions.vertex ?? true,
            edge: snapOptions.edge ?? true,
            intersection: snapOptions.intersection ?? false,
            segmenters: snapOptions.segmenters ?? undefined
        });
        this.snapInteractions.set(`${mapIndex}-${drawLayer}`, snap);
        this.coreMapService.getMap(mapIndex).addInteraction(snap);
        this.setSnap(mapIndex, snap);
    }
    stopSnap(mapIndex) {
        const prefix = `${mapIndex}-`;
        this.snapInteractions.forEach((interaction, key) => {
            if (key.startsWith(prefix)) {
                this.coreMapService.getMap(mapIndex).removeInteraction(interaction);
                this.snapInteractions.delete(key);
            }
        });
    }
    startSnapAgainIfExists(layerName, mapIndex) {
        // if SnapInteraction exists for mapIndex, add SnapInteraction again, so it's added as last interaction to the map.
        // SnapInteraction must be added after Modify- or DrawInteraction
        const interaction = this.snapInteractions.get(`${mapIndex}-${layerName}`);
        if (interaction) {
            this.coreMapService.getMap(mapIndex).addInteraction(interaction);
        }
    }
    initializeSnap(drawLayer, mapIndex) {
        const layer = this.coreDrawLayerService.getDrawLayer(drawLayer, mapIndex);
        if (layer) {
            this.initializedLayers.push(drawLayer);
            const sf = this.snapFeatures;
            layer.getSource().on("addfeature", function (evt) {
                if (evt.feature) {
                    sf.push(evt.feature);
                }
            });
            layer.getSource().on("removefeature", function (evt) {
                if (evt.feature) {
                    sf.remove(evt.feature);
                }
            });
        }
    }
    isInitialized(drawLayer) {
        return this.initializedLayers.includes(drawLayer);
    }
    addToSnapFeatures(snapLayer) {
        if (snapLayer) {
            const features = snapLayer.getSource().getFeatures();
            this.snapFeatures.extend(features);
        }
    }
    setSnap(mapIndex, snap) {
        snap.on("snap", (event) => {
            this.snapExtendedEventsMap
                .getOrCreateSubject(mapIndex)
                .next(createSnapExtendedEvent(event));
        });
        snap.on("unsnap", (event) => {
            this.snapExtendedEventsMap
                .getOrCreateSubject(mapIndex)
                .next(createUnsnapExtendedEvent(event));
        });
    }
    getSnapExtendedEventsObservable(mapIndex) {
        return this.snapExtendedEventsMap.getOrCreateObservable(mapIndex);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSnapService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSnapService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSnapService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Returns whether the provided coordinate is on the outline of the given feature and if it is a vertex or a line.
 * If the coordinate is not on the feature, undefined is returned.
 * @param feature
 * @param coordinate
 */
function isCoordinateInFeature(feature, coordinate) {
    const closestCoordinate = getClosestCoordinate(feature, coordinate);
    if (!closestCoordinate) {
        return undefined;
    }
    const coordinateOnFeature = coordinatesAreEqual(closestCoordinate, coordinate);
    if (!coordinateOnFeature) {
        return undefined;
    }
    const featureVertices = getCoordinatesOfFeature(feature);
    const isVertex = featureVertices.some((vertex) => {
        return coordinatesAreEqual(vertex, coordinate);
    });
    return isVertex ? "vertex" : "segment";
}
/**
 * Returns whether the provided coordinate is on the segment/line between the 2 provided segment coordinates.
 * The segmentCoordinates are excluded.
 * @param segmentCoordinate1
 * @param segmentCoordinate2
 * @param coordinate
 */
function coordinateIsOnSegment(segmentCoordinate1, segmentCoordinate2, coordinate) {
    const lineString = new LineString$1([
        segmentCoordinate1,
        segmentCoordinate2
    ]);
    return (isCoordinateInFeature(new Feature(lineString), coordinate) == "segment");
}
/**
 * Returns whether the given coordinate intersects the feature.
 * Point and linestring will always return false
 */
function intersectsCoordinate(feature, coordinate) {
    const geom = feature.getGeometry();
    if (!geom)
        return;
    if (geom.getType() === "Polygon" || geom.getType() === "MultiPolygon") {
        return geom.intersectsCoordinate(coordinate);
    }
    return false;
}
/**
 * get the closest coordinate of the feature to the provided coordinate
 * @param feature
 * @param coordinate
 */
function getClosestCoordinate(feature, coordinate) {
    const geometry = feature.getGeometry();
    if (geometry instanceof Point) {
        return geometry.getCoordinates();
    }
    else if (geometry instanceof LineString$1) {
        return geometry.getClosestPoint(coordinate);
    }
    else if (geometry instanceof Polygon) {
        return geometry.getClosestPoint(coordinate);
    }
    return undefined;
}
/**
 * Returns the coordinates of a feature as a list of coordinates
 * @param feature The feature to get the coordinates from
 */
function getCoordinatesOfFeature(feature) {
    const geometry = feature.getGeometry();
    if (!geometry) {
        return [];
    }
    return getCoordinatesOfGeometry(geometry);
}
function getCoordinatesOfGeometry(geometry) {
    if (geometry instanceof Point) {
        return [geometry.getCoordinates()];
    }
    else if (geometry instanceof LineString$1) {
        return geometry.getCoordinates();
    }
    else if (geometry instanceof Polygon) {
        return geometry.getCoordinates().flat();
    }
    return [];
}
function getCoordinatesOfFeatureWithMiddlePoints(feat) {
    const coords = getCoordinatesOfFeature(feat);
    const result = [];
    for (let i = 0; i < coords.length - 1; i++) {
        //voeg punt  en tussenpunt toe
        result.push(coords[i], new LineString$1([coords[i], coords[i + 1]]).getCoordinateAt(0.5));
    }
    //voeg laatste punt toe, niet voor polygoon (dit is namelijk hetzelfde als het eerste punt)
    if (feat.getGeometry() && feat.getGeometry().getType() !== "Polygon") {
        result.push(coords.at(-1));
    }
    return result;
}
/**
 * Calculate the distance between 2 pixels
 * @param p1 pixel 1
 * @param p2 pixel 2
 */
function calculateDistanceOfPixels(p1, p2) {
    const dx = p1[0] - p2[0];
    const dy = p1[1] - p2[1];
    return Math.hypot(dx, dy);
}
function calculateDistanceOfCoordinates(c1, c2) {
    const dx = c1[0] - c2[0];
    const dy = c1[1] - c2[1];
    return Math.hypot(dx, dy);
}
/**
 * Coordintes are often not exactly the same, therefore we introduce this function which checks if they are close enough
 * @param coord1 Coordinaat 1
 * @param coord2 Coordinaat 2
 * @param margin The margin when 2 coordinates are seen as equal
 */
function coordinatesAreEqual(coord1, coord2, margin = 1e-9) {
    return (Math.abs(coord1[0] - coord2[0]) < margin &&
        Math.abs(coord1[1] - coord2[1]) < margin);
}
function getClosestVertex(features, coordinate) {
    let closestFeatureVertex;
    let minDistance = Infinity;
    features.forEach((feature) => {
        const featureVertices = getCoordinatesOfFeature(feature);
        for (const vertex of featureVertices) {
            const distance = calculateDistanceOfCoordinates(coordinate, vertex);
            if (distance < minDistance) {
                minDistance = distance;
                closestFeatureVertex = {
                    feature: feature,
                    coordinate: vertex
                };
            }
        }
    });
    return closestFeatureVertex;
}
function getClosestSegmentCoordinate(features, coordinate) {
    let closestFeatureCoordinate;
    let minDistance = Infinity;
    features.forEach((feature) => {
        const featureCoordinate = getClosestCoordinate(feature, coordinate);
        if (featureCoordinate) {
            const distance = calculateDistanceOfCoordinates(coordinate, featureCoordinate);
            if (distance < minDistance) {
                minDistance = distance;
                closestFeatureCoordinate = {
                    feature: feature,
                    coordinate: featureCoordinate
                };
            }
        }
    });
    return closestFeatureCoordinate;
}

class CenterBase extends Interaction {
    constructor(options) {
        super();
        const style = options.crossHairStyle ?? crossHairImageStyle;
        this.crossHairOverlay = this.createVectorLayerWithStyle(style, Infinity);
    }
    createVectorLayerWithStyle(style, zIndex) {
        return new VectorLayer({
            source: new VectorSource({
                useSpatialIndex: false
            }),
            style: style,
            updateWhileInteracting: true,
            updateWhileAnimating: true,
            zIndex: zIndex
        });
    }
    setMap(map) {
        super.setMap(map);
        if (map) {
            this.registerListeners(map);
            this.crossHairOverlay.setMap(map);
            const center = map.getView().getCenter();
            if (center) {
                const crossHairSource = this.crossHairOverlay.getSource();
                this.centerPoint = new Point(center);
                crossHairSource.addFeature(new Feature(this.centerPoint));
            }
        }
        else {
            this.crossHairOverlay.setMap(map);
            unlistenByKey(this.changeCenterListener);
        }
    }
    cleanup() {
        unByKey(this.changeCenterListener);
        if (this.getMap() && this.crossHairOverlay) {
            this.crossHairOverlay.setMap(null);
            this.getMap().removeLayer(this.crossHairOverlay);
        }
    }
    updateCenterPoint() {
        const map = this.getMap();
        if (!map) {
            return;
        }
        const center = map.getView().getCenter();
        if (center) {
            this.centerPoint.setCoordinates(center);
        }
    }
    placeCrossHairOverlayOnTop() {
        const map = this.getMap();
        if (!map || !this.crossHairOverlay) {
            return;
        }
        this.crossHairOverlay.setMap(null);
        this.crossHairOverlay.setMap(map);
    }
    registerListeners(map) {
        this.changeCenterListener = listen(map.getView(), "change:center", this.updateCenterPoint, this);
    }
    calculatePixelDistanceOfCoordinates(c1, c2) {
        const map = this.getMap();
        if (!map) {
            return Infinity;
        }
        const p1 = map.getPixelFromCoordinate(c1);
        const p2 = map.getPixelFromCoordinate(c2);
        return calculateDistanceOfPixels(p1, p2);
    }
}

class CenterDraw extends CenterBase {
    constructor(options) {
        super({ crossHairStyle: options.crossHairStyle });
        this.type = options.type;
        this.overlay = new VectorLayer({
            source: new VectorSource({
                useSpatialIndex: false
            }),
            style: options.style,
            updateWhileInteracting: true,
            updateWhileAnimating: true,
            zIndex: 1
        });
        this.targetSource = options.source;
    }
    setMap(map) {
        super.setMap(map);
        this.overlay.setMap(map);
    }
    updateCenterPoint() {
        super.updateCenterPoint();
        if (this.sketchFeature) {
            switch (this.sketchFeature?.getGeometry().getType()) {
                case "Point":
                    //niks te doen
                    break;
                case "LineString":
                    this.updateLineString(this.sketchFeature?.getGeometry());
                    break;
                case "Polygon":
                    this.updatePolygon(this.sketchFeature?.getGeometry());
                    break;
            }
        }
    }
    updateLineString(geometry) {
        const coords = geometry.getCoordinates();
        if (coords.length > 1) {
            coords.pop();
            geometry.setCoordinates(coords);
        }
        geometry.appendCoordinate(this.centerPoint.getCoordinates());
    }
    updatePolygon(geometry) {
        const coords = geometry.getCoordinates()[0];
        coords.splice(coords.length - 2, 1, this.centerPoint.getCoordinates());
        geometry.setCoordinates([coords]);
    }
    appendCoordinates() {
        const map = this.getMap();
        const center = this.getMap()?.getView().getCenter();
        //punt niet toevoegen als het op dezelfde positie wordt geplaatst
        if (center == this.previousCenter) {
            return;
        }
        this.previousCenter = center;
        const sketchGeometry = this.sketchFeature?.getGeometry();
        if (!sketchGeometry && map) {
            this.initializeSketch(map);
        }
        if (center) {
            if (sketchGeometry instanceof Point) {
                //niets te doen
            }
            else if (sketchGeometry instanceof LineString$1) {
                // Coördinaten worden aan het einde van de bestaande array toegevoegd.
                sketchGeometry.appendCoordinate(center);
            }
            else if (sketchGeometry instanceof Polygon$1) {
                this.appendToPolygon(sketchGeometry, center);
            }
        }
    }
    appendToPolygon(geometry, center) {
        // Coördinaten worden vóór het sluitende coördinaat van de
        // buitenring toegevoegd, om de ring geldig te houden.
        const coords = geometry.getCoordinates();
        if (coords.length == 0) {
            coords.push([center, center, center]);
        }
        else {
            coords[0].splice(coords[0].length - 2, 0, center);
        }
        geometry.setCoordinates(coords);
    }
    initializeSketch(map) {
        const centerCoordinates = this.centerPoint.getCoordinates();
        switch (this.type) {
            case "Point":
                this.sketchFeature = new Feature(new Point(centerCoordinates));
                this.finishDrawing();
                break;
            case "LineString":
                this.sketchFeature = new Feature(new LineString$1([centerCoordinates, centerCoordinates]));
                break;
            case "Polygon":
                this.sketchFeature = new Feature(new Polygon$1([
                    [centerCoordinates, centerCoordinates, centerCoordinates]
                ]));
                break;
            default:
                this.sketchFeature = undefined;
        }
        this.overlay.setMap(map);
        if (this.sketchFeature) {
            this.dispatchEvent(new DrawEvent("drawstart", this.sketchFeature));
            const overlaySource = this.overlay.getSource();
            overlaySource.addFeature(this.sketchFeature);
        }
    }
    removeLastPoint() {
        const center = this.getMap()?.getView().getCenter();
        const sketchGeometry = this.sketchFeature?.getGeometry();
        if (sketchGeometry instanceof LineString$1) {
            const coords = sketchGeometry.getCoordinates();
            if (coords.length > 2) {
                coords.splice(coords.length - 2, 2, center);
                sketchGeometry.setCoordinates(coords);
                this.previousCenter = undefined;
            }
            else {
                this.abortDrawing();
            }
        }
        if (sketchGeometry instanceof Polygon$1) {
            const coords = sketchGeometry.getCoordinates()[0];
            if (coords && coords.length > 3) {
                coords.splice(coords.length - 3, 1);
                sketchGeometry.setCoordinates([coords]);
                this.previousCenter = undefined;
            }
            else {
                this.abortDrawing();
            }
        }
    }
    finishDrawing() {
        // remove the redundant vertices in line and polygon
        const sketchGeometry = this.sketchFeature?.getGeometry();
        if (sketchGeometry instanceof LineString$1) {
            const coords = sketchGeometry.getCoordinates();
            coords.pop();
            sketchGeometry.setCoordinates(coords);
        }
        if (sketchGeometry instanceof Polygon$1) {
            const coords = sketchGeometry.getCoordinates()[0];
            coords.splice(coords.length - 2, 1);
            sketchGeometry.setCoordinates([coords]);
        }
        const sketchFeature = this.abortDrawing();
        if (!sketchFeature) {
            return;
        }
        this.dispatchEvent(new DrawEvent("drawend", sketchFeature));
        this.targetSource?.addFeature(sketchFeature);
    }
    /*
     * Geeft de Geometry die getekend wordt terug,
     * zonder de huidige positie van de cursor.
     */
    getSketchCoordinates() {
        const sketchGeometry = this.sketchFeature?.getGeometry();
        if (!sketchGeometry)
            return [];
        switch (sketchGeometry.getType()) {
            case "Point":
                return [sketchGeometry.getCoordinates()];
            case "LineString":
                return this.getWithoutLastCoord(sketchGeometry);
            case "Polygon":
                return this.getWithoutSecondToLastCoord(sketchGeometry);
            default:
                console.warn("Unknown geometry type");
                return [];
        }
    }
    getWithoutLastCoord(line) {
        const coords = [...line.getCoordinates()];
        const index = coords.length - 1;
        coords.splice(index, 1);
        return coords;
    }
    getWithoutSecondToLastCoord(polygon) {
        const rings = [...polygon.getCoordinates()];
        if (!rings || rings.length === 0) {
            return [];
        }
        const outerRing = [...rings[0]];
        const length = outerRing.length;
        /*
          Wanneer de polygon getekend wordt vult deze de coördinaten[] met 3 punten.
          Daarnaast is er ook nog het punt waar de pointer staat op de kaart.
          Om alleen de gezette punten terug te geven worden de laatste 2 punten verwijderd.
         */
        if (length <= 4) {
            outerRing.splice(-2);
            return outerRing.splice(-2);
        }
        /*
         Als je 3 punten hebt geplaatst is er een geldige polygon en kan de tekening ook worden afgerond,
         Hier verwijderen we alleen het voorlaatste punt (dit is de positie van de pointer op de kaart).
        */
        const index = outerRing.length - 2;
        outerRing.splice(index, 1);
        return outerRing;
    }
    abortDrawing() {
        const sketchFeature = this.sketchFeature;
        this.sketchFeature = undefined;
        this.previousCenter = undefined;
        this.overlay.getSource().clear(true);
        return sketchFeature;
    }
    cleanup() {
        super.cleanup();
    }
}

const modifyBlue = "#0adcf8";
const modifyWhite = "#ffffff";
const defaultHighlightStyle = [
    // Dikke witte lijn
    new Style$1({
        stroke: new Stroke({ color: modifyWhite, width: 5 })
    }),
    // Dunne blauwe lijn
    new Style$1({
        stroke: new Stroke({ color: modifyBlue, width: 3 })
    }),
    // Bolletjes op elk punt van de lijn
    new Style$1({
        image: new CircleStyle({
            radius: 5,
            fill: new Fill$1({ color: modifyWhite }),
            stroke: new Stroke({ color: modifyBlue, width: 2 })
        }),
        geometry: (feature) => {
            const geom = feature.getGeometry();
            if (geom instanceof LineString$1 || geom instanceof Polygon) {
                return new MultiPoint(getCoordinatesOfGeometry(geom));
            }
            return null;
        }
    })
];
const defaultSelectedPointStyle = new Style$1({
    image: new CircleStyle({
        radius: 6,
        fill: new Fill$1({ color: modifyWhite }),
        stroke: new Stroke({ color: modifyBlue, width: 2 })
    })
});
const defaultPointModifyStyle = new Style$1({
    image: new CircleStyle({
        radius: 6,
        fill: new Fill$1({ color: modifyBlue }),
        stroke: new Stroke({ color: modifyWhite, width: 2 })
    })
});

class CenterModify extends CenterBase {
    constructor(options) {
        super(options);
        this.pixelTolerance = 6;
        this.keyNextPoint = "BracketRight"; // ]
        this.keyPrevPoint = "BracketLeft"; // [
        this.handleKeyPress = (evt) => {
            if (!this.highlightedFeature) {
                return;
            }
            switch (evt.code) {
                case this.keyNextPoint:
                    this.updateNextTabCoordinate();
                    break;
                case this.keyPrevPoint:
                    this.updatePreviousTabCoordinate();
                    break;
            }
            this.getMap().getView().setCenter(this.getCurrentTabCoordinate());
        };
        this.modifyOverlay = this.createVectorLayerWithStyle(options.modifyStyle ?? defaultHighlightStyle, Infinity);
        this.selectedPointOverlay = this.createVectorLayerWithStyle(options.selectedPointStyle ?? defaultSelectedPointStyle, Infinity);
        this.selectedPointStyle = options.selectedPointStyle;
        this.targetSource = options.targetSource;
        if (options.pixelTolerance) {
            this.pixelTolerance = options.pixelTolerance;
        }
        this.setOptionalCustomKeys(options);
        globalThis.addEventListener("keypress", this.handleKeyPress);
    }
    setMap(map) {
        super.setMap(map);
        this.modifyOverlay.setMap(map);
        this.selectedPointOverlay.setMap(map);
        this.placeCrossHairOverlayOnTop();
        this.updateCenterPoint();
    }
    /**
     * Start het bewerken van een feature met center interaction
     */
    startModifyCurrentPoint() {
        const featureCoordinate = this.getClosestFeatureCoordinate(this.targetSource.getFeatures(), this.centerPoint.getCoordinates(), this.pixelTolerance);
        if (!featureCoordinate) {
            return;
        }
        const feature = featureCoordinate.feature;
        const coordinate = featureCoordinate.coordinate;
        this.targetSource.removeFeature(feature);
        this.modifyOverlay.getSource().addFeature(feature);
        this.sketchFeature = feature;
        if (coordinate) {
            this.modifiedIndex = this.coordinateOfFeatureToIndex(feature, coordinate);
        }
        if (!this.selectedPointStyle) {
            this.selectedPointOverlay?.setStyle(defaultPointModifyStyle);
        }
        this.updateCenterPoint();
    }
    finishModify() {
        const sketchFeature = this.abortModifying();
        if (!sketchFeature) {
            return;
        }
        this.dispatchEvent(new DrawEvent("modifyend", sketchFeature));
        this.targetSource?.addFeature(sketchFeature);
        if (!this.selectedPointStyle) {
            this.selectedPointOverlay?.setStyle(defaultSelectedPointStyle);
        }
        this.updateCenterPoint();
    }
    removeModifyCurrentPoint() {
        const featureCoordinate = this.getClosestFeatureCoordinate(this.targetSource.getFeatures(), this.centerPoint.getCoordinates(), this.pixelTolerance);
        if (!featureCoordinate) {
            return;
        }
        const feature = featureCoordinate.feature;
        const selectedCoordinate = featureCoordinate.coordinate;
        if (feature.getGeometry() instanceof Point) {
            this.targetSource.removeFeature(feature);
            this.modifyOverlay.getSource()?.clear();
            this.highlightedFeature = undefined;
        }
        else if (feature.getGeometry() instanceof LineString$1) {
            const lineString = feature.getGeometry();
            const originalCoordinatesLineString = lineString.getCoordinates();
            if (originalCoordinatesLineString.some((coordinate) => coordinatesAreEqual(coordinate, selectedCoordinate))) {
                const filteredCoordinates = originalCoordinatesLineString.filter((coordinate) => !coordinatesAreEqual(coordinate, selectedCoordinate));
                if (filteredCoordinates.length > 1) {
                    lineString.setCoordinates(filteredCoordinates);
                }
                else {
                    this.targetSource.removeFeature(feature);
                    this.modifyOverlay.getSource()?.clear();
                    this.highlightedFeature = undefined;
                }
            }
        }
        else if (feature.getGeometry() instanceof Polygon$1) {
            const polygon = feature.getGeometry();
            const originalCoordinatesPolygon = polygon.getCoordinates()[0];
            if (originalCoordinatesPolygon.some((coordinate) => coordinatesAreEqual(coordinate, selectedCoordinate))) {
                const filteredCoordinates = originalCoordinatesPolygon.filter((coordinate) => !coordinatesAreEqual(coordinate, selectedCoordinate));
                if (filteredCoordinates.length > 2) {
                    const first = filteredCoordinates[0];
                    const last = filteredCoordinates.at(-1);
                    if (last && !coordinatesAreEqual(first, last)) {
                        filteredCoordinates.push([...first]);
                    }
                    polygon.setCoordinates([filteredCoordinates]);
                }
                if (filteredCoordinates.length <= 3) {
                    this.targetSource.removeFeature(feature);
                    this.modifyOverlay.getSource()?.clear();
                    this.highlightedFeature = undefined;
                }
            }
        }
        this.placeSelectedPoint();
        this.getNewHightlightedFeature();
    }
    cleanup() {
        super.cleanup();
        this.finishModify();
        const map = this.getMap();
        if (map) {
            map.removeLayer(this.selectedPointOverlay);
            map.removeLayer(this.modifyOverlay);
        }
        globalThis.removeEventListener("keypress", this.handleKeyPress);
    }
    updateCenterPoint() {
        super.updateCenterPoint();
        if (this.sketchFeature) {
            switch (this.sketchFeature?.getGeometry().getType()) {
                case "Point":
                    this.updatePoint();
                    break;
                case "LineString":
                    this.updateLineString(this.sketchFeature?.getGeometry());
                    break;
                case "Polygon":
                    this.updatePolygon(this.sketchFeature?.getGeometry());
                    break;
            }
        }
        this.updateHighlightSelection();
        this.placeSelectedPoint();
    }
    getClosestFeatureCoordinate(features, coordinate, pixelTolerance = 6) {
        const closestVertex = getClosestVertex(features, coordinate);
        if (closestVertex &&
            this.calculatePixelDistanceOfCoordinates(closestVertex.coordinate, coordinate) < pixelTolerance) {
            return closestVertex;
        }
        const closestSegmentCoordinate = getClosestSegmentCoordinate(features, coordinate);
        if (closestSegmentCoordinate &&
            this.calculatePixelDistanceOfCoordinates(closestSegmentCoordinate.coordinate, coordinate) < pixelTolerance) {
            return closestSegmentCoordinate;
        }
        return undefined;
    }
    getFeatureAtCoordinateWithTolerance(features) {
        const map = this.getMap();
        if (!map) {
            console.warn("geen map gevonden voor feature");
            return undefined;
        }
        const centerCoordinates = this.centerPoint.getCoordinates();
        // Get first the closest feature and if none in the pixel tolerance, check if a feature intersects the coordinate
        // With this order, a line under a polygon can still be selected
        const closestFeature = this.getClosestFeatureCoordinate(features, centerCoordinates, this.pixelTolerance)?.feature;
        if (closestFeature) {
            return closestFeature;
        }
        for (const feature of features) {
            if (intersectsCoordinate(feature, centerCoordinates)) {
                return feature;
            }
        }
        return undefined;
    }
    updateHighlightSelection() {
        const newHighlightedFeature = this.getNewHightlightedFeature();
        if (this.highlightedFeature != newHighlightedFeature) {
            // reset the current coordinate index for tabbing between the feature points
            this.selectedFeatureCurrentCoordinateIndex = undefined;
        }
        this.highlightedFeature = newHighlightedFeature;
        const source = this.modifyOverlay.getSource();
        if (!source) {
            return;
        }
        source.clear();
        if (this.highlightedFeature) {
            source.addFeature(new Feature(this.highlightedFeature.getGeometry()));
        }
    }
    getNewHightlightedFeature() {
        // If modify is active, return modified feature
        if (this.sketchFeature) {
            return this.sketchFeature;
        }
        // If current selected feature is still within pixelTolerance, prioritize currently selected feature
        if (this.highlightedFeature &&
            this.getClosestFeatureCoordinate([this.highlightedFeature], this.centerPoint.getCoordinates(), this.pixelTolerance)) {
            return this.highlightedFeature;
        }
        // Else return closest feature for highlighting
        return this.getFeatureAtCoordinateWithTolerance([
            ...this.targetSource.getFeatures(),
            ...(this.modifyOverlay.getSource()?.getFeatures() ?? [])
        ]);
    }
    updatePoint() {
        const center = this.getMap()?.getView().getCenter();
        if (center) {
            this.sketchFeature?.setGeometry(new Point(center));
        }
    }
    updateLineString(geometry) {
        const coords = geometry.getCoordinates();
        const center = this.getMap()?.getView().getCenter();
        if (this.modifiedIndex !== undefined) {
            coords.splice(this.modifiedIndex, 1, center);
        }
        geometry.setCoordinates(coords);
    }
    updatePolygon(geometry) {
        const coords = geometry.getCoordinates()[0];
        const center = this.getMap()?.getView().getCenter();
        if (this.modifiedIndex !== undefined) {
            coords.splice(this.modifiedIndex, 1, center);
            if (this.modifiedIndex == 0) {
                // First and last coordinate of a polygon should be the same
                coords.splice(-1, 1, center);
            }
        }
        geometry.setCoordinates([coords]);
    }
    /**
     * Return the coordiante-index of the provided coordinate in the feature, returns undefined if the coordinate is not on the feature.
     * If the coordinate is on a segment instead of an existing vertex, a new vertex is inserted and that newly created index is returned.
     * If the feature is a point, undefined is returned, as a point does not have indices.
     * @param feature
     * @param coordinate
     * @private
     */
    coordinateOfFeatureToIndex(feature, coordinate) {
        const geometry = feature.getGeometry();
        if (!geometry || geometry.getType() == "Point") {
            return undefined;
        }
        const coordinateInFeature = isCoordinateInFeature(feature, coordinate);
        switch (coordinateInFeature) {
            case "vertex": {
                const coordinates = getCoordinatesOfFeature(feature);
                const result = coordinates.findIndex((c) => {
                    return coordinatesAreEqual(coordinate, c);
                });
                return result == -1 ? undefined : result;
            }
            case "segment": {
                return this.insertCoordinateInFeature(feature, coordinate);
            }
            default:
                return undefined;
        }
    }
    /**
     * Insert the provided coordinate as a new vertex inside an existing segment in the feature.
     * Return the index where it is inserted in the feature.
     * If no valid coordinate is provided or the feature is a point, undefined is returned.
     * @param feature
     * @param coordinate
     * @private
     */
    insertCoordinateInFeature(feature, coordinate) {
        const geometry = feature.getGeometry();
        if (!geometry || geometry.getType() == "Point") {
            return undefined;
        }
        const featureCoordinates = getCoordinatesOfFeature(feature);
        for (let i = 0; i < featureCoordinates.length - 1; i++) {
            if (coordinateIsOnSegment(featureCoordinates[i], featureCoordinates[i + 1], coordinate)) {
                featureCoordinates.splice(i + 1, 0, coordinate);
                if (geometry.getType() == "LineString") {
                    geometry.setCoordinates(featureCoordinates);
                }
                else if (geometry.getType() == "Polygon") {
                    geometry.setCoordinates([featureCoordinates]);
                }
                return i + 1;
            }
        }
        return undefined;
    }
    abortModifying() {
        const sketchFeature = this.sketchFeature;
        this.sketchFeature = undefined;
        this.modifyOverlay.getSource().clear(true);
        return sketchFeature;
    }
    placeSelectedPoint() {
        const source = this.selectedPointOverlay.getSource();
        if (!source) {
            return;
        }
        source.clear();
        if (!this.highlightedFeature) {
            return;
        }
        const coordinate = this.getClosestFeatureCoordinate([this.highlightedFeature], this.centerPoint.getCoordinates(), this.pixelTolerance)?.coordinate;
        if (coordinate) {
            const pointFeature = new Feature(new Point(coordinate));
            source.addFeature(pointFeature);
        }
    }
    updateNextTabCoordinate() {
        const coordinatesLength = getCoordinatesOfFeatureWithMiddlePoints(this.highlightedFeature).length;
        const newIndex = this.selectedFeatureCurrentCoordinateIndex == undefined
            ? 0
            : this.selectedFeatureCurrentCoordinateIndex + 1;
        this.selectedFeatureCurrentCoordinateIndex =
            newIndex >= coordinatesLength ? 0 : newIndex;
    }
    updatePreviousTabCoordinate() {
        const coordinatesLength = getCoordinatesOfFeatureWithMiddlePoints(this.highlightedFeature).length;
        const newIndex = this.selectedFeatureCurrentCoordinateIndex == undefined
            ? coordinatesLength - 1
            : this.selectedFeatureCurrentCoordinateIndex - 1;
        this.selectedFeatureCurrentCoordinateIndex =
            newIndex <= -1 ? coordinatesLength - 1 : newIndex;
    }
    getCurrentTabCoordinate() {
        if (!this.highlightedFeature ||
            this.selectedFeatureCurrentCoordinateIndex == undefined) {
            return;
        }
        const coordinates = getCoordinatesOfFeatureWithMiddlePoints(this.highlightedFeature);
        return coordinates.at(this.selectedFeatureCurrentCoordinateIndex);
    }
    setOptionalCustomKeys(options) {
        if (options.customKeyNextPoint) {
            this.keyNextPoint = options.customKeyNextPoint;
        }
        if (options.customKeyPrevPoint) {
            this.keyPrevPoint = options.customKeyPrevPoint;
        }
    }
}

class CoreDrawService {
    constructor() {
        this.MIN_POINTS_LINE_STRING = 2;
        this.MIN_POINTS_POLYGON = 3;
        this.drawInteractions = new Map();
        this.coreMapService = inject(CoreMapService);
        this.coreDrawValidationService = inject(CoreDrawValidationService);
        this.measureDrawStyleService = inject(CoreMeasureDrawStyleService);
        this.coreDrawLayerService = inject(CoreDrawLayerService);
        this.coreSnapService = inject(CoreSnapService);
        this.modifyInteractions = new Map();
        this.moveInteractions = new Map();
        this.validLineStringOrPolygon = false;
        this.drawEventsMap = new ObservableMapWrapper(() => new Subject());
        this.modifyEventsMap = new ObservableMapWrapper(() => new Subject());
        this.drawEndListenerMap = new Map();
        this.drawStyleMap = new Map();
        this.modifyListenersMap = new Map();
        this.moveListenersMap = new Map();
    }
    startCenterInteraction(mapIndex, croshairStyle) {
        const activeCenterBase = new CenterBase({
            crossHairStyle: croshairStyle
        });
        this.coreMapService.getMap(mapIndex).addInteraction(activeCenterBase);
    }
    startCenterModify(layerName, mapIndex, options) {
        this.removeActiveCenterInteraction(mapIndex);
        const targetSource = this.coreDrawLayerService
            .getDrawLayer(layerName, mapIndex)
            .getSource();
        options = {
            targetSource: targetSource,
            crossHairStyle: this.decideAndGetStyles(layerName, mapIndex, "Polygon", {}, true)?.crossHairStyle,
            ...options
        };
        const centerModify = new CenterModify(options);
        this.activeCenterInteraction = centerModify;
        const map = this.coreMapService.getMap(mapIndex);
        map.addInteraction(centerModify);
        this.modifyInteractions.set(mapIndex, centerModify);
        return centerModify;
    }
    startCenterModifyCurrentPoint() {
        if (this.activeCenterInteraction instanceof CenterModify) {
            this.activeCenterInteraction.startModifyCurrentPoint();
        }
    }
    stopCenterModifyCurrentPoint() {
        if (this.activeCenterInteraction instanceof CenterModify) {
            this.activeCenterInteraction.finishModify();
        }
    }
    removeCenterModifyCurrentPoint() {
        if (this.activeCenterInteraction instanceof CenterModify) {
            this.activeCenterInteraction.removeModifyCurrentPoint();
        }
    }
    removeActiveCenterInteraction(mapIndex) {
        if (this.activeCenterInteraction) {
            this.activeCenterInteraction.cleanup();
            const map = this.coreMapService.getMap(mapIndex);
            map.removeInteraction(this.activeCenterInteraction);
        }
    }
    addFeatureToLayer(layerName, mapIndex, feature) {
        const exists = this.coreMapService.checkMapIndex(mapIndex);
        if (exists) {
            if (feature.getStyle() === undefined || feature.getStyle() === null) {
                this.addStylingToFeature(layerName, mapIndex, feature);
            }
            const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
            layer.getSource().addFeature(feature);
        }
        return this.coreMapService.decideMapComponentEventType(exists, mapIndex);
    }
    removeFeatureFromLayer(layerName, mapIndex, feature) {
        const exists = this.coreMapService.checkMapIndex(mapIndex);
        if (exists) {
            const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
            layer.getSource().removeFeature(feature);
        }
    }
    appendCoordinates(coordinates, mapIndex) {
        const mapIndexExists = this.coreMapService.checkMapIndex(mapIndex);
        if (mapIndexExists) {
            const drawInteraction = this.drawInteractions.get(mapIndex);
            if (drawInteraction) {
                drawInteraction.appendCoordinates([coordinates]);
            }
        }
    }
    removeLastPoint(mapIndex) {
        const mapIndexExists = this.coreMapService.checkMapIndex(mapIndex);
        if (mapIndexExists) {
            const drawInteraction = this.drawInteractions.get(mapIndex);
            if (drawInteraction) {
                drawInteraction.removeLastPoint();
            }
        }
    }
    getSketchCoordinates(mapIndex) {
        const mapIndexExists = this.coreMapService.checkMapIndex(mapIndex);
        if (mapIndexExists) {
            const drawInteraction = this.drawInteractions.get(mapIndex);
            if (drawInteraction && drawInteraction instanceof CenterDraw) {
                return drawInteraction.getSketchCoordinates();
            }
        }
        else {
            return;
        }
    }
    clearLayer(layerName, mapIndex) {
        const exists = this.coreMapService.checkMapIndex(mapIndex);
        if (exists) {
            const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
            layer.getSource().clear();
        }
        return this.coreMapService.decideMapComponentEventType(exists, mapIndex);
    }
    deleteDrawInteraction(mapIndex) {
        const map = this.coreMapService.getMap(mapIndex);
        if (this.drawInteractions.has(mapIndex)) {
            map.removeInteraction(this.drawInteractions.get(mapIndex));
        }
        this.drawInteractions.delete(mapIndex);
    }
    deleteLayers(mapIndex) {
        this.stopDraw(mapIndex);
        this.stopModify(mapIndex);
        const prefix = `${mapIndex}-`;
        this.coreSnapService.stopSnap(mapIndex);
        this.coreDrawLayerService.getDrawLayers().forEach((_layer, key) => {
            if (key.startsWith(prefix)) {
                this.deleteLayer(key.slice(prefix.length), mapIndex);
            }
        });
    }
    deleteLayer(layerName, mapIndex) {
        this.stopDraw(mapIndex);
        this.stopModify(mapIndex);
        this.coreSnapService.stopSnap(mapIndex);
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        layer.setMap(null);
        this.coreDrawLayerService
            .getDrawLayers()
            .delete(`${mapIndex}-${layerName}`);
    }
    finishCurrentDraw(mapIndex) {
        const drawInteraction = this.drawInteractions.get(mapIndex);
        if (drawInteraction && this.validLineStringOrPolygon) {
            drawInteraction.finishDrawing();
        }
    }
    getDrawObservable(mapIndex) {
        return this.drawEventsMap.getOrCreateObservable(mapIndex);
    }
    getModifyEventsObservable(mapIndex) {
        return this.modifyEventsMap.getOrCreateObservable(mapIndex);
    }
    setDrawStyle(layerName, mapIndex, drawStyle) {
        this.drawStyleMap.set(`${mapIndex}-${layerName}`, drawStyle);
    }
    setLayerZIndex(layerName, mapIndex, index) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        layer.setZIndex(index);
        layer.changed();
    }
    startDraw(layerName, mapIndex, drawType, drawOptions = {}) {
        this.stopDraw(mapIndex);
        this.stopMove(mapIndex);
        this.setLayerVisibility(layerName, mapIndex, true);
        this.drawEventsMap.getOrCreateObservable(mapIndex);
        const geometryType = drawTypeToGeometryType(drawType);
        const selectedStyle = this.decideAndGetStyles(layerName, mapIndex, geometryType, drawOptions);
        const drawInteraction = this.getDrawInteraction(layerName, mapIndex, drawType, selectedStyle, drawOptions);
        drawInteraction.on("drawstart", (event) => {
            this.drawEventsMap
                .getOrCreateSubject(mapIndex)
                .next(new DrawInteractionEvent(DrawInteractionEventTypes.DRAWSTART, drawType, mapIndex, `DrawStart on ${layerName}`, event));
            if (drawOptions.validators) {
                this.coreDrawValidationService.addValidators(mapIndex, event.feature, drawOptions.validators, selectedStyle);
            }
            const geom = event.feature.getGeometry();
            if (geom) {
                geom.on("change", () => {
                    this.validLineStringOrPolygon = this.isValidOnFinishByMethod(event.feature);
                });
            }
        });
        const id = drawInteraction.on("drawend", (event) => {
            if (selectedStyle) {
                event.feature.setStyle(selectedStyle.finishDrawStyle);
            }
            const valid = this.coreDrawValidationService.checkAndRemoveValidators(mapIndex);
            const areaOrLength = calculateAreaOrLength(event.feature);
            event.feature.setProperties({
                areaOrLength,
                measurement: this.getDrawType(drawOptions)
            });
            this.drawEventsMap
                .getOrCreateSubject(mapIndex)
                .next(new DrawInteractionEvent(DrawInteractionEventTypes.DRAWEND, drawType, mapIndex, `DrawEnd on ${layerName}`, event, valid, areaOrLength));
        });
        this.drawEndListenerMap.set(mapIndex, id);
        this.coreSnapService.startSnapAgainIfExists(layerName, mapIndex);
    }
    // Segments are not supported yet and polygon has only area.
    getDrawType(options) {
        if (options.showArea !== undefined && options.showArea) {
            return "area";
        }
        else if (options.showTotalLength !== undefined &&
            options.showTotalLength) {
            return "length";
        }
        else {
            return "none";
        }
    }
    startModify(layerName, mapIndex, drawOptions, deleteCondition = never, insertVertexCondition = never) {
        this.stopModify(mapIndex);
        this.stopMove(mapIndex);
        this.setLayerVisibility(layerName, mapIndex, true);
        const source = this.coreDrawLayerService
            .getDrawLayer(layerName, mapIndex)
            .getSource();
        const modify = new Modify({
            source,
            deleteCondition: deleteCondition,
            insertVertexCondition: insertVertexCondition
        });
        const map = this.coreMapService.getMap(mapIndex);
        map.addInteraction(modify);
        this.modifyInteractions.set(mapIndex, modify);
        const modifyEventSubject = this.modifyEventsMap.getOrCreateSubject(mapIndex);
        const eventsKeys = [];
        const validators = drawOptions?.validators || [];
        if (validators.length > 0) {
            eventsKeys.push(modify.on("modifystart", (event) => {
                event.features.forEach((feature) => {
                    const selectedStyle = this.decideAndGetStyles(layerName, mapIndex, feature.getGeometry().getType(), drawOptions, true);
                    this.coreDrawValidationService.addValidators(mapIndex, feature, validators, selectedStyle);
                });
            }));
        }
        eventsKeys.push(modify.on("modifyend", (event) => {
            if (event.features) {
                event.features.forEach((feature) => {
                    const areaOrLength = calculateAreaOrLength(feature);
                    feature.set("areaOrLength", areaOrLength);
                });
            }
            modifyEventSubject.next(new ModifyInteractionEvent(ModifyInteractionEventTypes.MODIFYEND, mapIndex, `bewerken ${layerName}`, event, this.coreDrawValidationService.checkAndRemoveValidators(mapIndex)));
        }));
        this.modifyListenersMap.set(mapIndex, eventsKeys);
        this.coreSnapService.startSnapAgainIfExists(layerName, mapIndex);
    }
    startMove(layerName, mapIndex, drawOptions = {}) {
        const map = this.coreMapService.getMap(mapIndex);
        const drawLayer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        // source.
        this.stopModify(mapIndex);
        this.stopDraw(mapIndex);
        this.stopMove(mapIndex);
        const features = new Collection();
        const move = new Translate({ features });
        const modifyEventSubject = this.modifyEventsMap.getOrCreateSubject(mapIndex);
        let selected;
        let isTranslating = false;
        this.moveInteractions.set(mapIndex, move);
        map.addInteraction(move);
        const eventsKeys = [];
        eventsKeys.push(move.on("translatestart", () => {
            isTranslating = true;
            map.getViewport().style.cursor = "grabbing";
            if (drawOptions.validators) {
                const selectedStyle = this.decideAndGetStyles(layerName, mapIndex, selected.getGeometry().getType(), drawOptions);
                this.coreDrawValidationService.addValidators(mapIndex, selected, drawOptions.validators, selectedStyle);
            }
        }), move.on("translateend", (event) => {
            isTranslating = false;
            map.getViewport().style.cursor = "grab";
            modifyEventSubject.next(new ModifyInteractionEvent(ModifyInteractionEventTypes.MOVEEND, mapIndex, `verplaatsen feature op ${layerName}`, event, this.coreDrawValidationService.checkAndRemoveValidators(mapIndex)));
        }), map.on("pointermove", (evt) => {
            if (isTranslating) {
                return;
            }
            let onFeature = false;
            map.forEachFeatureAtPixel(evt.pixel, (feat) => {
                onFeature = true;
                selected = feat;
                map.getViewport().style.cursor = "grab";
                return true;
            }, { layerFilter: (layer) => layer === drawLayer });
            features.clear();
            if (onFeature) {
                if (selected) {
                    features.push(selected);
                }
            }
            else {
                selected = undefined;
                map.getViewport().style.cursor = "";
            }
        }));
        this.moveListenersMap.set(mapIndex, eventsKeys);
    }
    stopDraw(mapIndex) {
        const interaction = this.drawInteractions.get(mapIndex);
        if (interaction) {
            unByKey(this.drawEndListenerMap.get(mapIndex));
            this.drawEndListenerMap.delete(mapIndex);
            this.deleteDrawInteraction(mapIndex);
        }
    }
    stopModify(mapIndex) {
        const interaction = this.modifyInteractions.get(mapIndex);
        if (interaction) {
            unByKey(this.modifyListenersMap.get(mapIndex));
            this.modifyListenersMap.delete(mapIndex);
            this.modifyInteractions.delete(mapIndex);
            if (interaction instanceof CenterModify) {
                interaction.finishModify();
            }
            this.coreMapService.getMap(mapIndex).removeInteraction(interaction);
        }
    }
    stopMove(mapIndex) {
        const interaction = this.moveInteractions.get(mapIndex);
        if (interaction) {
            unByKey(this.moveListenersMap.get(mapIndex));
            this.moveListenersMap.delete(mapIndex);
            this.moveInteractions.delete(mapIndex);
            this.coreMapService.getMap(mapIndex).removeInteraction(interaction);
        }
    }
    setLayerVisibility(layerName, mapIndex, visible) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        layer.setVisible(visible);
        layer.changed();
    }
    toggleLayer(layerName, mapIndex) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        layer.setVisible(!layer.getVisible());
        layer.changed();
    }
    resetDrawStyle(layerName, mapIndex, drawOptions) {
        this.stopDraw(mapIndex);
        // Style de afgeronde tekeningen
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        const features = layer.getSource()?.getFeatures() ?? [];
        features.forEach((feature) => {
            const styles = this.decideAndGetStyles(layerName, mapIndex, feature.getGeometry().getType(), drawOptions);
            // bepaal validatie status
            const isValid = drawOptions.validators?.length
                ? new DrawValidator(feature, drawOptions.validators).validate(feature)
                : true;
            feature.setStyle(isValid ? styles?.finishDrawStyle : styles?.invalidFinishDrawStyle);
        });
    }
    decideAndGetStyles(layerName, mapIndex, measureType, drawOptions, modifying = false) {
        return this.measureDrawStyleService.getMeasureStyle(measureType, drawOptions, this.drawStyleMap.get(`${mapIndex}-${layerName}`), modifying);
    }
    getDrawInteraction(layerName, mapIndex, drawType, styleLikeMap, options) {
        if (!this.drawInteractions.has(mapIndex)) {
            let drawInteraction;
            let geometryFunction;
            let geometryType;
            switch (drawType) {
                case MapComponentDrawTypes.RECTANGLE:
                    // type Circle and geometryFunction createBox() enables drawing rectangles (default Openlayers)
                    geometryFunction = createBox;
                    geometryType = "Circle";
                    break;
                case MapComponentDrawTypes.POLYGON:
                    geometryType = "Polygon";
                    break;
                case MapComponentDrawTypes.LINESTRING:
                    geometryType = "LineString";
                    break;
                case MapComponentDrawTypes.POINT:
                    geometryType = "Point";
                    break;
                case MapComponentDrawTypes.CIRCLE:
                    geometryType = "Circle";
                    break;
                default:
                    throw new Error("Unknown draw type");
            }
            // Validatie of LineString uit minimaal 2 en Polygon 3 punten bestaat
            let currentSketch = null;
            options = {
                ...options,
                finishCondition: () => {
                    return this.isValidOnFinishByDoubleClick(currentSketch);
                }
            };
            if (geometryType) {
                drawInteraction = this.createDrawObject(layerName, mapIndex, geometryType, styleLikeMap, options, geometryFunction ? geometryFunction() : undefined);
                // currentSketch vullen met huidige actieve Draw tekening
                if (drawInteraction instanceof Draw) {
                    drawInteraction.on("drawstart", (evt) => {
                        currentSketch = evt.feature;
                    });
                    drawInteraction.on("drawend", () => {
                        currentSketch = null;
                    });
                }
                const map = this.coreMapService.getMap(mapIndex);
                map.addInteraction(drawInteraction);
                /* need to snap to tracing layer after
                 * drawInteraction is initiated */
                if (options?.trace) {
                    this.addSnappingForTracing(layerName, mapIndex, options);
                }
                this.drawInteractions.set(mapIndex, drawInteraction);
            }
        }
        return this.drawInteractions.get(mapIndex);
    }
    createDrawObject(layerName, mapIndex, type, styleLikeMap, options, geoFunction) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex, styleLikeMap?.finishDrawStyle);
        const source = layer.getSource();
        let drawOptions = {
            ...options,
            source,
            type,
            stopClick: true,
            geometryFunction: geoFunction
        };
        // voeg tracing toe
        if (options?.trace && options?.traceSourceId) {
            const traceSourceLayer = this.coreMapService.getLayer(options?.traceSourceId, mapIndex);
            if (traceSourceLayer) {
                drawOptions = {
                    ...drawOptions,
                    trace: options.trace,
                    traceSource: traceSourceLayer.getSource()
                };
            }
        }
        if (styleLikeMap) {
            drawOptions.style = styleLikeMap.drawingDrawStyle;
        }
        if (options?.centerDraw) {
            const centerDrawOptions = {
                ...drawOptions,
                crossHairStyle: styleLikeMap?.crossHairStyle
            };
            const centerDraw = new CenterDraw(centerDrawOptions);
            this.removeActiveCenterInteraction(mapIndex);
            this.activeCenterInteraction = centerDraw;
            return centerDraw;
        }
        return new Draw(drawOptions);
    }
    isValidOnFinishByMethod(currentSketch) {
        if (!currentSketch)
            return false;
        const geom = currentSketch.getGeometry();
        if (geom instanceof LineString$1) {
            const placedCoordinates = new Set(geom
                .getCoordinates()
                .slice(0, -1)
                .map((c) => JSON.stringify(c)));
            return placedCoordinates.size >= this.MIN_POINTS_LINE_STRING; // -1, want tijdens tekenen is muispositie extra point
        }
        if (geom instanceof Polygon$1) {
            const placedCoordinates = new Set(geom
                .getCoordinates()[0]
                .slice(0, -2)
                .map((c) => JSON.stringify(c)));
            return placedCoordinates.size >= this.MIN_POINTS_POLYGON; // -1, want tijdens tekenen is muispositie extra point
        }
        return true;
    }
    isValidOnFinishByDoubleClick(currentSketch) {
        if (!currentSketch)
            return false;
        const geom = currentSketch.getGeometry();
        if (geom instanceof LineString$1) {
            const placedCoordinates = new Set(geom.getCoordinates().map((c) => JSON.stringify(c)));
            return placedCoordinates.size >= this.MIN_POINTS_LINE_STRING;
        }
        if (geom instanceof Polygon$1) {
            const placedCoordinates = new Set(geom.getCoordinates()[0].map((c) => JSON.stringify(c)));
            return placedCoordinates.size >= this.MIN_POINTS_POLYGON;
        }
        return true;
    }
    addStylingToFeature(layerName, mapIndex, feature) {
        const styleLikeMap = this.drawStyleMap.get(`${mapIndex}-${layerName}`);
        if (styleLikeMap) {
            feature.setStyle(styleLikeMap.finishDrawStyle);
        }
    }
    addSnappingForTracing(layerId, mapIndex, options) {
        this.coreSnapService.startSnap(layerId, mapIndex, {
            snapLayers: [options.traceSourceId],
            pixelTolerance: options.traceSnapTolerance
                ? options.traceSnapTolerance
                : 6
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreDrawService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Service voor het beheren van teken- en bewerkingsinteracties op de kaart.
 *
 * Deze service biedt methoden voor het starten, stoppen en configureren van
 * teken-, bewerk- en verplaatsingsinteracties, en het beheren van tekenlagen en features.
 */
class GgcDrawService {
    constructor() {
        this.coreDrawService = inject(CoreDrawService);
        this.coreDrawLayerService = inject(CoreDrawLayerService);
    }
    /**
     * Start een interactie met het midden van de kaart (draw of modify),
     * toont een crosshair
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param croshairStyle - Optioneel: een alternatieve stijl voor de crosshair
     */
    startCenterInteraction(mapIndex = DEFAULT_MAPINDEX, croshairStyle) {
        this.coreDrawService.startCenterInteraction(mapIndex, croshairStyle);
    }
    /**
     * Stopt een Centerinteraction, de bestaande center interactie (draw of modify)
     * wordt gestopt en de crosshair verwijderd.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopCenterInteractions(mapIndex = DEFAULT_MAPINDEX) {
        this.stopDraw(mapIndex);
        this.stopModify(mapIndex);
        this.coreDrawService.removeActiveCenterInteraction(mapIndex);
    }
    /**
     * Start het wijzigen van objecten met behulp van het centrum van de kaart.
     *
     * @param layerName - Naam van de laag met de te wijzigen objecten.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param options - Optioneel: options voor:
     *    - de laag,
     *    - de stijl voor het highlighten van objecten,
     *    - de stijl voor het highlighten van een te wijzigen punt van een object
     *    - de toetsenbordknoppen voor het tabben door punten van een object
     */
    startCenterModify(layerName, mapIndex = DEFAULT_MAPINDEX, options) {
        this.coreDrawService.startCenterModify(layerName, mapIndex, options);
    }
    /**
     * Start het wijzigen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    startCenterModifyCurrentPoint() {
        this.coreDrawService.startCenterModifyCurrentPoint();
    }
    /**
     * Stopt het wijzigen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    stopCenterModifyCurrentPoint() {
        this.coreDrawService.stopCenterModifyCurrentPoint();
    }
    /**
     * Verwijderen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    removeCenterModifyCurrentPoint() {
        this.coreDrawService.removeCenterModifyCurrentPoint();
    }
    // einde toetsenbord
    /**
     * Voegt een feature toe aan een bestaande tekenlaag.
     *
     * @param layerName - Naam van de laag waaraan de feature toegevoegd wordt.
     * @param feature - Toe te voegen `ol/Feature`.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `MapComponentEvent` als bevestiging van de toevoeging.
     */
    addFeatureToLayer(layerName, feature, mapIndex = DEFAULT_MAPINDEX) {
        return this.coreDrawService.addFeatureToLayer(layerName, mapIndex, feature);
    }
    removeFeatureFromLayer(layerName, feature, mapIndex = DEFAULT_MAPINDEX) {
        return this.coreDrawService.removeFeatureFromLayer(layerName, mapIndex, feature);
    }
    /**
     * Voegt een coördinaat toe aan de huidige actieve tekening.
     *
     * @param coordinates - Toe te voegen coördinaat.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    appendCoordinates(coordinates, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.appendCoordinates(coordinates, mapIndex);
    }
    /**
     * Verwijdert het laatste toegevoegde punt van de huidige actieve tekening.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    removeLastPoint(mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.removeLastPoint(mapIndex);
    }
    /**
     * Geeft de coördinaten terug van de huidige actieve tekening, exclusief de positie van de cursos.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns Array van `Coordinate` of `undefined` als er geen actieve tekening is.
     */
    getSketchCoordinates(mapIndex = DEFAULT_MAPINDEX) {
        return this.coreDrawService.getSketchCoordinates(mapIndex);
    }
    /**
     * Verwijdert alle features uit de opgegeven laag.
     *
     * @param layerName - Naam van de te legen laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    clearLayer(layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.clearLayer(layerName, mapIndex);
    }
    /**
     * Verwijdert de opgegeven laag van de kaart.
     *
     * @param layerName - Naam van de te verwijderen laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    deleteLayer(layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.deleteLayer(layerName, mapIndex);
    }
    /**
     * Rondt de huidige actieve tekening af.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    finishCurrentDraw(mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.finishCurrentDraw(mapIndex);
    }
    /**
     * Geeft een `Observable` terug met tekeninteractie-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van `DrawInteractionEvent`.
     */
    getDrawEventsObservable(mapIndex = DEFAULT_MAPINDEX) {
        return this.coreDrawService.getDrawObservable(mapIndex);
    }
    /**
     * Geeft een `Observable` terug met bewerkingsinteractie-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van `ModifyInteractionEvent`.
     */
    getModifyEventsObservable(mapIndex = DEFAULT_MAPINDEX) {
        return this.coreDrawService.getModifyEventsObservable(mapIndex);
    }
    /**
     * Haalt alle features op uit de opgegeven tekenlaag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns Array van `Feature<Geometry>`.
     */
    getFeaturesFromLayer(layerName, mapIndex = DEFAULT_MAPINDEX) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        return layer.getSource().getFeatures();
    }
    /**
     * Controleert of de opgegeven laag zichtbaar is.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `true` als de laag zichtbaar is, anders `false`.
     */
    isLayerVisible(layerName, mapIndex = DEFAULT_MAPINDEX) {
        const layer = this.coreDrawLayerService.getDrawLayer(layerName, mapIndex);
        return layer.getVisible();
    }
    /**
     * Stelt de tekenstijl in voor de opgegeven laag.
     *
     * @param layerName - Naam van de laag.
     * @param styleLikeMap - Toe te passen stijl als `StyleLikeMap`.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setDrawStyle(layerName, styleLikeMap, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.setDrawStyle(layerName, mapIndex, styleLikeMap);
    }
    /**
     * Stelt de zichtbaarheid van een laag in.
     *
     * @param layerName - Naam van de laag.
     * @param visible - `true` om de laag zichtbaar te maken, `false` om te verbergen.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setLayerVisibility(layerName, visible, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.setLayerVisibility(layerName, mapIndex, visible);
    }
    /**
     * Stelt de z-index in van de opgegeven laag.
     *
     * @param zIndex - Gewenste z-index waarde.
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setLayerZIndex(zIndex, layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.setLayerZIndex(layerName, mapIndex, zIndex);
    }
    /**
     * Start het tekenen van objecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop getekend wordt.
     * @param drawType - Type tekening (bijv. punt, lijn, polygoon).
     * @param drawOptions - Opties voor de tekeninteractie.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    startDraw(layerName, drawType, drawOptions, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.startDraw(layerName, mapIndex, drawType, drawOptions);
    }
    /**
     * Start het bewerken van opbjecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop bewerkt wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de bewerkingsinteractie. Default: leeg object.
     * @param deleteCondition - Optioneel: ol/Condition om een vertex te verwijderen. Default: never.
     * @param insertVertexCondition - Optioneel: ol/Condition om een vertex in te voegen. Default: never.
     */
    startModify(layerName, mapIndex = DEFAULT_MAPINDEX, drawOptions = {}, deleteCondition, insertVertexCondition) {
        this.coreDrawService.startModify(layerName, mapIndex, drawOptions, deleteCondition, insertVertexCondition);
    }
    /**
     * Start het verplaatsen van objecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop verplaatst wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de verplaatsingsinteractie. Default: leeg object.
     */
    startMove(layerName, mapIndex = DEFAULT_MAPINDEX, drawOptions = {}) {
        this.coreDrawService.startMove(layerName, mapIndex, drawOptions);
    }
    /**
     * Stopt het verplaatsen van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopMove(mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.stopMove(mapIndex);
    }
    /**
     * Stopt het tekenen van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopDraw(mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.stopDraw(mapIndex);
    }
    /**
     * Stopt het tekenen, leegt de laag en verwijdert daarna de laag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopDrawAndClearLayer(layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.stopDraw(mapIndex);
        this.clearLayer(layerName, mapIndex);
        this.coreDrawService.deleteLayer(layerName, mapIndex);
    }
    /**
     * Stopt het bewerken van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopModify(mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.stopModify(mapIndex);
    }
    /**
     * Wisselt de zichtbaarheid van de opgegeven laag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    toggleLayer(layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.coreDrawService.toggleLayer(layerName, mapIndex);
    }
    /**
     * Reset de tekenstijl van de opgegeven laag naar de standaardstijl.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de tekenstijl. Default: leeg object.
     */
    resetDrawStyle(layerName, mapIndex = DEFAULT_MAPINDEX, drawOptions = {}) {
        this.coreDrawService.resetDrawStyle(layerName, mapIndex, drawOptions);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcDrawService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcDrawService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcDrawService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Service voor het beheren van snap-interacties op de kaart.
 *
 * Deze service biedt methoden voor het starten en stoppen van snap-interacties,
 * en het ophalen van snap-events.
 */
class GgcSnapService {
    constructor() {
        this.coreSnapService = inject(CoreSnapService);
    }
    /**
     * Start snappen op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop gesnapped wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param snapOptions - Opties voor de snap-interactie. Default: leeg object.
     */
    startSnap(layerName, mapIndex = DEFAULT_MAPINDEX, snapOptions = {}) {
        this.coreSnapService.startSnap(layerName, mapIndex, snapOptions);
    }
    /**
     * Stopt snappen.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopSnap(mapIndex = DEFAULT_MAPINDEX) {
        this.coreSnapService.stopSnap(mapIndex);
    }
    /**
     * Geeft een `Observable` terug met uitgebreide snap-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van snap-events.
     */
    getSnapExtendedEventsObservable(mapIndex = DEFAULT_MAPINDEX) {
        return this.coreSnapService.getSnapExtendedEventsObservable(mapIndex);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSnapService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSnapService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSnapService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * @deprecated verhuisd naar models
 * Mogelijke types voor kaartevents.
 *
 * Deze enum wordt gebruikt in {@link MapComponentEvent} om het type
 * gebeurtenis eenduidig te identificeren, zoals zoomacties,
 * klikinteracties en selection-updates.
 */
var MapComponentEventTypes;
(function (MapComponentEventTypes) {
    /** Kaart is succesvol geïnitialiseerd */
    MapComponentEventTypes["MAPINITIALIZED"] = "mapInitialized";
    /** Zoomactie is beëindigd */
    MapComponentEventTypes["ZOOMEND"] = "zoomEnd";
    /** Zoomactie naar een specifieke locatie is beëindigd */
    MapComponentEventTypes["ZOOMENDLOCATION"] = "zoomEndLocation";
    /** Enkelvoudige klik op de kaart */
    MapComponentEventTypes["SINGLECLICK"] = "singleClick";
    /** WMS capabilities zijn opgehaald */
    MapComponentEventTypes["WMSCAPABILITIES"] = "WmsCapabilities";
    /** WMS feature-informatie is opgehaald */
    MapComponentEventTypes["WMSFEATUREINFO"] = "WmsFeatureInfo";
    /** WMTS capabilities zijn opgehaald */
    MapComponentEventTypes["WMTSCAPABILITES"] = "WmtsCapabilites";
    /** WMTS feature-informatie is opgehaald*/
    MapComponentEventTypes["WMTSFEATUREINFO"] = "WmtsFeatureInfo";
    /** feature-informatie van een vector laag is opgehaald*/
    MapComponentEventTypes["VECTORFEATUREINFO"] = "vectorFeatureInfo";
    /** feature-informatie van een GeoJson vector laag is opgehaald*/
    MapComponentEventTypes["GEOJSONFEATUREINFO"] = "geoJsonFeatureInfo";
    /** Actie is succesvol uitgevoerd */
    MapComponentEventTypes["SUCCESSFUL"] = "successful";
    /** Actie is niet succesvol uitgevoerd */
    MapComponentEventTypes["UNSUCCESSFUL"] = "unsuccessful";
    /** Kaart of laag is aan het laden */
    MapComponentEventTypes["LOADING"] = "loading";
    /** Kaartklik afkomstig van de selection service */
    MapComponentEventTypes["SELECTIONSERVICE_MAPCLICKED"] = "selectionServiceMapClicked";
    /** Selection service heeft de selectie gewist */
    MapComponentEventTypes["SELECTIONSERVICE_CLEARSELECTION"] = "selectionServiceClearSelection";
    /** Selection service heeft een nieuwe selectie gezet */
    MapComponentEventTypes["SELECTIONSERVICE_SELECTIONUPDATED"] = "selectionServiceSelectionUpdated";
})(MapComponentEventTypes || (MapComponentEventTypes = {}));
/**
 * @deprecated verhuisd naar models
 * Standaard event-object voor communicatie vanuit kaartcomponenten
 * en kaartservices.
 *
 * Wordt gebruikt om kaartinteracties, statusupdates en resultaten
 * eenduidig door te geven aan afnemende componenten.
 */
class MapComponentEvent {
    /**
     *
     * Maakt een nieuw MapComponentEvent aan.
     *
     * @param type Type van het event (zie MapComponentEventTypes)
     * @param mapIndex Index of naam van de kaart waarop het event betrekking heeft
     * @param message Beschrijvende tekst van het event (het zoomen is beeindingd, ...)
     * @param layerName (optioneel) Naam van de laag die het event heeft veroorzaakt
     * @param value (optioneel) het oorspronkelijke event indien aanwezig
     */
    constructor(type, mapIndex, message, layerName, value) {
        this.type = type;
        this.mapIndex = mapIndex;
        this.message = message;
        this.layerName = layerName;
        this.value = value;
    }
}
/**
 * @deprecated
 * Beschrijft de huidige status van een kaartview.
 *
 * Wordt gebruikt om de centrering en het zoomniveau van een kaart
 * vast te leggen of te herstellen.
 */
class MapViewState {
    constructor(center, zoom) {
        this.center = center;
        this.zoom = zoom;
    }
}

/**
 * Beschrijft de mogelijke selectiemodi voor het selecteren
 * van objecten op de kaart.
 */
var SelectionModeTypes;
(function (SelectionModeTypes) {
    /** Selectie van één enkel object tegelijk */
    SelectionModeTypes["SINGLE_SELECT"] = "singleselect";
    /** Selectie van meerdere objecten tegelijk */
    SelectionModeTypes["MULTI_SELECT"] = "multiselect";
})(SelectionModeTypes || (SelectionModeTypes = {}));

class CoreSelectionService {
    static { this.messageClearSelection = "Selectie is gewist"; }
    static { this.messageMapClicked = "Er is geklikt in de kaart en de feature info wordt opgehaald."; }
    static { this.messageSelectionUpdated = "Nieuwe feature info van een kaartlaag toegevoegd aan de selectie."; }
    static { this.messageCoordinateDoesNotMatch = "Er is iets mis gegaan in de CoreSelectionService: het coordinaat van de kaartlaag komt" +
        " niet overeen met het verwachte coordinaat van het klik-event in de kaart."; }
    constructor() {
        this.subjectSelectEvents = new Subject();
        this.activeSelectInteractions = new Map();
        this.activeMapClickEventsKeys = new Map();
        this.activeSelectEventsKeys = new Map();
        this.GGC_LAYER_IDS = "ggc-layerIds";
        this.GGC_SELECT_MODE = "ggc-select-mode";
        this.ggcMapService = inject(GgcMapService);
        this.coreMapService = inject(CoreMapService);
        this.coreMapService.getLayerChangedObservable().subscribe((event) => {
            if (event.eventTrigger === LayerChangedEventTrigger.LAYER_REMOVED) {
                this.clearAllSelectionsForMapIndex(event.mapIndex);
            }
        });
    }
    getObservableForMap(mapIndex, selectIndex) {
        return this.subjectSelectEvents
            .asObservable()
            .pipe(filter((event) => event.mapIndex === mapIndex &&
            (!selectIndex || event.selectIndex === selectIndex)));
    }
    startSelect(options, mapIndex, selectIndex) {
        selectIndex = selectIndex ?? mapIndex;
        this.stopSelect(selectIndex);
        const map = this.ggcMapService.getMap(mapIndex);
        let condition;
        let toggleCondition;
        switch (options.selectMode) {
            case "multi":
                condition = options.condition ?? singleClick;
                toggleCondition = options.condition ?? singleClick;
                break;
            case "openlayersDefault":
                break;
            case "single":
            default:
                condition = options.condition ?? singleClick;
                toggleCondition = never;
                break;
        }
        const filterFunction = this.createSelectionFilterFunction(options.layerIds);
        const select = new Select({
            condition,
            toggleCondition,
            filter: filterFunction,
            // Visibility is handled in the selection layer, not the select interaction
            style: null,
            hitTolerance: options.hitTolerance,
            multi: true
        });
        select.set(this.GGC_LAYER_IDS, options.layerIds);
        select.set(this.GGC_SELECT_MODE, options.selectMode ?? "single");
        map.addInteraction(select);
        this.activeSelectInteractions.set(selectIndex, { mapIndex, select });
        this.coreMapService.addSelectLayer(mapIndex, selectIndex);
        this.connectSelectEvents(select, selectIndex, mapIndex);
        if (options.style !== undefined) {
            this.ggcMapService.changeSelectionLayerStyle(options.style, mapIndex, selectIndex);
        }
    }
    stopSelect(selectIndex) {
        const activeSelectInteraction = this.getActiveSelectInteraction(selectIndex);
        if (!activeSelectInteraction) {
            return;
        }
        const map = this.ggcMapService.getMap(activeSelectInteraction.mapIndex);
        if (!map) {
            return;
        }
        const select = activeSelectInteraction.select;
        // trigger selection updated
        select.clearSelection();
        map.removeInteraction(select);
        this.activeSelectInteractions.delete(selectIndex);
        const selectEvent = this.activeSelectEventsKeys.get(selectIndex);
        if (selectEvent) {
            select.un("select", selectEvent);
        }
        this.activeSelectEventsKeys.delete(selectIndex);
        const mapClickEvent = this.activeMapClickEventsKeys.get(selectIndex);
        if (mapClickEvent) {
            map.un("singleclick", mapClickEvent);
        }
        this.activeMapClickEventsKeys.delete(selectIndex);
        this.ggcMapService.clearSelectionLayer(activeSelectInteraction.mapIndex, selectIndex);
        if (selectIndex) {
            this.coreMapService.removeSelectLayer(activeSelectInteraction.mapIndex, selectIndex);
        }
    }
    clearSelection(mapIndex, selectIndex) {
        const activeSelectInteraction = this.getActiveSelectInteraction(selectIndex ?? mapIndex);
        if (!activeSelectInteraction) {
            return;
        }
        activeSelectInteraction.select.clearSelection();
        this.ggcMapService.clearSelectionLayer(mapIndex, selectIndex);
        this.ggcMapService.clearHighlightLayer(activeSelectInteraction.mapIndex);
        this.emitEvent(new MapComponentEvent$1(MapComponentEventTypes$1.SELECTIONSERVICE_CLEARSELECTION, mapIndex, CoreSelectionService.messageClearSelection, undefined, undefined, selectIndex));
    }
    /**
     * Verwijdert alle selecties voor alle actieve select interactions
     * die gekoppeld zijn aan de opgegeven mapIndex.
     *
     * @param mapIndex De kaartindex waarvoor alle selecties worden gewist.
     */
    clearAllSelectionsForMapIndex(mapIndex) {
        const selectIndices = this.getAllActiveSelectIndicesOnMapIndex(mapIndex);
        for (const selectIndex of selectIndices) {
            this.clearSelection(selectIndex);
        }
    }
    setSelection(features, selectIndex) {
        const select = this.getActiveSelectInteraction(selectIndex)?.select;
        if (select) {
            select.clearSelection();
            for (const feature of features) {
                select.selectFeature(feature);
            }
        }
    }
    getCurrentSelection(selectIndex) {
        const select = this.getActiveSelectInteraction(selectIndex)?.select;
        if (select) {
            return select.getFeatures().getArray();
        }
        return [];
    }
    handleFeatureInfoForLayer(mapIndex, features, layerId) {
        const relevantSelectIndices = this.getAllActiveSelectIndicesOnMapIndex(mapIndex);
        for (const selectIndex of relevantSelectIndices) {
            const select = this.getActiveSelectInteraction(selectIndex)?.select;
            if (select) {
                const filterLayerIds = select.get(this.GGC_LAYER_IDS);
                // Only add features that are within the filtered layerIds of the select interaction
                if (!filterLayerIds || filterLayerIds.includes(layerId)) {
                    this.handleNewFeaturesForSelection(features, selectIndex, layerId);
                }
            }
        }
    }
    getActiveSelectInteraction(selectIndex) {
        return this.activeSelectInteractions.get(selectIndex);
    }
    /**
     * Maakt een filterfunctie voor de OpenLayers Select‑interaction.
     *
     * De filter:
     * - controleert of de feature afkomstig is van een geldige layer
     * - accepteert alle layers indien `layerIds` undefined is
     * - voegt altijd de property `layer_id` toe aan de feature
     *
     * De `layer_id` wordt gelezen uit de layer property `ggc-layer-id`.
     *
     * @param layerIds Optionele lijst met toegestane layer‑IDs
     * @returns Filterfunctie voor Select‑interaction
     */
    createSelectionFilterFunction(layerIds) {
        return (feature, layer) => {
            if (!layer) {
                // !layer means that either
                // a feature of a WMS or WMTS layer is clicked, which we are handling manually
                // or a feature from the selection layer is clicked, which we can also ignore, as this layer is only for visualization
                return false;
            }
            const layerId = layer.get("ggc-layer-id");
            if (layerId !== undefined) {
                feature.set(GGC_FEATURE_LAYERID, layerId);
            }
            if (!layerIds || layerIds.length === 0) {
                return true;
            }
            return layerIds.includes(layerId);
        };
    }
    connectSelectEvents(select, selectIndex, mapIndex) {
        const map = this.ggcMapService.getMap(mapIndex);
        if (!map) {
            return;
        }
        const clickEvent = () => {
            this.emitEvent(new MapComponentEvent$1(MapComponentEventTypes$1.SELECTIONSERVICE_MAPCLICKED, mapIndex, CoreSelectionService.messageMapClicked, undefined, undefined, selectIndex));
        };
        map.on("singleclick", clickEvent);
        this.activeMapClickEventsKeys.set(selectIndex, clickEvent);
        const selectionUpdatedEvent = () => {
            const features = this.getActiveSelectInteraction(selectIndex)?.select.getFeatures();
            if (!features) {
                return;
            }
            const map = this.ggcMapService.getMap(mapIndex);
            const layers = map.getLayers();
            for (const layer of layers.getArray()) {
                // update the selection visualization on the vector layers
                layer.changed();
            }
            this.updateSelectionLayer(features, mapIndex, selectIndex);
            this.emitSelectionUpdatedEvent(selectIndex, features);
        };
        select.on("select", selectionUpdatedEvent);
        this.activeSelectEventsKeys.set(selectIndex, selectionUpdatedEvent);
    }
    emitEvent(event) {
        this.subjectSelectEvents.next(event);
    }
    emitSelectionUpdatedEvent(selectIndex, features) {
        const mapIndex = this.getMapIndexFromSelectIndex(selectIndex);
        if (!mapIndex) {
            return;
        }
        this.emitEvent(new MapComponentEvent$1(MapComponentEventTypes$1.SELECTIONSERVICE_SELECTIONUPDATED, mapIndex, CoreSelectionService.messageSelectionUpdated, undefined, this.buildFeatureCollectionForCoordinateFromFeatures(features, mapIndex), selectIndex));
    }
    updateSelectionLayer(featureCollection, mapIndex, selectIndex) {
        this.ggcMapService.clearSelectionLayer(mapIndex, selectIndex);
        this.ggcMapService.addFeaturesToSelectionLayer(featureCollection.getArray(), mapIndex, selectIndex);
    }
    handleNewFeaturesForSelection(features, selectIndex, layerId) {
        const activeSelectInteraction = this.getActiveSelectInteraction(selectIndex);
        if (!activeSelectInteraction) {
            return;
        }
        const select = activeSelectInteraction.select;
        const mapIndex = activeSelectInteraction.mapIndex;
        const featureCollection = select.getFeatures();
        switch (select.get(this.GGC_SELECT_MODE)) {
            case "multi": {
                this.toggleFeatures(features, featureCollection, mapIndex, layerId, selectIndex);
                break;
            }
            case "single": {
                // Previous features are automatically deselected/removed in the selection interaction, so pushing new features is enough
                this.addFeaturesToCollection(features, featureCollection, layerId);
                break;
            }
            default:
                return;
        }
        this.updateSelectionLayer(featureCollection, mapIndex, selectIndex);
        // Emit event manually, because manual action do not trigger select events automatically
        this.emitSelectionUpdatedEvent(selectIndex, featureCollection);
    }
    toggleFeatures(featuresToToggle, featureCollection, mapIndex, layerId, selectIndex) {
        for (const featureToggle of featuresToToggle) {
            if (this.ggcMapService.isFeatureInSelectionLayer(featureToggle, mapIndex, selectIndex)) {
                /**
                 * Manually remove the feature from the collection as it is already in the selection layer yet
                 */
                const featureToBeRemoved = this.getEqualFeatureFromCollection(featureCollection, featureToggle);
                if (featureToBeRemoved) {
                    featureCollection.remove(featureToBeRemoved);
                }
            }
            else {
                /**
                 * Manually add the feature to the collection as it is not in the selection layer yet
                 */
                featureToggle.set(GGC_FEATURE_LAYERID, layerId);
                featureCollection.push(featureToggle);
            }
        }
    }
    buildFeatureCollectionForCoordinateFromFeatures(features, mapIndex) {
        const layerFeatureMap = this.buildLayerFeatureMap(features);
        const result = new FeatureCollectionForCoordinate$1();
        layerFeatureMap.forEach((features, layerId) => {
            const layerCollection = {
                layerId,
                layerName: "",
                layerTitle: this.ggcMapService
                    .getLayer(layerId, mapIndex)
                    ?.get("ggc-title"),
                features
            };
            result.featureCollectionForLayers.push(layerCollection);
        });
        return result;
    }
    /**
     * Build a layerId to features mapping
     * @param features
     * @private
     */
    buildLayerFeatureMap(features) {
        const layerFeatureMap = new Map();
        for (const feature of features.getArray()) {
            const layerId = feature.get(GGC_FEATURE_LAYERID) ?? "";
            let layerFeatures = layerFeatureMap.get(layerId);
            if (!layerFeatures) {
                layerFeatures = [];
                layerFeatureMap.set(layerId, layerFeatures);
            }
            layerFeatures.push(feature);
        }
        return layerFeatureMap;
    }
    addFeaturesToCollection(newFeatures, featureCollection, layerId) {
        for (const feature of newFeatures) {
            feature.set(GGC_FEATURE_LAYERID, layerId);
            featureCollection.push(feature);
        }
    }
    getMapIndexFromSelectIndex(selectindex) {
        return this.activeSelectInteractions.get(selectindex)?.mapIndex;
    }
    getAllActiveSelectIndicesOnMapIndex(mapIndex) {
        const result = [];
        this.activeSelectInteractions.forEach((selectInteraction, selectIndex) => {
            if (selectInteraction.mapIndex === mapIndex) {
                result.push(selectIndex);
            }
        });
        return result;
    }
    getEqualFeatureFromCollection(featureCollection, feature) {
        if (!featureCollection || !feature) {
            return false;
        }
        return featureCollection
            .getArray()
            .find((collectionFeature) => this.areFeaturesEqual(collectionFeature, feature));
    }
    areFeaturesEqual(feature1, feature2) {
        if (feature1 == feature2) {
            return true;
        }
        if (feature1.getId()) {
            return feature1.getId() === feature2.getId();
        }
        if (feature1.values_.id) {
            return feature1.values_.id === feature2.values_.id;
        }
        if (feature1.values_.external_fid) {
            return (feature1.values_.external_fid ===
                feature2.values_.external_fid);
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSelectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSelectionService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreSelectionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }], ctorParameters: () => [] });

/**
 * Service voor het selecteren en highlighten van features op de kaart.
 *
 * De {@link GgcSelectionService} biedt ondersteuning voor selectie‑interacties
 * op verschillende typen kaartlagen en abstracteert de onderliggende
 * OpenLayers‑selectielogica via de {@link CoreSelectionService}.
 *
 * ## Ondersteunde kaartlagen
 *
 * De service ondersteunt selecties op alle kaartlagen, maar het gebruik van
 * **WFS‑ of OGC‑kaartlagen** wordt sterk aanbevolen. Deze lagen bevatten features
 * als vector‑data in de front‑end, wat uitgebreidere en stabielere selectiemogelijkheden
 * biedt.
 *
 * Selecties op **WMS/WMTS‑kaartlagen** worden ook ondersteund, maar kennen
 * functionele beperkingen (zie hieronder).
 *
 * ## Selectiemodi voor WFS en OGC kaartlagen
 *
 * Voor WFS‑ en OGC‑kaartlagen zijn de volgende selectiemodi beschikbaar:
 *
 * - **Single select**
 *   Door te klikken wordt één feature geselecteerd. Een nieuwe selectie
 *   vervangt de bestaande selectie.
 *
 * - **Multi select**
 *   Meerdere features kunnen geselecteerd worden. Door op een reeds
 *   geselecteerde feature te klikken, wordt deze uit de selectie verwijderd.
 *
 * - **OpenLayers default**
 *   Standaard OpenLayers‑gedrag:
 *   - normale klik → single select
 *   - shift‑klik → multi select
 *
 * ## Selecties op WMS en WMTS kaartlagen
 *
 * Selecties op WMS‑ en WMTS‑kaartlagen werken anders dan bij vector‑lagen,
 * omdat de features niet permanent in de front‑end beschikbaar zijn.
 *
 * Voor WMS/WMTS‑selecties gelden de volgende vereisten en beperkingen:
 *
 * - De kaartlaag moet de property `getFeatureInfoOnSingleclick` op `true` hebben.
 * - Selecties werken alleen via **singleclick** in:
 *   - single select modus
 *   - multi select modus
 * - De GetFeatureInfo‑response **moet een geometry bevatten**,
 *   anders kan de feature niet worden gehighlight.
 *
 * Buiten deze beperkingen gedragen WMS‑ en WMTS‑kaartlagen zich verder hetzelfde
 * binnen de {@link GgcSelectionService} en kunnen zij:
 *
 * - gecombineerd worden met andere kaartlagen;
 * - gelijktijdig gebruikt worden met WFS/OGC‑lagen;
 * - gefilterd worden via `layerIds` bij het starten van een selectie.
 *
 * ## Events en observables
 *
 * De service throws selectie‑events via een {@link Observable} van
 * {@link MapComponentEvent}. Deze events kunnen gebruikt worden om
 * selectie‑wijzigingen te volgen en te synchroniseren met andere componenten.
 *
 * @see {@link SelectOptions}
 */
class GgcSelectionService {
    constructor() {
        this.coreSelectionService = inject(CoreSelectionService);
    }
    /**
     * @deprecated
     * Zet de selectiemodus van de kaart op **single select**.
     * Hierbij kan steeds slechts één object tegelijk geselecteerd worden.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectiemodus wordt ingesteld.
     */
    setSingleselectMode(mapIndex = DEFAULT_MAPINDEX) {
        this.startSelect({ selectMode: "single" }, mapIndex);
    }
    /**
     * @deprecated
     * Zet de selectiemodus van de kaart op **multi select**.
     * Hierbij kunnen meerdere objecten tegelijk geselecteerd worden.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectiemodus wordt ingesteld.
     */
    setMultiselectMode(mapIndex = DEFAULT_MAPINDEX) {
        this.startSelect({ selectMode: "multi" }, mapIndex);
    }
    /**
     * Start een selectie‑interactie op de kaart.
     *
     * @param options Configuratie voor de selectie, zoals selectiemodus
     * en aanvullende selectie‑opties.
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt gestart.
     * @param selectIndex Optionele selectIndex (default: undefined) waarmee een
     * select interaction wordt geïdentificeerd. Als undefined, dan wordt de mapIndex gebruikt voor de selectIndex.
     * Met selectIndex kunnen meerdere select interactions actief zijn op 1 kaart.
     */
    startSelect(options, mapIndex = DEFAULT_MAPINDEX, selectIndex = undefined) {
        this.coreSelectionService.startSelect(options, mapIndex, selectIndex);
    }
    /**
     * Stopt de actieve selectie‑interactie op de kaart.
     *
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt gestopt.
     */
    stopSelect(selectIndex = DEFAULT_MAPINDEX) {
        this.coreSelectionService.stopSelect(selectIndex);
    }
    /**
     * Verwijdert alle huidige selecties van de opgegeven kaart.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectie wordt gewist.
     * @param selectIndex Optionele selectIndex waarvoor
     * de selectie wordt gewist.
     */
    clearSelection(mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        this.coreSelectionService.clearSelection(mapIndex, selectIndex);
    }
    /**
     * Cleart alle selecties voor de opgegeven kaartindex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * waarvoor alle selecties worden gewist.
     */
    clearAllSelectionsForMapIndex(mapIndex = DEFAULT_MAPINDEX) {
        this.coreSelectionService.clearAllSelectionsForMapIndex(mapIndex);
    }
    /**
     * @deprecated
     * Zet een selectie voor een specifieke kaartlaag.
     * Bestaande selecties voor deze laag worden overschreven.
     *
     * @param features Array van OpenLayers features die geselecteerd moeten worden.
     * @param layerName Naam van de kaartlaag waarop de selectie betrekking heeft.
     * @param mapIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt toegepast.
     */
    setSelectionForLayer(features, layerName, mapIndex = DEFAULT_MAPINDEX) {
        this.setSelection(features, mapIndex);
    }
    /**
     * Overschrijft de bestaande selectie met de meegegeven features.
     *
     * @param features De nieuwe OpenLayers features die geselecteerd worden.
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt overschreven.
     */
    setSelection(features, selectIndex = DEFAULT_MAPINDEX) {
        this.coreSelectionService.setSelection(features, selectIndex);
    }
    /**
     * Geeft de actieve selectie van de opgegeven kaart.
     *
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de huidige selectie wordt opgehaald.
     * @returns De huidige selectie voor de opgegeven kaart.
     */
    getCurrentSelection(selectIndex = DEFAULT_MAPINDEX) {
        return this.coreSelectionService.getCurrentSelection(selectIndex);
    }
    /**
     * Geeft een observable die selectie‑gerelateerde events emit
     * voor de opgegeven kaart. De mapIndex in het event refereert naar de selectIndex als die is opgegeven, anders de mapIndex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * selectie‑events worden gevolgd.
     * @param selectIndex Optionele selectIndex waarvoor
     * selectie‑events worden gevolgd.
     * @returns Observable met {@link MapComponentEvent} selectie‑events.
     */
    getObservable(mapIndex = DEFAULT_MAPINDEX, selectIndex) {
        return this.coreSelectionService.getObservableForMap(mapIndex, selectIndex);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSelectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSelectionService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcSelectionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * @deprecated verhuisd naar ggc-models
 * Verzameling van features die behoren tot één specifieke kaartlaag.
 */
class FeatureCollectionForLayer {
}
/**
 * @deprecated verhuisd naar ggc-models
 * Verzameling van features gegroepeerd per laag voor een specifieke
 * kaartcoördinaat.
 *
 * Wordt bijvoorbeeld gebruikt bij feature-informatie of
 * selectieresultaten op een kaartlocatie.
 */
class FeatureCollectionForCoordinate {
    /**
     * @param coord Optionele kaartcoördinaat
     */
    constructor(coord) {
        this.coordinate = coord;
        this.featureCollectionForLayers = [];
    }
}

/**
 * Controleert of een featurecollectie voor een laag één of meerdere
 * geclusterde features bevat (features in een feature).
 *
 * Een clusterfeature wordt herkend aan de aanwezigheid
 * van een `features` property met meer dan één onderliggend feature.
 *
 * @param featureinfo Featurecollectie voor een specifieke laag
 * @returns `true` indien er minimaal één clusterfeature aanwezig is,
 *          anders `false`
 */
const featureCollectionForLayerHasCluster = (featureinfo) => {
    return featureinfo.features.some((feature) => feature.get("features"));
};
/**
 * Haalt de onderliggende features uit geclusterde features
 * en geeft deze terug als een vlakke lijst.
 *
 * Deze functie wordt gebruikt om clusterfeatures te
 * "declusteren" naar losse OpenLayers features.
 *
 * @param features Array van (cluster)features
 * @returns Array met individuele OpenLayers features
 */
const declusterFeatures = (features) => {
    return features.reduce((previousValue, currentValue) => {
        const containedFeatures = currentValue.get("features") || [];
        return previousValue.concat(containedFeatures);
    }, []);
};

class AbstractBaseLayerComponent {
    constructor() {
        this.mapIndex = DEFAULT_MAPINDEX;
        this.coreMapService = inject(CoreMapService);
        this.coreSelectionService = inject(CoreSelectionService);
        this.crsConfig = inject(GgcCrsConfigService);
    }
    ngOnInit() {
        this.rdNewConfig = this.crsConfig.getRdNewCrsConfig();
        if (this.options) {
            this.options.layerId ??= this.generateLayerId();
        }
        else {
            this.options = {
                mapIndex: this.mapIndex,
                layerId: this.generateLayerId()
            };
        }
        if (this.options.mapIndex !== undefined) {
            this.mapIndex = this.options.mapIndex;
        }
    }
    ngOnDestroy() {
        // remove the layer if the tag is destroyed.
        if (this.map !== undefined && this.olLayer !== undefined) {
            this.map.removeLayer(this.olLayer);
        }
    }
    disable() {
        // placeholder
    }
    enable() {
        // placeholder
    }
    getLayerId() {
        return this.options.layerId;
    }
    setLayer(layer) {
        this.olLayer = layer;
        this.olLayer.set("ggc-layer-id", this.options?.layerId);
        this.olLayer.set("ggc-title", this.options?.title);
        this.olLayer.set("persistent", this.options?.persistent);
        this.map = this.coreMapService.getMap(this.mapIndex);
        this.map.addLayer(this.olLayer);
    }
    generateLayerId() {
        return crypto.randomUUID();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractBaseLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: AbstractBaseLayerComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractBaseLayerComponent, decorators: [{
            type: Component,
            args: [{ template: "" }]
        }] });

class AbstractConfigurableLayerComponent extends AbstractBaseLayerComponent {
    constructor() {
        super(...arguments);
        this.events = new EventEmitter();
    }
    ngOnInit() {
        super.ngOnInit();
        this.layerName = this.options?.layerName;
        this.attributions = this.options?.attributions;
        this.layerOptions = {
            ...(this.options?.minResolution && {
                minResolution: this.options?.minResolution
            }),
            ...(this.options?.maxResolution && {
                maxResolution: this.options?.maxResolution
            }),
            ...(this.options?.zIndex && { zIndex: this.options?.zIndex }),
            ...(this.options?.opacity && { opacity: this.options?.opacity })
        };
        if (this.options?.minZoomLevel !== undefined &&
            this.options.maxResolution == undefined) {
            this.layerOptions = {
                ...this.layerOptions,
                maxResolution: zoomlevelToResolution(this.options.minZoomLevel)
            };
        }
        if (this.options?.maxZoomLevel !== undefined &&
            this.options.minResolution == undefined) {
            this.layerOptions = {
                ...this.layerOptions,
                minResolution: zoomlevelToResolution(this.options.maxZoomLevel)
            };
        }
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    setLayer(layer) {
        super.setLayer(layer);
        const attributions = this.options?.attributions;
        if (attributions !== undefined) {
            this.olLayer.getSource().setAttributions(attributions);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractConfigurableLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: AbstractConfigurableLayerComponent, isStandalone: true, selector: "ggc-abstract-configurable-layer", outputs: { events: "events" }, usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractConfigurableLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-abstract-configurable-layer",
                    template: ""
                }]
        }], propDecorators: { events: [{
                type: Output
            }] } });

class AbstractClickableLayerComponent extends AbstractConfigurableLayerComponent {
    constructor() {
        super(...arguments);
        this.maxFeaturesOnSingleclick = 8;
        this.mapEventsService = inject(CoreMapEventsService);
    }
    ngOnInit() {
        super.ngOnInit();
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    getFeatureInfo(_event) {
        // stubbed method
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractClickableLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: AbstractClickableLayerComponent, isStandalone: true, selector: "ng-component", usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: AbstractClickableLayerComponent, decorators: [{
            type: Component,
            args: [{ template: "" }]
        }] });

class CoreOgcApiFeaturesService {
    constructor() {
        this.http = inject(HttpClient);
        this.geoJsonFormat = new GeoJSON();
        this.limitDefault = 100;
        this.maxFeaturesDefault = 5000;
    }
    async fetchAllOgcApiFeatures(initialUrl, limit = this.limitDefault, maxFeatures = this.maxFeaturesDefault) {
        const allFeatures = [];
        if (!this.isValidOgcApiFeatureUrl(initialUrl)) {
            return allFeatures;
        }
        let url = new URL(initialUrl);
        url.searchParams.set("limit", String(limit));
        while (allFeatures.length < maxFeatures) {
            const response = (await firstValueFrom(this.http.get(url.toString())));
            if (!response) {
                break;
            }
            const olFeatures = this.geoJsonFormat.readFeatures({
                type: "FeatureCollection",
                features: response.features ?? []
            });
            const remainingSlots = maxFeatures - allFeatures.length;
            const featuresToAdd = olFeatures.slice(0, remainingSlots);
            allFeatures.push(...featuresToAdd);
            if (allFeatures.length >= maxFeatures) {
                break;
            }
            const nextLink = response.links?.find((l) => l.rel === "next")?.href;
            if (!nextLink) {
                break;
            }
            url = new URL(nextLink);
        }
        return allFeatures;
    }
    isValidOgcApiFeatureUrl(url) {
        return url.includes("/collections/") && url.includes("/items");
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiFeaturesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiFeaturesService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiFeaturesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Door `<ggc-geojson-layer></ggc-geojson-layer>` op te nemen in de HTML kunnen
 * kaartlagen worden getoond die GeoJSON data bevatten. Dit kan bijvoorbeeld een
 * losse file zijn die GeoJSON-objecten bevat of een WFS-kaartlaag die JSON als
 * outputformat heeft. Bij deze kaartlaag is de variabele url optioneel.
 *
 * @example
 * import { GeojsonLayerOptions } from "@kadaster/ggc-map";
 * import Style from "ol/style/Style";
 *
 * const stylePointObjectShapeTriangle = new Style();
 *
 * const geojsonLayerOptions: GeojsonLayerOptions = {
 *     url: "/assets/GeoJSONTest.json",
 *     minResolution: 100,
 *     maxResolution: 861,
 *     zIndex: 3,
 *     getFeatureInfoOnSingleclick: true,
 *     maxFeaturesOnSingleclick: 15,
 *     hitTolerance: 6,
 *     styleLike: stylePointObjectShapeTriangle,
 *     attributions: "Attributie voor deze GeoJSON kaartlaag",
 *     mapIndex: "geojson",
 *     layerName: "GeoJSON kaartlaag"
 * };
 *
 * <ggc-geojson-layer [options]="geojsonLayerOptions" (events)="logGetFeatureInfoEvents($event)">
 *   </ggc-geojson-layer>
 *
 */
class GgcGeojsonLayerComponent extends AbstractClickableLayerComponent {
    constructor() {
        super(...arguments);
        this.foundFeatures = [];
        this.ggcOgcApiFeaturesService = inject(CoreOgcApiFeaturesService);
    }
    /**
     * Initialiseert de GeoJSON-laag bij het laden van de component.
     * Bouwt de vectorbron en eventueel een clusterbron op basis van de opgegeven opties.
     */
    ngOnInit() {
        super.ngOnInit();
        this.geoJsonFormat = new GeoJSON$1({
            dataProjection: this.rdNewConfig.projectionCode,
            geometryName: "",
            featureProjection: this.rdNewConfig.projectionCode
        });
        const isOgcApiUrl = this.options?.url?.includes("/collections/") &&
            this.options?.url?.includes("/items");
        // basis opties
        const options = {
            format: this.geoJsonFormat
        };
        // Options assignen voordat vectorSource wordt geinitialiseerd
        if (!isOgcApiUrl) {
            Object.assign(options, {
                ...this.options?.sourceOptions,
                ...(this.options?.url && { url: this.options?.url }),
                ...(this.options?.features && { features: this.options?.features })
            });
        }
        this.vectorSource = new VectorSource(options);
        // voeg een eigen loader toe ipv de OL loader om customheaders te kunnen meegeven
        if (this.options?.customHeaders) {
            this.vectorSource.setLoader((extent, resolution, projection) => {
                if (!this.options?.url) {
                    throw new Error("GeoJson options.url is verplicht");
                }
                if (!this.options.customHeaders) {
                    throw new Error("GeoJson options.customHeaders is verplicht");
                }
                fetch(new URL(this.options.url), {
                    headers: this.options.customHeaders
                })
                    .then((response) => {
                    if (!response.ok) {
                        throw new Error(`HTTP error ${response.status}`);
                    }
                    return response.json();
                })
                    .then((data) => {
                    const features = this.geoJsonFormat.readFeatures(data, {
                        featureProjection: projection
                    });
                    this.vectorSource.addFeatures(features);
                })
                    .catch((error) => {
                    console.error("GeoJSON load error", error);
                });
            });
        }
        const layerOptions = {
            ...this.options?.layerOptions,
            ...this.layerOptions,
            ...(this.options?.styleLike && { style: this.options?.styleLike })
        };
        if (this.options?.clusterDistance !== undefined ||
            this.options?.sourceClusterOptions !== undefined) {
            this.clusterSource = new Cluster({
                ...this.options?.sourceClusterOptions,
                ...(this.options?.clusterDistance && {
                    distance: this.options?.clusterDistance
                }),
                ...(this.attributions && { attributions: this.attributions }),
                source: this.vectorSource
            });
            layerOptions.source = this.clusterSource;
        }
        else {
            layerOptions.source = this.vectorSource;
        }
        this.setLayer(new VectorLayer(layerOptions));
        // OGC API Features inladen na setten van Vectorlaag
        if (isOgcApiUrl) {
            (async () => {
                const limit = this.options?.limit;
                const maxFeatures = this.options?.maxFeatures;
                try {
                    const features = await this.ggcOgcApiFeaturesService.fetchAllOgcApiFeatures(this.options.url, limit, maxFeatures);
                    options.features = features;
                    this.vectorSource.addFeatures(features);
                }
                catch (e) {
                    console.error("Fout bij ophalen OGC API features: ", e);
                }
            })();
        }
    }
    /**
     * Reageert op wijzigingen in de input properties.
     * Ondersteunt dynamische updates van URL en features.
     *
     * @param changes - De gewijzigde inputs.
     */
    ngOnChanges(changes) {
        if (changes.url && !changes.url.firstChange) {
            this.updateUrl(changes.url.currentValue);
        }
        if (changes.features && !changes.features.firstChange) {
            this.updateFeatures(changes.features.currentValue);
        }
        if (changes.options && !changes.options.firstChange) {
            if (changes.options.currentValue.sourceOptions?.url !==
                changes.options.previousValue?.sourceOptions?.url) {
                this.updateUrl(changes.options.currentValue.sourceOptions?.url);
            }
            if (changes.options.currentValue.url !== changes.options.previousValue?.url) {
                this.updateUrl(changes.options.currentValue.url);
            }
            if (changes.options.currentValue.sourceOptions?.features !==
                changes.options.previousValue?.sourceOptions?.features) {
                this.updateFeatures(changes.options.currentValue.sourceOptions?.features);
            }
            if (changes.options.currentValue.features !==
                changes.options.previousValue?.features) {
                this.updateFeatures(changes.options.currentValue.features);
            }
        }
    }
    /**
     * Verwerkt een klik op de kaart en haalt relevante features op.
     * Stuurt een MapComponentEvent met de gevonden features.
     *
     * @param event - Het MapBrowserEvent van de klik.
     */
    getFeatureInfo(event) {
        const pixel = event.pixel;
        this.map.forEachFeatureAtPixel(pixel, (feature) => this.limitFeatures(feature), {
            layerFilter: this.decideLayerCandidate.bind(this),
            hitTolerance: this.options?.hitTolerance
        });
        /* Kopie van de foundFeatures meegeven, omdat dit anders later fout gaat met
         de objectreferentie bij het zetten van foundFeatures.length op 0. */
        const foundFeaturesCopy = this.foundFeatures.slice();
        this.coreSelectionService.handleFeatureInfoForLayer(this.mapIndex, foundFeaturesCopy, this.getLayerId());
        const mapComponentEvent = new MapComponentEvent$1(MapComponentEventTypes$1.GEOJSONFEATUREINFO, this.mapIndex, "GeoJSON getFeatureInfo resultaten: ", this.layerName, foundFeaturesCopy);
        this.events.emit(mapComponentEvent);
        this.foundFeatures.length = 0;
    }
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    /**
     * Update de URL van de vectorbron en forceert een refresh.
     *
     * @param url - De nieuwe GeoJSON URL.
     */
    updateUrl(url) {
        const vectorSource = this.olLayer.getSource();
        vectorSource.setUrl(url);
        vectorSource.refresh();
    }
    /**
     * Update de features van de vectorbron.
     *
     * @param features - De nieuwe lijst van Feature objecten.
     */
    updateFeatures(features) {
        let vectorSource = this.olLayer.getSource();
        if (vectorSource instanceof Cluster) {
            vectorSource = vectorSource.getSource();
        }
        vectorSource.clear();
        vectorSource.addFeatures(features);
    }
    /**
     * Beperkt het aantal gevonden features bij een klik.
     *
     * @param feature - Het gevonden FeatureLike object.
     */
    limitFeatures(feature) {
        if (this.foundFeatures.length < this.maxFeaturesOnSingleclick) {
            // feature as Feature, because VectorSource contains Features. RenderFeatures are used for VectorTileLayer
            this.foundFeatures.push(feature);
        }
    }
    /**
     * Filtert lagen om te bepalen of ze relevant zijn voor feature info.
     *
     * @param layerCandidate - De kandidaat BaseLayer.
     * @returns `true` als de laag overeenkomt met deze component.
     */
    decideLayerCandidate(layerCandidate) {
        return this.olLayer === layerCandidate;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcGeojsonLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcGeojsonLayerComponent, isStandalone: true, selector: "ggc-geojson-layer", inputs: { options: "options" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcGeojsonLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-geojson-layer",
                    template: ""
                }]
        }], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Door `<ggc-image-layer></ggc-image-layer>` op te nemen in de HTML kan een image
 * worden weergegeven als kaartlaag.
 *
 * @example
 * import { ImageLayerOptions } from "@kadaster/ggc-map";
 *
 * const imageLayerOptions: ImageLayerOptions = {
 *     url: "/assets/image1.png",
 *     zIndex: 4,
 *     attributions: "Attributie voor Image",
 *     mapIndex: "een",
 *     layerName: "Image kaartlaag"
 * };
 *
 * <ggc-image-layer [options]="imageLayerOptions"> </ggc-image-layer>
 */
class GgcImageLayerComponent extends AbstractConfigurableLayerComponent {
    /**
     * Initialiseert de afbeeldingslaag bij het laden van de component.
     * De afbeelding wordt geladen via ImageStatic en gekoppeld aan een ImageLayer.
     */
    ngOnInit() {
        super.ngOnInit();
        this.imageSource = new ImageStatic({
            // url is not optional in ImageStatic options, but can be set from options or input which can both be undefined.
            url: "",
            crossOrigin: "anonymous",
            ...this.options?.sourceOptions,
            // only set url when this.options.url is defined, otherwise it will overwrite url from this.options?.sourceOptions
            ...(this.options?.url && { url: this.options?.url }),
            ...(this.options?.imageExtent && {
                imageExtent: this.options?.imageExtent
            }),
            projection: this.rdNewConfig.projectionCode
        });
        this.setLayer(new ImageLayer({
            ...this.options?.layerOptions,
            ...this.layerOptions,
            source: this.imageSource
        }));
    }
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcImageLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcImageLayerComponent, isStandalone: true, selector: "ggc-image-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcImageLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-image-layer",
                    template: ""
                }]
        }], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Door <ggc-vector-tile-layer></ggc-vector-tile-layer> op te nemen in de HTML
 * kunnen kaartlagen worden getoond die opgebouwd worden door middel van vector
 * tiles. Let op ggc-vector-tile-layer kan nog niet geprint worden met de print-services.
 *
 * @example
 * import { VectorTileLayerOptions } from "@kadaster/ggc-map";
 *
 * const vectorTileLayerOptions: VectorTileLayerOptions = {
 *     url: "https://api.pdok.nl/lv/bgt/ogc/v1/tiles/NetherlandsRDNewQuad/{z}/{y}/{x}?f=mvt",
 *     minResolution: 0,
 *     maxResolution: 4,
 *     zIndex: 3,
 *     getFeatureInfoOnSingleclick: true,
 *     maxFeaturesOnSingleclick: 15,
 *     hitTolerance: 6,
 *     style: "https://api.pdok.nl/lv/bgt/ogc/v1/styles/bgt_achtergrondvisualisatie",
 *     attributions: "Attributie voor deze Vector Tile kaartlaag",
 *     mapIndex: "vectortile",
 *     layerName: "Vector Tile kaartlaag"
 * };
 *
 * <ggc-vector-tile-layer [options]="vectorTileLayerOptions" (events)="logGetFeatureInfoEvents($event)">
 *   </ggc-vector-tile-layer>
 */
class GgcVectorTileLayerComponent extends AbstractClickableLayerComponent {
    constructor() {
        super(...arguments);
        /**
         * Angular HttpClient voor het ophalen van externe JSON-bestanden zoals stijl- of tile-informatie.
         */
        this.httpClient = inject(HttpClient);
        /**
         * Interne lijst van gevonden features bij een klik op de kaart.
         * Wordt gebruikt voor het genereren van feature info events.
         */
        this.foundFeatures = [];
    }
    /**
     * Angular lifecycle hook die wordt aangeroepen bij initialisatie van de component.
     * Initialiseert de vector tile source en laag.
     */
    ngOnInit() {
        super.ngOnInit();
        this.createVectorTileSource().then((source) => {
            this.vectorTileSource = source;
            const vectorTileLayer = this.createVectorTileLayer();
            // Set style before adding layer preventing flickering
            this.setStyle(vectorTileLayer, false);
            this.setLayer(vectorTileLayer);
        });
    }
    /**
     * Maakt een nieuwe VectorTileLayer instantie met configuratieopties.
     * Wordt gebruikt als renderlaag in de kaart.
     */
    createVectorTileLayer() {
        return new VectorTileLayer({
            renderMode: "hybrid",
            declutter: true,
            useInterimTilesOnError: false,
            ...this.options?.layerOptions,
            ...this.layerOptions,
            source: this.vectorTileSource
        });
    }
    /**
     * Genereert een TileGrid op basis van resoluties en extent.
     * Ondersteunt overzoom indien geactiveerd.
     */
    async createTileGrid() {
        return new TileGrid({
            resolutions: (this.options?.enableOverzoom ?? false)
                ? await this.createOverzoomResolutions()
                : this.crsConfig.getRdNewCrsConfig().resolutions,
            extent: this.crsConfig.getRdNewCrsConfig().extent,
            tileSize: this.options?.tileSize || [256, 256],
            origin: getTopLeft(this.crsConfig.getRdNewCrsConfig().extent)
        });
    }
    /**
     * Update de vector tile source van de laag indien overzoom is ingeschakeld.
     * Wordt aangeroepen bij stijlwijzigingen.
     */
    async updateOverzoomSettings(layer) {
        this.vectorTileSource = await this.createVectorTileSource();
        layer.setSource(this.vectorTileSource);
        layer.getSource().changed();
    }
    /**
     * Maakt een nieuwe VectorTileSource op basis van configuratieopties.
     * Ondersteunt attributies, URL en tileGrid.
     */
    async createVectorTileSource() {
        const options = {
            // Zie TMS-9812, https://github.com/openlayers/openlayers/issues/15929
            // @ts-ignore
            format: new MVT({ featureClass: Feature }),
            ...this.options?.sourceOptions,
            ...(this.attributions && { attributions: this.attributions }),
            ...(this.options?.url && { url: this.options?.url }),
            projection: this.crsConfig.getRdNewCrsConfig().projectionCode,
            tileGrid: await this.createTileGrid()
        };
        return new VectorTileSource(options);
    }
    /**
     * Genereert een lijst van resoluties voor overzoom op basis van maxZoom.
     * Filtert resoluties lager dan de minimale resolutie.
     */
    async createOverzoomResolutions() {
        const maxZoom = await this.getMaxZoom();
        const resolutions = this.crsConfig.getRdNewCrsConfig().resolutions;
        if (maxZoom) {
            const minResolution = zoomlevelToResolution(maxZoom);
            return resolutions.filter((resolution) => {
                return resolution >= minResolution;
            });
        }
        else {
            return resolutions;
        }
    }
    /**
     * Bepaalt de maximale zoomwaarde uit configuratie, tile URL of stijl URL.
     * Wordt gebruikt voor overzoom functionaliteit.
     */
    async getMaxZoom() {
        if (this.options?.sourceOptions?.maxZoom) {
            return this.options?.sourceOptions?.maxZoom;
        }
        if (this.options?.url) {
            const result = await this.getMaxZoomFromUrl(this.options?.url);
            if (result) {
                return result;
            }
        }
        if (this.options?.style && typeof this.options?.style === "string") {
            const result = await this.getMaxZoomFromStyleUrl(this.options?.style);
            if (result) {
                return result;
            }
        }
        console.error("Could not get a max zoom from the available sources for the overzoom");
        return undefined;
    }
    /**
     * Haalt de maximale zoomwaarde op uit een tile URL via een tilejson request.
     *
     * @param tileUrl - De URL van de tile endpoint (bijv. met /{z}/{x}/{y}).
     * @returns De maximale zoomwaarde indien beschikbaar, anders undefined.
     */
    async getMaxZoomFromUrl(tileUrl) {
        try {
            const url = tileUrl.split("/{z}/{y}/{x}")[0] + "?f=tilejson";
            const json = await this.getJsonFromUrl(url);
            return json.maxzoom ?? undefined;
        }
        catch (e) {
            console.error(`Could not get the json from the tile url ${tileUrl}`);
            return undefined;
        }
    }
    /**
     * Haalt de minimale maxzoom op uit alle bronnen in een Mapbox stijlbestand.
     *
     * @param styleUrl - De URL naar het Mapbox stijlbestand.
     * @returns De laagste maxzoom waarde van alle bronnen indien beschikbaar, anders undefined.
     */
    async getMaxZoomFromStyleUrl(styleUrl) {
        let json;
        try {
            json = await this.getJsonFromUrl(styleUrl);
        }
        catch (e) {
            console.error(`Could not get the json from the style url ${styleUrl}`);
            return undefined;
        }
        const sources = json.sources;
        if (sources) {
            const maxZooms = [];
            for (const key in sources) {
                const source = sources[key];
                if (source.maxzoom) {
                    maxZooms.push(source.maxzoom);
                }
                else if (source.tiles) {
                    for (const tileUrl of source.tiles) {
                        const result = await this.getMaxZoomFromUrl(tileUrl);
                        if (result) {
                            maxZooms.push(result);
                        }
                    }
                }
            }
            if (maxZooms.length > 0) {
                return Math.min(...maxZooms);
            }
        }
        return undefined;
    }
    /**
     * Voert een HTTP GET request uit naar een URL en retourneert de JSON response.
     * Wordt gebruikt voor tilejson en stijlbestanden.
     */
    async getJsonFromUrl(url) {
        try {
            const response$ = this.httpClient.get(url);
            return await firstValueFrom(response$);
        }
        catch (e) {
            console.error(`Could not fetch JSON from ${url}`);
            throw new Error(`Could not fetch JSON from ${url}`);
        }
    }
    /**
     * Filterfunctie om te bepalen of een laag overeenkomt met de huidige OpenLayers laag.
     * Wordt gebruikt bij feature selectie.
     */
    decideLayerCandidate(layerCandidate) {
        return this.olLayer === layerCandidate;
    }
    /**
     * Verwerkt een klik op de kaart en haalt feature informatie op.
     * Emit een MapComponentEvent met gevonden features.
     */
    getFeatureInfo(event) {
        const pixel = event.pixel;
        this.map.forEachFeatureAtPixel(pixel, (feature) => this.limitFeatures(feature), {
            layerFilter: this.decideLayerCandidate.bind(this),
            hitTolerance: this.options?.hitTolerance
        });
        const foundFeaturesCopy = this.foundFeatures.slice();
        this.coreSelectionService.handleFeatureInfoForLayer(this.mapIndex, foundFeaturesCopy, this.getLayerId());
        const mapComponentEvent = new MapComponentEvent$1(MapComponentEventTypes$1.VECTORFEATUREINFO, this.mapIndex, "VectorTileLayer getFeatureInfo resultaten: ", this.layerName, foundFeaturesCopy);
        this.events.emit(mapComponentEvent);
        this.foundFeatures = [];
    }
    /**
     * Beperkt het aantal geselecteerde features bij een klik tot een maximum.
     * Voegt geldige features toe aan de interne lijst.
     */
    limitFeatures(feature) {
        if (this.foundFeatures.length < this.maxFeaturesOnSingleclick) {
            // feature as Feature, because VectorTileSource contains Features. RenderFeatures are used for VectorTileLayer
            this.foundFeatures.push(feature);
        }
    }
    /**
     * Laadt een Mapbox stijlbestand en past de stijl toe op de vector tile laag.
     * Ondersteunt meerdere bronnen in het stijlbestand.
     */
    async loadStyle(url) {
        try {
            const json = await this.getJsonFromUrl(url);
            Object.keys(json.sources).forEach((key) => {
                applyStyle(this.olLayer, json, key);
            });
        }
        catch (e) {
            console.error(`Failed to load style from ${url}`);
        }
    }
    /**
     * Past de stijl toe op de vector tile layer. Ondersteunt zowel string URL als OL stijlobject.
     *
     * @param layer - De VectorTileLayer waarop de stijl wordt toegepast.
     * @param updateOverzoomSettings - Of overzoom instellingen moeten worden bijgewerkt.
     */
    setStyle(layer, updateOverzoomSettings = true) {
        if (typeof this.options?.style === "string") {
            this.loadStyle(this.options?.style);
        }
        else {
            layer.setStyle(this.options?.style || this.options?.layerOptions?.style);
        }
        if (updateOverzoomSettings && this.options?.enableOverzoom) {
            this.updateOverzoomSettings(layer);
        }
    }
    /**
     * Angular lifecycle hook die wordt aangeroepen bij het vernietigen van de component.
     * Roept de parent destructor aan.
     */
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    /**
     * Angular lifecycle hook die wordt aangeroepen bij wijzigingen in input properties.
     * Past stijl aan indien opties of stijl zijn gewijzigd.
     */
    ngOnChanges(changes) {
        if (changes.style && this.olLayer) {
            this.setStyle(this.olLayer);
        }
        if (changes.options && !changes.options.firstChange) {
            if (this.options?.layerOptions?.style !==
                changes.options.previousValue.layerOptions?.style) {
                this.setStyle(this.olLayer);
            }
            if (this.options?.style !== changes.options.previousValue.style) {
                this.setStyle(this.olLayer);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcVectorTileLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcVectorTileLayerComponent, isStandalone: true, selector: "ggc-vector-tile-layer", inputs: { options: "options" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcVectorTileLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-vector-tile-layer",
                    template: ""
                }]
        }], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Verwerkt WMS-capabilities en haalt de URL op voor `GetFeatureInfo`-requests.
 */
class Capabilities {
    /**
     * Initialiseert een nieuwe instantie van Capabilities met de opgegeven capabilities.
     * @param cap Het capabilities-object zoals verkregen uit een WMS GetCapabilities-response.
     */
    constructor(cap) {
        this.setFeatureInfoUrl(cap);
    }
    /**
     * Geeft de URL terug die gebruikt wordt voor `GetFeatureInfo`.
     * @returns De `GetFeatureInfo`-URL als string.
     */
    getFeatureInfoUrl() {
        return this.featureInfoUrl;
    }
    /**
     * Stelt de `featureInfoUrl` in op basis van het capabilities-object.
     * @param cap Het capabilities-object.
     */
    setFeatureInfoUrl(cap) {
        this.featureInfoUrl =
            cap?.OperationsMetadata?.GetFeatureInfo?.DCP?.HTTP?.Get &&
                cap.OperationsMetadata.GetFeatureInfo.DCP.HTTP.Get.length > 0 &&
                cap.OperationsMetadata.GetFeatureInfo.DCP.HTTP.Get["0"]?.href;
    }
}

/**
 * Service voor het ophalen en verwerken van WMS/WMTS capabilities.
 * Ondersteunt caching van capabilities per URL en het genereren van GetFeatureInfo requests.
 */
class CoreWmsWmtsCapabilitiesService {
    constructor() {
        this.httpClient = inject(HttpClient);
        this.capabilitiesMap = new Map();
    }
    /**
     * Haalt capabilities op voor een gegeven URL en service type.
     * Ondersteunt caching en het delen van observables.
     *
     * @param baseUrl - De URL van de capabilities endpoint.
     * @param service - Het type service: `"WMTS"` of `"WMS"`.
     * @param withCredentials - Of credentials moeten worden meegestuurd.
     * @returns Observable met de capabilities data.
     */
    getCapabilitiesForUrl(baseUrl, service, withCredentials = false) {
        let format;
        const params = {
            request: "getCapabilities",
            service
        };
        if (service === "WMTS") {
            format = new WMTSCapabilities();
        }
        else {
            format = new WMSCapabilities();
            params.version = "1.3.0";
        }
        if (this.capabilitiesMap.has(baseUrl)) {
            return this.capabilitiesMap.get(baseUrl);
        }
        else {
            const observable = this.httpClient
                .get(baseUrl, {
                responseType: "text",
                params,
                withCredentials
            })
                .pipe(map((res) => format.read(res)), shareReplay(1));
            this.capabilitiesMap.set(baseUrl, observable);
            return observable;
        }
    }
    /**
     * Genereert WMTS opties uit capabilities en configuratie.
     *
     * @param wmtsCapabilities - De capabilities zoals gelezen met WMTSCapabilities.
     * @param config - Configuratie voor de laag.
     * @returns Options object voor WMTS.
     */
    optionsFromCapabilities(wmtsCapabilities, config) {
        return optionsFromCapabilities(wmtsCapabilities, config);
    }
    /**
     * Controleert of de capabilities een GetFeatureInfo URL bevatten.
     *
     * @param capabilities - De capabilities.
     * @returns `true` als een GetFeatureInfo URL beschikbaar is.
     */
    hasFeatureInfoUrl(capabilities) {
        return !!capabilities.getFeatureInfoUrl();
    }
    /**
     * Maakt een observable voor een GetFeatureInfo request.
     *
     * @param baseUrl - De URL van de WMTS service.
     * @param source - De WMTS bron.
     * @param coordinate - De Coordinate waarop info gewenst is.
     * @param resolution - De resolutie van de kaart.
     * @returns Observable met de response van de GetFeatureInfo request.
     */
    createGetFeatureInfoUrlObservable(baseUrl, source, coordinate, resolution) {
        const baseParams = this.constructGetFeatureInfoParams(source, coordinate, resolution);
        return this.httpClient.get(baseUrl, { params: baseParams });
    }
    /**
     * Genereert de parameters voor een GetFeatureInfo request.
     *
     * @param source - De WMTS bron.
     * @param coordinate - De Coordinate waarop info gewenst is.
     * @param resolution - De resolutie van de kaart.
     * @returns Object met query parameters.
     */
    constructGetFeatureInfoParams(source, coordinate, resolution) {
        const tileGrid = source.getTileGrid();
        const tileCoord = tileGrid.getTileCoordForCoordAndResolution(coordinate, resolution);
        const tileCol = tileCoord[1];
        const tileRow = tileCoord[2];
        const tileExtent = tileGrid.getTileCoordExtent(tileCoord);
        const tileResolution = tileGrid.getResolution(tileCoord[0]);
        const zoom = tileGrid.getZForResolution(tileResolution);
        const i = Math.floor((coordinate[0] - tileExtent[0]) / tileResolution);
        const j = Math.floor((tileExtent[3] - coordinate[1]) / tileResolution);
        return {
            SERVICE: "WMTS",
            VERSION: "1.0.0",
            REQUEST: "GetFeatureInfo",
            LAYER: source.getLayer(),
            STYLE: "",
            FORMAT: "image/png",
            TileCol: "" + tileCol,
            TileRow: "" + tileRow,
            TileMatrix: source.getMatrixSet() + ":" + zoom,
            TileMatrixSet: source.getMatrixSet(),
            I: "" + i,
            J: "" + j,
            infoformat: "application/json",
            info_format: "application/json",
            FEATURE_COUNT: "8"
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreWmsWmtsCapabilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreWmsWmtsCapabilitiesService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreWmsWmtsCapabilitiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Controleert of een opgegeven `viewResolution` binnen het bereik valt van een laag,
 * gedefinieerd door optionele `minResolution` en `maxResolution` waarden.
 *
 * @param viewResolution - De resolutie van de huidige view (bijvoorbeeld kaartzoomniveau).
 * @param minResolution - (Optioneel) De minimale resolutie waarbij de laag zichtbaar moet zijn.
 * @param maxResolution - (Optioneel) De maximale resolutie waarbij de laag zichtbaar moet zijn.
 * @returns `true` als `viewResolution` binnen het bereik valt (groter dan of gelijk aan `minResolution`
 * en kleiner dan `maxResolution`), anders `false`.
 *
 * @example
 * ```ts
 * viewResolutionIsInLayerResolutionRange(50, 30, 100); // true
 * viewResolutionIsInLayerResolutionRange(20, 30, 100); // false
 * viewResolutionIsInLayerResolutionRange(120, undefined, 150); // true
 * ```
 */
const viewResolutionIsInLayerResolutionRange = (viewResolution, minResolution, maxResolution) => {
    const minResCheck = minResolution
        ? viewResolution >= minResolution
        : true;
    const maxResCheck = maxResolution
        ? viewResolution < maxResolution
        : true;
    return minResCheck && maxResCheck;
};

/**
 * Door `<ggc-wmts-layer></ggc-wmts-layer>` op te nemen in de HTML kunnen WMTS-kaarten
 * worden toegevoegd, bijvoorbeeld afkomstig van PDOK. Binnen deze tags kunnen onder
 * andere de WMTS url, de gewenste kaartlaag en de minimale- en maximale resolutie
 * worden ingesteld.
 *
 * @example
 * <ggc-wmts-layer [options]="wmtsOptions"></ggc-wmts-layer>
 */
class GgcWmtsLayerComponent extends AbstractClickableLayerComponent {
    constructor() {
        super(...arguments);
        /**
         * Injectie van de CoreWmsWmtsCapabilitiesService.
         */
        this.capabilitiesService = inject(CoreWmsWmtsCapabilitiesService);
    }
    /**
     * Angular lifecycle hook die wordt aangeroepen bij initialisatie van de component.
     * Haalt WMTS-capabilities op en configureert de laag op basis van de opgehaalde gegevens.
     */
    ngOnInit() {
        super.ngOnInit();
        if (this.options != undefined && this.options?.layer == undefined) {
            this.options.layer = this.options?.layerName;
        }
        if (this.options?.getFeatureInfoOnSingleclick === true) {
            this.singleclick = this.mapEventsService
                .getSingleclickObservableForMap(this.mapIndex)
                .subscribe((evt) => {
                this.getFeatureInfo(evt);
            });
        }
        if (this.options?.maxFeaturesOnSingleclick !== undefined) {
            this.maxFeaturesOnSingleclick = this.options?.maxFeaturesOnSingleclick;
        }
        this.capabilitiesSubscription = this.capabilitiesService
            .getCapabilitiesForUrl(this.options?.url ||
            this.options?.sourceOptions?.url, "WMTS")
            .subscribe((result) => {
            if (result) {
                this.capabilities = new Capabilities(result);
                const options = this.capabilitiesService.optionsFromCapabilities(result, {
                    format: "image/png",
                    style: "default",
                    crossOrigin: "anonymous",
                    ...this.options?.sourceOptions,
                    ...(this.options?.layer && { layer: this.options?.layer }),
                    projection: this.rdNewConfig.projectionCode
                });
                if (options) {
                    // Set transition to 0 when opacity < 1 to prevent flicker
                    const opacity = this.options?.layerOptions?.opacity;
                    if (opacity !== undefined && opacity < 1) {
                        options.transition = 0;
                        this.layerOptions.opacity = opacity;
                    }
                    this.wmtsSource = new WMTS(options);
                    this.setLayer(new TileLayer({
                        ...this.options?.layerOptions,
                        ...this.layerOptions,
                        source: this.wmtsSource
                    }));
                }
                else {
                    this.capabilities = undefined;
                    console.error("Could not generate options from capabilities");
                }
                this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.WMTSCAPABILITES, this.mapIndex, "WMTS capabilities resultaten: ", this.layerName, result));
            }
            else {
                this.capabilities = undefined;
                console.error("Invalid capabilities");
            }
        });
    }
    /**
     * Verwerkt een klik op de kaart en haalt feature info op via WMTS indien beschikbaar.
     *
     * @param evt - Het MapBrowserEvent dat de klik representeert.
     */
    getFeatureInfo(evt) {
        const coordinate = evt.coordinate;
        const viewResolution = this.map.getView().getResolution();
        if (viewResolution &&
            viewResolutionIsInLayerResolutionRange(viewResolution, this.olLayer.getMinResolution(), this.olLayer.getMaxResolution())) {
            if (this.capabilities &&
                this.capabilitiesService.hasFeatureInfoUrl(this.capabilities)) {
                const featureInfoObservable = this.capabilitiesService.createGetFeatureInfoUrlObservable(this.options?.url ||
                    this.options?.sourceOptions?.url, this.wmtsSource, coordinate, viewResolution);
                featureInfoObservable.subscribe((data) => {
                    const formatGeoJSON = new GeoJSON$1();
                    const features = formatGeoJSON.readFeatures(data);
                    this.emitFeatureInfoEvent(features, coordinate);
                }, () => {
                    this.emitFeatureInfoEvent([], coordinate);
                });
            }
            else {
                this.emitFeatureInfoEvent([], coordinate);
            }
        }
        else {
            this.emitFeatureInfoEvent([], coordinate);
        }
    }
    /**
     * Emit een event met de opgehaalde features en coördinaten.
     *
     * @param features - De gevonden features.
     * @param coordinate - De locatie van de klik.
     */
    emitFeatureInfoEvent(features, coordinate) {
        this.coreSelectionService.handleFeatureInfoForLayer(this.mapIndex, features, this.getLayerId());
        this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.WMTSFEATUREINFO, this.mapIndex, "WMTS getFeatureInfo resultaten: ", this.layerName, features));
    }
    /**
     * Angular lifecycle hook die wordt aangeroepen bij het vernietigen van de component.
     * Zorgt voor het opruimen van subscriptions.
     */
    ngOnDestroy() {
        if (this.capabilitiesSubscription !== undefined) {
            this.capabilitiesSubscription.unsubscribe();
        }
        this.unsubscribeOnClickEvent();
        super.ngOnDestroy();
    }
    enable() {
        super.enable();
        this.subscribeOnClickEvent();
    }
    disable() {
        super.disable();
        this.unsubscribeOnClickEvent();
    }
    subscribeOnClickEvent() {
        this.unsubscribeOnClickEvent();
        if (this.options?.getFeatureInfoOnSingleclick === true) {
            this.singleclick = this.mapEventsService
                .getSingleclickObservableForMap(this.mapIndex)
                .subscribe((evt) => {
                this.getFeatureInfo(evt);
            });
        }
    }
    unsubscribeOnClickEvent() {
        if (this.singleclick !== undefined) {
            this.singleclick.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmtsLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcWmtsLayerComponent, isStandalone: true, selector: "ggc-wmts-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmtsLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-wmts-layer",
                    template: ""
                }]
        }], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Door `<ggc-wms-layer></ggc-wms-layer>` op te nemen in de HTML kunnen WMS-kaarten
 * worden toegevoegd, bijvoorbeeld afkomstig van PDOK. Binnen deze tags kunnen
 * onder andere de WMS url, de gewenste kaartlagen en de minimale- en maximale
 * resolutie worden ingesteld en events worden opgevangen. Ook kan ingesteld worden
 * dat de WMS-kaart als tiled-WMS wordt weergegeven.
 *
 * @example
 * <ggc-wms-layer [options]="wmsLayerOptions"></ggc-wms-layer>
 */
class GgcWmsLayerComponent extends AbstractClickableLayerComponent {
    constructor() {
        super(...arguments);
        this.capabilitiesService = inject(CoreWmsWmtsCapabilitiesService);
        this.httpClient = inject(HttpClient);
    }
    /** Initialiseert de WMS-laag en haalt optioneel capabilities op. */
    ngOnInit() {
        super.ngOnInit();
        if (this.options != undefined && this.options?.layers == undefined) {
            this.options.layers = this.options?.layerName;
        }
        this.enable();
        if (this.options?.maxFeaturesOnSingleclick !== undefined) {
            this.maxFeaturesOnSingleclick = this.options?.maxFeaturesOnSingleclick;
        }
        const urlForCapabilities = this.options?.url || this.options?.sourceOptions?.url;
        if (this.options?.getCapabilities !== false && urlForCapabilities) {
            this.capabilitiesService
                .getCapabilitiesForUrl(urlForCapabilities, "WMS", this.options?.sourceOptions?.crossOrigin === "withCredentials")
                .subscribe((result) => {
                this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.WMSCAPABILITIES, this.mapIndex, "WMS capabilities resultaten:", this.layerName, result));
            }, noop);
        }
        const params = this.makeParamsKeysUppercase({
            ...this.options?.sourceOptions?.params,
            ...(this.options?.layers && { layers: this.options?.layers })
        });
        this.addDpiToParams(params, DEVICE_PIXEL_RATIO);
        const sourceOptions = {
            crossOrigin: "anonymous",
            serverType: "geoserver",
            ...this.options?.sourceOptions,
            params,
            ...(this.options?.url && { url: this.options?.url }),
            projection: this.rdNewConfig.projectionCode
        };
        const layerOptions = {
            ...this.options?.layerOptions,
            ...this.layerOptions
        };
        if (this.options?.tiled) {
            if (this.options?.gutter) {
                // set gutter to prevent that icons and labels are clipped at the edges of the tiles.
                sourceOptions.gutter = this.options.gutter;
            }
            this.wmsSource = new TileWMS(sourceOptions);
            layerOptions.source = this.wmsSource;
            this.setLayer(new TileLayer(layerOptions));
        }
        else {
            this.wmsSource = new ImageWMS(sourceOptions);
            layerOptions.source = this.wmsSource;
            this.setLayer(new ImageLayer(layerOptions));
        }
    }
    /**
     * Voert een `GetFeatureInfo` request uit op basis van een klik op de kaart.
     * @param evt Het MapBrowserEvent met kliklocatie.
     */
    getFeatureInfo(evt) {
        const coordinate = evt.coordinate;
        const viewResolution = this.map.getView().getResolution();
        if (viewResolution &&
            viewResolutionIsInLayerResolutionRange(viewResolution, this.olLayer.getMinResolution(), this.olLayer.getMaxResolution())) {
            const querylayers = this.options?.getFeatureInfoQueryLayers ||
                this.options?.layers ||
                this.options?.sourceOptions?.params?.layers;
            const featureInfoUrl = this.wmsSource.getFeatureInfoUrl(coordinate, viewResolution, this.rdNewConfig.projectionCode, {
                INFO_FORMAT: "application/json",
                // query_layers lijkt voor sommige wms-en nodig
                QUERY_LAYERS: querylayers,
                FEATURE_COUNT: this.maxFeaturesOnSingleclick
            });
            if (featureInfoUrl === undefined) {
                this.emitFeatureInfoEvent([], coordinate, "Geen featureInfoUrl gevonden");
            }
            else {
                this.httpClient.get(featureInfoUrl).subscribe((data) => {
                    const formatGeoJSON = new GeoJSON$1();
                    const features = formatGeoJSON.readFeatures(data);
                    this.emitFeatureInfoEvent(features, coordinate);
                }, (error) => {
                    this.emitFeatureInfoEvent([], coordinate, "Kon geen features ophalen van featureInfoUrl vanwege " +
                        error.statusText);
                });
            }
        }
        else {
            this.emitFeatureInfoEvent([], coordinate, "Binnen deze resolutie zijn er geen features gevonden.");
        }
    }
    /** Verwijdert de laag en voert opruimacties uit. */
    ngOnDestroy() {
        super.ngOnDestroy();
        this.unsubscribeOnClickEvent();
    }
    /**
     * Past meerdere stijlen toe op de WMS-laag.
     * @param styles Een array van stijlstrings.
     */
    setStyles(styles) {
        this.wmsSource.updateParams({ STYLES: styles });
        this.updateLocalSourceOptionsFromWmsSource();
    }
    /**
     * Past een specifieke stijl toe op een specifieke sublaag.
     * @param style De stijlnaam.
     * @param layerName De naam van de sublaag waarop de stijl moet worden toegepast.
     */
    setStyle(style, layerName) {
        const currentParams = this.wmsSource.getParams();
        const currentLayers = Object.entries(currentParams)
            .filter(([key, item]) => key.toLowerCase() === "layers")
            .map((items) => items[1])[0];
        const currentStyles = Object.entries(currentParams)
            .filter(([key, item]) => key.toLowerCase() === "styles")
            .map((items) => items[1])[0];
        if (typeof currentLayers === "string") {
            if (currentLayers === layerName) {
                this.wmsSource.updateParams({ STYLES: style });
                this.updateLocalSourceOptionsFromWmsSource();
            }
        }
        else if (Array.isArray(currentLayers)) {
            const index = currentLayers.indexOf(layerName);
            if (index == -1) {
                return;
            }
            let newStyles;
            if (Array.isArray(currentStyles)) {
                // The styles array is already created
                newStyles = currentStyles.with(index, style);
            }
            else {
                // Create the style array with the necessary size
                newStyles = new Array(currentLayers.length).fill("");
                newStyles[index] = style;
            }
            this.wmsSource.updateParams({ STYLES: newStyles });
            this.updateLocalSourceOptionsFromWmsSource();
        }
    }
    enable() {
        super.enable();
        this.subscribeOnClickEvent();
    }
    disable() {
        super.disable();
        this.unsubscribeOnClickEvent();
    }
    subscribeOnClickEvent() {
        this.unsubscribeOnClickEvent();
        if (this.options?.getFeatureInfoOnSingleclick === true) {
            this.singleclick = this.mapEventsService
                .getSingleclickObservableForMap(this.mapIndex)
                .subscribe((evt) => {
                this.getFeatureInfo(evt);
            });
        }
    }
    unsubscribeOnClickEvent() {
        if (this.singleclick !== undefined) {
            this.singleclick.unsubscribe();
        }
    }
    /** Werkt de lokale sourceOptions.params bij op basis van de WMS-bron. */
    updateLocalSourceOptionsFromWmsSource() {
        this.options = this.options ?? {};
        this.options.sourceOptions = this.options.sourceOptions ?? {};
        this.options.sourceOptions.params = this.wmsSource.getParams();
    }
    /**
     * Emit een feature info event met de opgehaalde features.
     * @param features De gevonden features.
     * @param coordinate De kliklocatie.
     * @param message Optioneel bericht.
     */
    emitFeatureInfoEvent(features, coordinate, message = "WMS getFeatureInfo resultaten: ") {
        this.coreSelectionService.handleFeatureInfoForLayer(this.mapIndex, features, this.getLayerId());
        this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.WMSFEATUREINFO, this.mapIndex, message, this.layerName, features));
    }
    /**
     * Voegt DPI-gerelateerde parameters toe aan de WMS-request.
     * @param params De bestaande WMS-parameters.
     * @param DEVICE_PIXEL_RATIO De pixelratio van het apparaat.
     */
    addDpiToParams(params, DEVICE_PIXEL_RATIO) {
        // Pixelratio conform openlayers
        // https://github.com/openlayers/openlayers/blob/v8.2.0/src/ol/source/wms.js#L90
        if (DEVICE_PIXEL_RATIO !== 1) {
            const dpi = Math.floor(90 * DEVICE_PIXEL_RATIO + 0.5);
            params.DPI = dpi;
            params.MAP_RESOLUTION = dpi;
        }
    }
    /**
     * Zet alle keys van de WMS-parameters om naar hoofdletters.
     * @param params De originele parameters.
     * @returns De aangepaste parameters met hoofdletter-keys.
     */
    makeParamsKeysUppercase(params) {
        const paramsUppercase = {};
        Object.entries(params).forEach(([key, param]) => {
            paramsUppercase[key.toUpperCase()] = param;
        });
        return paramsUppercase;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmsLayerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcWmsLayerComponent, isStandalone: true, selector: "ggc-wms-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmsLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-wms-layer",
                    template: ""
                }]
        }], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Door `<ggc-layer-brt-achtergrondkaart></ggc-layer-brt-achtergrondkaart>` op te
 * nemen in de HTML wordt de brt achtergrondkaart toegevoegd aan de kaart.
 *
 * @example
 * <ggc-layer-brt-achtergrondkaart [mapIndex]="'kaart1'"></ggc-layer-brt-achtergrondkaart>
 */
class GgcLayerBrtAchtergrondkaartComponent extends AbstractBaseLayerComponent {
    /**
     * Initialisatie van de WMTS-laag bij het laden van de component.
     * De BRT Achtergrondkaart wordt geconfigureerd met een tileGrid op basis van RD-coördinaten.
     */
    ngOnInit() {
        super.ngOnInit();
        const brtsource = new WMTS({
            projection: this.rdNewConfig.projectionCode,
            layer: "standaard",
            format: "image/png",
            url: "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0?",
            matrixSet: this.rdNewConfig.matrixSet,
            style: "default",
            crossOrigin: "anonymous",
            tileGrid: new WMTSTileGrid({
                extent: this.rdNewConfig.extent,
                resolutions: this.rdNewConfig.resolutions,
                matrixIds: this.rdNewConfig.matrixIds
            })
        });
        this.setLayer(new TileLayer({
            source: brtsource,
            minResolution: 0.21 // BRT Achtergrondkaart is niet beschikbaar onder deze resolutie
        }));
        this.olLayer.set("ggc-layer-id", this.getLayerId());
    }
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLayerBrtAchtergrondkaartComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcLayerBrtAchtergrondkaartComponent, isStandalone: true, selector: "ggc-layer-brt-achtergrondkaart", inputs: { mapIndex: "mapIndex" }, usesInheritance: true, ngImport: i0, template: "", isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLayerBrtAchtergrondkaartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "ggc-layer-brt-achtergrondkaart",
                    template: ""
                }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }] } });

/**
 * Centrale service voor het beheren van kaartlagen binnen GGC.
 *
 * Verantwoordelijkheden:
 * - Laden en configureren van webservices en lagen
 * - Dynamisch toevoegen/verwijderen van kaartlagen
 * - Synchroniseren van layer‑wijzigingen en legenda‑events
 * - Bieden van query‑API’s voor zichtbaarheid, status en metadata
 *
 * Deze service fungeert als orchestrator tussen:
 * - configuratie (Webservice / LayerOptions)
 * - OpenLayers Map
 * - UI‑componenten (legenda, toggles)
 */
class GgcLayerService {
    /**
     * Initialiseert de service en luistert naar
     * layer changes vanuit de GgcMapService.
     */
    constructor() {
        this.mapService = inject(CoreMapService);
        this.appRef = inject(ApplicationRef);
        this.layerChangedSubject = new Subject();
        this.legendAddedSubject = new Subject();
        this.legendRemovedSubject = new Subject();
        this.mapConfigurations = new Map();
        this.mapLayerComponents = new Map();
        this.mapService
            .getLayerChangedObservable()
            .subscribe((event) => {
            this.emitLayerChanged(event.layerId, event.mapIndex, event.eventTrigger);
        });
    }
    /**
     * Observable voor layer change events.
     */
    getLayerChangedObservable() {
        return this.layerChangedSubject.asObservable();
    }
    /**
     * Observable die wordt getriggerd
     * wanneer een legenda wordt toegevoegd.
     */
    getLegendAddedObservable() {
        return this.legendAddedSubject.asObservable();
    }
    /**
     * Observable die wordt getriggerd
     * wanneer een legenda wordt verwijderd.
     */
    getLegendRemovedObservable() {
        return this.legendRemovedSubject.asObservable();
    }
    /**
     * Geeft alle actieve legenda‑items terug voor de opgegeven kaart.
     */
    getCurrentActiveLegends(mapIndex) {
        const result = [];
        const services = this.mapConfigurations.get(mapIndex) ?? [];
        services.forEach((service) => {
            service.layers.forEach((layer) => {
                const layerId = layer.layerId;
                if (layerId && this.isVisible(layerId, mapIndex)) {
                    result.push(this.buildLayerLegend(layerId, mapIndex));
                }
            });
        });
        return result;
    }
    /**
     * Laadt een lijst van webservices
     * en voegt hun zichtbare lagen toe aan de kaart.
     */
    loadWebservices(services, mapIndex) {
        this.removeCurrentLayers(mapIndex);
        this.mapConfigurations.set(mapIndex, services);
        for (const service of services) {
            this.loadWebservice(service, mapIndex);
        }
    }
    /**
     * Voegt een BRT achtergrondkaart toe aan de kaart.
     */
    addBrtAchtergrondkaartLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            if (!layerOptions.layerId) {
                //default layerId
                layerOptions.layerId = "brt-achtergrondkaart";
            }
            const componentRef = createComponent(GgcLayerBrtAchtergrondkaartComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.mapIndex = layerOptions.mapIndex;
            componentRef.instance.ngOnInit();
            componentRef.instance["olLayer"].set("ggc-layer-id", layerOptions.layerId);
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, layerOptions.layerId);
            return layerOptions.layerId;
        }
    }
    /**
     * Voegt een laag toe aan de kaart op basis van het webservice‑type.
     */
    addLayer(layerOptions, webserviceType) {
        if (layerOptions.persistent === true &&
            layerOptions.layerId &&
            layerOptions.mapIndex) {
            const layer = this.mapService.getLayer(layerOptions.layerId, layerOptions.mapIndex);
            if (layer) {
                layer.setVisible(true);
                this.mapLayerComponents
                    .get(this.buildLayerComponentKey(layerOptions.mapIndex, layerOptions.layerId))
                    ?.enable();
                this.emitLayerChanged(layerOptions.layerId, layerOptions.mapIndex ?? DEFAULT_MAPINDEX, LayerChangedEventTrigger.LAYER_ADDED);
                return layerOptions.layerId;
            }
        }
        switch (webserviceType) {
            case Webservice2DType.GEOJSON:
                return this.addGeojsonLayer(layerOptions);
            case Webservice2DType.IMAGE:
                return this.addImageLayer(layerOptions);
            case Webservice2DType.VECTOR:
                return this.addVectorTileLayer(layerOptions);
            case Webservice2DType.WMS:
                return this.addWmsLayer(layerOptions);
            case Webservice2DType.WMTS:
                return this.addWmtsLayer(layerOptions);
            default:
                return undefined;
        }
    }
    /**
     * Voegt een geojson laag toe aan de kaart.
     */
    addGeojsonLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            const componentRef = createComponent(GgcGeojsonLayerComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.options = layerOptions;
            componentRef.instance.ngOnInit();
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, componentRef.instance.options.layerId);
            return componentRef.instance.options.layerId;
        }
    }
    /**
     * Voegt een image laag toe aan de kaart.
     */
    addImageLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            const componentRef = createComponent(GgcImageLayerComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.options = layerOptions;
            componentRef.instance.ngOnInit();
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, componentRef.instance.options.layerId);
            return componentRef.instance.options.layerId;
        }
    }
    /**
     * Voegt een vector tile laag toe aan de kaart.
     */
    addVectorTileLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            const componentRef = createComponent(GgcVectorTileLayerComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.options = layerOptions;
            componentRef.instance.ngOnInit();
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, componentRef.instance.options.layerId);
            return componentRef.instance.options.layerId;
        }
    }
    /**
     * Voegt een wms laag toe aan de kaart.
     */
    addWmsLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            const componentRef = createComponent(GgcWmsLayerComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.options = layerOptions;
            componentRef.instance.ngOnInit();
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, componentRef.instance.options.layerId);
            return componentRef.instance.options.layerId;
        }
    }
    /**
     * Voegt een wmts laag toe aan de kaart.
     */
    addWmtsLayer(layerOptions) {
        if (layerOptions.mapIndex) {
            const componentRef = createComponent(GgcWmtsLayerComponent, {
                environmentInjector: this.appRef.injector
            });
            componentRef.instance.options = layerOptions;
            componentRef.instance.ngOnInit();
            this.addLayerComponentToMapLayerComponents(componentRef.instance, layerOptions.mapIndex, componentRef.instance.options.layerId);
            return componentRef.instance.options.layerId;
        }
    }
    /**
     * Verwijdert een laag van de kaart en triggert een layer removed event.
     * Als er een selectie actief is in de SelectionService, wordt deze ook leeggehaald.
     */
    removeLayer(mapIndex, layerId) {
        const layer = this.mapService.getLayer(layerId, mapIndex);
        if (layer) {
            if (layer.get("persistent") === true) {
                layer.setVisible(false);
            }
            else {
                this.mapService.getMap(mapIndex).removeLayer(layer);
            }
            this.mapLayerComponents
                .get(this.buildLayerComponentKey(mapIndex, layerId))
                ?.disable();
            // the layer service will automatically react on this event
            this.mapService.emitLayerChangedEvent(layerId, mapIndex, LayerChangedEventTrigger.LAYER_REMOVED);
        }
    }
    /**
     * Vraagt een laag op van de kaart.
     */
    getLayer(layerId, mapIndex = DEFAULT_MAPINDEX) {
        return this.mapService.getLayer(layerId, mapIndex);
    }
    /**
     * Geeft de titel van een laag terug op basis van de configuratie.
     */
    getTitle(layerId, mapIndex = DEFAULT_MAPINDEX) {
        return this.getLayerConfig(layerId, mapIndex)?.title;
    }
    /**
     * Geeft de legenda‑index van een laag terug.
     *
     * De legenda‑index bepaalt de volgorde waarin legenda‑items
     * worden weergegeven in de gebruikersinterface.
     */
    getLegendIndex(layerId, mapIndex = DEFAULT_MAPINDEX) {
        return this.getLayerConfig(layerId, mapIndex)?.legendIndex;
    }
    /**
     * Controleert of een laag zichtbaar is.
     */
    isVisible(layerId, mapIndex = DEFAULT_MAPINDEX) {
        return this.mapService.getLayer(layerId, mapIndex)?.getVisible() ?? false;
    }
    /**
     * Wisselt de zichtbaarheid van een laag.
     */
    toggleVisibility(layerId, mapIndex = DEFAULT_MAPINDEX) {
        if (this.isVisible(layerId, mapIndex)) {
            this.removeLayer(mapIndex, layerId);
        }
        else {
            this.addLayerFromMapConfig(layerId, mapIndex);
        }
        return this.isVisible(layerId, mapIndex);
    }
    /**
     * Bepaalt of een laag momenteel *enabled* is op basis van resolutie.
     *
     * Een laag wordt als enabled beschouwd wanneer de huidige kaartresolutie
     * binnen de minimale en maximale resolutiegrenzen van de laag valt.
     *
     * De resolutiegrenzen worden:
     * - bij voorkeur gehaald uit de actieve OpenLayers layer
     * - anders uit de laagconfiguratie
     */
    getEnabled(layerId, mapIndex = DEFAULT_MAPINDEX) {
        let minResolution;
        let maxResolution;
        const layer = this.getLayer(layerId, mapIndex);
        if (layer) {
            minResolution = layer.getMinResolution();
            maxResolution = layer.getMaxResolution();
        }
        else {
            const layerConfig = this.getLayerConfig(layerId, mapIndex);
            if (!layerConfig) {
                return undefined;
            }
            minResolution = layerConfig.minResolution ?? 0;
            maxResolution = layerConfig.maxResolution ?? Infinity;
        }
        const viewResolution = this.mapService
            .getMap(mapIndex)
            .getView()
            .getResolution();
        if (viewResolution) {
            return viewResolutionIsInLayerResolutionRange(viewResolution, minResolution, maxResolution);
        }
        else {
            return undefined;
        }
    }
    /**
     * Zet de zichtbaarheid van meerdere lagen tegelijkertijd.
     *
     * Per laag wordt gecontroleerd of:
     * - deze toegevoegd moet worden (visible = true)
     * - of verwijderd moet worden (visible = false)
     *
     * De methode is idempotent: er worden geen dubbele add/remove acties uitgevoerd.
     */
    setVisibilityLayers(layerIds, visible, mapIndex = DEFAULT_MAPINDEX) {
        layerIds
            .filter((layerId) => layerId !== undefined)
            .forEach((layerId) => {
            if (visible && !this.isVisible(layerId, mapIndex)) {
                this.addLayerFromMapConfig(layerId, mapIndex);
            }
            else if (!visible && this.isVisible(layerId, mapIndex)) {
                this.removeLayer(mapIndex, layerId);
            }
        });
    }
    /**
     * Geeft het webservice‑type van een laag terug.
     *
     * Het type wordt bepaald aan de hand van de configuratie
     * van de webservice waarin de laag is gedefinieerd.
     */
    getTypeOfLayer(layerId, mapIndex) {
        return this.mapConfigurations.get(mapIndex)?.find((service) => {
            return service.layers.some((layer) => {
                return layer.layerId === layerId;
            });
        })?.type;
    }
    /**
     * Haalt de configuratie van een laag op.
     *
     * De configuratie bevat metadata zoals:
     * - titel
     * - legendainformatie
     * - resolutie‑instellingen
     */
    getLayerConfig(layerId, mapIndex) {
        return this.mapConfigurations
            .get(mapIndex)
            ?.flatMap((service) => service.layers)
            .find((layer) => layer.layerId === layerId);
    }
    /**
     * Initialiseert lagen van één webservice en voegt deze toe aan de kaart
     */
    loadWebservice(service, mapIndex) {
        service.layers = service.layers.map((layerOptions) => {
            const updatedLayer = {
                ...layerOptions,
                url: service.url,
                customHeaders: service.customHeaders,
                mapIndex: mapIndex,
                visible: layerOptions.visible ?? true
            };
            if (updatedLayer.visible) {
                this.addLayer(updatedLayer, service.type);
            }
            return updatedLayer;
        });
    }
    removeCurrentLayers(mapIndex) {
        const configuration = this.mapConfigurations.get(mapIndex);
        if (configuration) {
            configuration.forEach((service) => {
                service.layers.forEach((layer) => {
                    if (layer.layerId) {
                        this.removeLayer(mapIndex, layer.layerId);
                    }
                });
            });
        }
    }
    /**
     * Emit een event dat aangeeft dat een legenda is toegevoegd.
     */
    emitLegendAddedEvent(layerId, mapIndex) {
        this.legendAddedSubject.next({
            mapIndex: mapIndex,
            legend: this.buildLayerLegend(layerId, mapIndex)
        });
    }
    /**
     * Bouwt een legenda‑object op basis van de actuele laagstatus.
     *
     * Het resultaat combineert configuratie‑informatie
     * met runtime‑status (enabled / zichtbaar).
     */
    buildLayerLegend(layerId, mapIndex) {
        return {
            layerId: layerId,
            legend: this.getLayerConfig(layerId, mapIndex)?.activeLegend,
            serviceTitle: this.getServiceTitleOfLayer(layerId, mapIndex),
            layerTitle: this.getTitle(layerId, mapIndex),
            layerEnabled: this.getEnabled(layerId, mapIndex),
            legendIndex: this.getLegendIndex(layerId, mapIndex)
        };
    }
    /**
     * Geeft de titel terug van de webservice waartoe een laag behoort.
     */
    getServiceTitleOfLayer(layerId, mapIndex) {
        return this.mapConfigurations.get(mapIndex)?.find((service) => {
            return service.layers.some((layer) => {
                return layer.layerId === layerId;
            });
        })?.title;
    }
    /**
     * Emit een event dat aangeeft dat een legenda is verwijderd.
     */
    emitLegendRemovedEvent(layerId, mapIndex) {
        this.legendRemovedSubject.next({
            mapIndex: mapIndex,
            layerId: layerId
        });
    }
    /**
     * Voegt een laag toe op basis van de kaartconfiguratie.
     *
     * Wordt gebruikt bij:
     * - togglen van zichtbaarheid
     * - batch‑operaties
     */
    addLayerFromMapConfig(layerId, mapIndex) {
        const layerOptions = this.getLayerConfig(layerId, mapIndex);
        const layerType = this.getTypeOfLayer(layerId, mapIndex);
        if (!layerOptions || !layerType) {
            return;
        }
        this.addLayer(layerOptions, layerType);
    }
    /**
     * Emit een layer changed event
     * en synchroniseert legenda‑events.
     */
    emitLayerChanged(layerId, mapIndex, eventTrigger) {
        this.layerChangedSubject.next({ layerId, mapIndex, eventTrigger });
        if (eventTrigger == LayerChangedEventTrigger.LAYER_ADDED) {
            this.emitLegendAddedEvent(layerId, mapIndex);
        }
        else if (eventTrigger == LayerChangedEventTrigger.LAYER_REMOVED) {
            this.emitLegendRemovedEvent(layerId, mapIndex);
        }
    }
    addLayerComponentToMapLayerComponents(layerComponent, mapIndex, layerId) {
        this.mapLayerComponents.set(this.buildLayerComponentKey(mapIndex, layerId ?? ""), layerComponent);
    }
    /**
     * Bouwt een unieke key voor het opslaan van layer componenten
     * op basis van mapIndex en layerId.
     */
    buildLayerComponentKey(mapIndex, layerId) {
        return `${mapIndex}:${layerId}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLayerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLayerService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }], ctorParameters: () => [] });

/**
 * `<ggc-map></ggc-map>` toont een 2D kaart waar verschillende lagen aan toegevoegd
 * kunnen worden.
 *
 * Let op: om de kaarten te tonen, moet het `ggc-map` element een specifieke
 * hoogte meekrijgen vanuit CSS, zoals in het voorbeeld hieronder.
 *
 * Dit component vormt het hart van de GGC kaartarchitectuur en is
 *  verantwoordelijk voor:
 *   - initialisatie en vernietiging van de OpenLayers Map
 *   - koppelen van kaart‑events aan GGC‑events
 *   - laden van webservices en lagen
 *   - selectie, tekenen en loading‑status
 *
 * @example
 * kaartConfig = [
 *     {
 *       url: "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0?",
 *       type: "wmts",
 *       layers: [
 *         {
 *           layerId: "brtAchtergrondkaartStandaard",
 *           title: "BRT achtergrond kaart Standaard (WMTS)",
 *           layerName: "standaard",
 *           visible: true,
 *           zIndex: 0
 *         }
 *       ]
 *     }
 * ];
 *
 * <div style="height: 500px">
 *   <ggc-map [webServices]="kaartConfig"></ggc-map>
 * </div>
 */
class GgcMapComponent {
    constructor() {
        /** Unieke naam/index van de kaart */
        this.mapIndex = DEFAULT_MAPINDEX;
        /** tabIndex t.b.v. toetsenbordnavigatie */
        this.mapTabIndex = undefined;
        /** ARIA role voor accessibility */
        this.ariaRole = "application";
        /** ARIA label voor screenreaders */
        this.ariaLabel = "viewer";
        /**
         * Output event‑stream van het kaartcomponent.
         *
         * Emit o.a.:
         * - MAPINITIALIZED
         * - SINGLECLICK
         * - ZOOMEND / ZOOMENDLOCATION
         * - LOADING
         */
        this.events = new EventEmitter();
        this.eventsMap = [];
        this._minZoomlevel = 0;
        this._maxZoomlevel = 14;
        this.coreMapService = inject(CoreMapService);
        this.mapEventsService = inject(CoreMapEventsService);
        this.coreLoadingService = inject(CoreLoadingService);
        this.coreSelectionService = inject(CoreSelectionService);
        this.coreDrawService = inject(CoreDrawService, {
            optional: true
        });
        this.ggcLayerService = inject(GgcLayerService);
        // ol event type name
        this.OL_MOVEEND = "moveend";
        this.OL_SINGLECLICK = "singleclick";
        this.OL_CHANGE_RESOLUTION = "change:resolution";
        this.OL_PRECOMPOSE = "precompose";
        this.OL_RENDERCOMPLETE = "rendercomplete";
    }
    /**
     * Webservices met lagen die op de kaart geladen moeten worden.
     */
    set webServices(webservices) {
        this._webServices = webservices;
        this.loadWebservices();
    }
    /**
     * minZoomlevel van de kaart
     * Waarde wordt geclamped binnen CRS‑limieten.
     */
    set minZoomlevel(value) {
        this._minZoomlevel = Math.max(0, Math.min(GgcCrsConfigService.MAX_ZOOMLEVEL, value));
    }
    get minZoomlevel() {
        return this._minZoomlevel;
    }
    /**
     * Maximum zoomlevel van de kaart.
     * Waarde wordt geclamped binnen CRS‑limieten.
     */
    set maxZoomlevel(value) {
        this._maxZoomlevel = Math.max(1, Math.min(GgcCrsConfigService.MAX_ZOOMLEVEL, value));
    }
    get maxZoomlevel() {
        return this._maxZoomlevel;
    }
    /**
     * Initialiseert de kaart nadat de view beschikbaar is.
     *
     * - valideert zoomlevels
     * - creëert de OpenLayers map
     * - koppelt OL‑events aan GGC‑events
     */
    ngAfterViewInit() {
        if (this._minZoomlevel > this._maxZoomlevel) {
            this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.UNSUCCESSFUL, this.mapIndex, `Kaart kon niet worden geladen omdat de waarde van minZoomLevel (${this._minZoomlevel}) ` +
                `hoger is dan die van maxZoomLevel (${this._maxZoomlevel}).`));
        }
        else {
            const map = this.coreMapService.createAndGetMap(this.mapIndex, this._minZoomlevel, this._maxZoomlevel);
            map.setTarget(this.mapElement.nativeElement.id);
            this.eventsMap.push(map.on(this.OL_PRECOMPOSE, this.processEvent.bind(this)), map.on(this.OL_RENDERCOMPLETE, this.processEvent.bind(this)), map.on(this.OL_SINGLECLICK, this.processEvent.bind(this)), map.on(this.OL_MOVEEND, this.processEvent.bind(this)));
            // event on the view of this map.
            const view = map.getView();
            this.eventsMap.push(view.on(this.OL_CHANGE_RESOLUTION, this.processEvent.bind(this)));
            view.setZoom(3);
            this.initializeLoader();
            this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.MAPINITIALIZED, this.mapIndex, "Het ggc-map component is geinitialiseerd."));
        }
    }
    /**
     * Verwerkt alle OpenLayers events en vertaalt deze
     * naar GGC MapComponent events.
     */
    processEvent(mapEvent) {
        switch (mapEvent.type) {
            case this.OL_CHANGE_RESOLUTION:
                this.lastChangeResolutionEvent = mapEvent;
                break;
            case this.OL_MOVEEND: {
                const mapViewState = this.getLocationFromMapEvent(mapEvent);
                this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.ZOOMENDLOCATION, this.mapIndex, "Het zoomen is beeindigd, dit event bevat X en Y en zoomlevel.", undefined, mapViewState));
                if (this.lastChangeResolutionEvent) {
                    this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.ZOOMEND, this.mapIndex, "Het zoomen is beeindigd, dit is het laatste ol.MapEvent.", undefined, mapEvent));
                    this.lastChangeResolutionEvent = undefined;
                    this.mapEventsService.emitZoomendEventForMap(mapEvent, this.mapIndex);
                }
                break;
            }
            case this.OL_SINGLECLICK:
                // order of events is important, because the singleclick event should be emitted before
                // getFeatureInfo events on the ggc-layer componenten are emitted!
                // First emit MapComponent singleclick event and send singleclick event to the CoreSelectionService
                // then, send singleclick event on MapEventsService, because the ggc-layer componenten are subscribed to the mapEventsService
                this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.SINGLECLICK, this.mapIndex, "Er is een singleClick gegenereerd.", undefined, mapEvent));
                this.mapEventsService.emitSingleclickEventForMap(mapEvent, this.mapIndex);
                break;
        }
    }
    /**
     * Laadt webservices en hun lagen via de LayerService.
     */
    loadWebservices() {
        if (this._webServices) {
            this.ggcLayerService.loadWebservices(this._webServices, this.mapIndex);
        }
    }
    /**
     * Haalt huidige kaartpositie en zoomniveau op.
     */
    getLocationFromMapEvent(mapEvent) {
        const zoom = mapEvent.map.getView().getZoom();
        const coordinate = mapEvent.map.getView().getCenter();
        return new MapViewState$1(coordinate, zoom);
    }
    /**
     * Opruimen van events, subscriptions en map‑resources.
     */
    ngOnDestroy() {
        // Unsubscribe from Observable by key
        while (this.eventsMap.length > 0) {
            unByKey(this.eventsMap.pop());
        }
        if (this.isLoading$) {
            this.isLoading$.unsubscribe();
        }
        /* destroying the olMap, optional drawInteraction and selectionService. Destroying the OlMap itself last to prevent issues during
        destruction of the other parts */
        this.coreLoadingService.destroyLoadersForMap(this.mapIndex);
        if (this.coreDrawService) {
            this.coreDrawService.deleteLayers(this.mapIndex);
        }
        // destroying the events
        this.mapEventsService.destroyEventsForMap(this.mapIndex);
        // destroying the map
        this.coreMapService.destroyMap(this.mapIndex);
    }
    /**
     * Initialiseert de loader‑events van de kaart.
     */
    initializeLoader() {
        this.isLoading$ = this.coreLoadingService
            .isLoading(this.mapIndex)
            .subscribe((value) => {
            const message = value
                ? `De kaart is aan het laden`
                : `De kaart is klaar met laden`;
            this.events.emit(new MapComponentEvent$1(MapComponentEventTypes$1.LOADING, this.mapIndex, message, undefined, value));
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcMapComponent, isStandalone: true, selector: "ggc-map", inputs: { mapIndex: "mapIndex", mapTabIndex: "mapTabIndex", ariaRole: "ariaRole", ariaLabel: "ariaLabel", webServices: "webServices", minZoomlevel: "minZoomlevel", maxZoomlevel: "maxZoomlevel" }, outputs: { events: "events" }, viewQueries: [{ propertyName: "mapElement", first: true, predicate: ["mapElement"], descendants: true, static: true }], ngImport: i0, template: "<div\n  #mapElement\n  [id]=\"mapIndex\"\n  class=\"ggc-ol-map\"\n  [attr.tabindex]=\"mapTabIndex\"\n  [attr.role]=\"ariaRole\"\n  [attr.aria-label]=\"ariaLabel\"\n></div>\n", styles: [".ggc-ol-map{height:100%;width:100%}::ng-deep .ol-attribution li{font-size:1.1rem;line-height:1.375rem}::ng-deep .ol-viewport canvas{touch-action:none}::ng-deep .ol-hidden{display:none}::ng-deep .map-control:not(.ol-hidden){align-items:center;justify-content:center;background:transparent;display:flex;flex-direction:column;order:1;padding:2px 0;position:relative}::ng-deep .map-control:not(.ol-hidden):has(.map-control-reset){order:0}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=false]+ul{display:none}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul{align-items:flex-start;background:#fff;border:1px solid #bfcddf;border-radius:4px;display:flex;flex-direction:column;justify-content:center;min-height:3rem;position:absolute;padding:.5em 1em;right:5rem;top:0}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul li{list-style-type:none;white-space:nowrap}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul li:before{content:none}::ng-deep .ol-overlaycontainer-stopevent{align-items:flex-end;justify-content:flex-end;display:flex;flex-direction:column;padding-right:1.5em;padding-bottom:1.5em}::ng-deep .ol-overlaycontainer-stopevent .ol-overlay-container{top:0;left:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-map", template: "<div\n  #mapElement\n  [id]=\"mapIndex\"\n  class=\"ggc-ol-map\"\n  [attr.tabindex]=\"mapTabIndex\"\n  [attr.role]=\"ariaRole\"\n  [attr.aria-label]=\"ariaLabel\"\n></div>\n", styles: [".ggc-ol-map{height:100%;width:100%}::ng-deep .ol-attribution li{font-size:1.1rem;line-height:1.375rem}::ng-deep .ol-viewport canvas{touch-action:none}::ng-deep .ol-hidden{display:none}::ng-deep .map-control:not(.ol-hidden){align-items:center;justify-content:center;background:transparent;display:flex;flex-direction:column;order:1;padding:2px 0;position:relative}::ng-deep .map-control:not(.ol-hidden):has(.map-control-reset){order:0}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=false]+ul{display:none}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul{align-items:flex-start;background:#fff;border:1px solid #bfcddf;border-radius:4px;display:flex;flex-direction:column;justify-content:center;min-height:3rem;position:absolute;padding:.5em 1em;right:5rem;top:0}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul li{list-style-type:none;white-space:nowrap}::ng-deep .map-control:not(.ol-hidden) button[aria-expanded=true]+ul li:before{content:none}::ng-deep .ol-overlaycontainer-stopevent{align-items:flex-end;justify-content:flex-end;display:flex;flex-direction:column;padding-right:1.5em;padding-bottom:1.5em}::ng-deep .ol-overlaycontainer-stopevent .ol-overlay-container{top:0;left:0}\n"] }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }], mapTabIndex: [{
                type: Input
            }], ariaRole: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], events: [{
                type: Output
            }], mapElement: [{
                type: ViewChild,
                args: ["mapElement", { static: true }]
            }], webServices: [{
                type: Input
            }], minZoomlevel: [{
                type: Input
            }], maxZoomlevel: [{
                type: Input
            }] } });

class GgcWmsWmtsCapabilitiesService {
    constructor() {
        this.coreCapabilitiesService = inject(CoreWmsWmtsCapabilitiesService);
    }
    /*
     * Haalt de capabilities op voor een gegeven URL en service type.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @param service - Het type service: `"WMTS"` of `"WMS"`.
     * @returns Observable met de capabilities data.
     */
    getCapabilities(baseUrl, service) {
        return this.coreCapabilitiesService.getCapabilitiesForUrl(baseUrl, service);
    }
    /*
     * Haalt de WMS capabilities op voor een gegeven URL en vertaald deze naar
     * een ServiceCapabilities Object.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @returns Observable met de Capabilities vertaald naar een CapabilitiesService Object
     */
    getServiceCapabilitiesWMS(baseUrl) {
        return this.getCapabilities(baseUrl, "WMS").pipe(map((capabilities) => {
            if (!capabilities) {
                return undefined;
            }
            return this.extractServiceCapabilitiesWMS(capabilities);
        }));
    }
    /*
     * Creëert een ServiceCapabilities uit de capabilities van een WMS service.
     * @param capabilities - De capabilities van een WMS service.
     * @returns ServiceCapabilities Object met de informatie uit de capabilities.
     */
    extractServiceCapabilitiesWMS(capabilities) {
        const wmsLayers = capabilities?.Capability?.Layer?.Layer;
        const layers = [];
        const service = {
            title: capabilities?.Service?.Title,
            abstract: capabilities?.Service?.Abstract,
            type: "WMS",
            url: capabilities.Request?.GetCapabilities?.DCPType?.HTTP?.Get
                ?.OnlineResource,
            layers: layers
        };
        if (wmsLayers === undefined) {
            console.warn("Geen layers gevonden in WMS capabilities");
        }
        else {
            for (const layer of wmsLayers) {
                const ggcLayerStyles = this.extractStylesFromWMSLayer(layer);
                const datasetLayer = {
                    name: crypto.randomUUID(),
                    title: layer.Name,
                    maxResolution: layer.MaxScaleDenominator,
                    minResolution: layer.MinScaleDenominator,
                    styles: ggcLayerStyles
                };
                layers.push(datasetLayer);
            }
        }
        return service;
    }
    /*
     * Haalt de styles uit een WMS layer.
     * @param layer - De WMS layer.
     * @returns Array met CapabilitiesServiceLayerStyle objecten.
     */
    extractStylesFromWMSLayer(layer) {
        const styles = [];
        if (!layer.Style) {
            console.warn("Geen stijlen gevonden in WMS layer: " + layer.Name);
            return styles;
        }
        for (const style of layer.Style) {
            const wmsStyle = {
                name: style.Name,
                legendURL: style.LegendURL[0].OnlineResource
            };
            styles.push(wmsStyle);
        }
        return styles;
    }
    /*
     * Haalt de WMTS capabilities op voor een gegeven URL en vertaald deze naar
     * een ServiceCapabilitiesObject.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @returns Observable met de Capabilities vertaald naar een ServiceCapabilities Object.
     */
    getServiceCapabilitiesWMTS(baseUrl) {
        return this.getCapabilities(baseUrl, "WMTS").pipe(map((capabilities) => {
            if (!capabilities) {
                return undefined;
            }
            return this.extractServiceCapabilitiesWMTS(capabilities);
        }));
    }
    /*
     * Creëert een ServiceCapabilities uit de capabilities van een WMTS service.
     * @param capabilities - De capabilities van een WMTS service.
     * @returns ServiceCapabilities Object met de informatie uit de capabilities.
     */
    extractServiceCapabilitiesWMTS(capabilities) {
        const wmtsLayers = capabilities?.Contents?.Layer;
        const layers = [];
        const mapSource = {
            title: capabilities?.ServiceIdentification?.Title,
            url: capabilities?.OperationsMetadata?.DCP?.HTTP?.Get[0]?.href,
            type: "WMTS",
            layers: layers
        };
        if (wmtsLayers === undefined) {
            console.warn("Geen layers gevonden in WMTS capabilities");
        }
        else {
            for (const layer of wmtsLayers) {
                const styles = this.extractStylesFromWMTSLayer(layer);
                layers.push({
                    name: layer.Identifier,
                    title: layer.Title,
                    styles: styles
                });
            }
        }
        return mapSource;
    }
    /*
     * Haalt de styles uit een WMTS layer.
     * @param layer - De WMTS layer.
     * @returns Array met CapabilitiesServiceLayerStyle objecten.
     */
    extractStylesFromWMTSLayer(layer) {
        const styles = [];
        if (!layer.Style) {
            console.warn("Geen stijlen gevonden in WMTS layer: " + layer.Name);
            return styles;
        }
        for (const style of layer.Style) {
            const wmtsStyle = {
                name: style.Identifier,
                legendURL: style?.LegendURL?.[0]?.href
            };
            styles.push(wmtsStyle);
        }
        return styles;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmsWmtsCapabilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmsWmtsCapabilitiesService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcWmsWmtsCapabilitiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Service voor het ophalen van capabilities van een OgcApiService.
 * Ondersteunt caching van capabilities per URL.
 */
let CoreOgcApiCapabilitiesService = class CoreOgcApiCapabilitiesService {
    constructor() {
        this.httpClient = inject(HttpClient);
        this.httpHeaders = new HttpHeaders({
            Accept: "application/json"
        });
        this.landingPagesMap = new Map();
        this.stylesMap = new Map();
        this.tilesMap = new Map();
    }
    /*
     * Haalt informatie op van een OGCAPI landingspagina
     * @param baseUrl - De URL naar de landingspagina van een OGCAPI service.
     * @returns Observable met een OGCLandingPageInfo
     */
    getLandingPageInfo(baseUrl) {
        // 1) Als 'ie al bestaat: direct teruggeven (géén nieuwe request)
        const cached = this.landingPagesMap.get(baseUrl);
        if (cached) {
            return cached;
        }
        // 2) Opbouw URL + headers
        const url = baseUrl.endsWith("/")
            ? `${baseUrl}?f=json`
            : `${baseUrl}/?f=json`;
        // 3) Nieuwe Observable maken, mappen en cachen
        const stream$ = this.httpClient
            .get(url, { headers: this.httpHeaders })
            .pipe(map((landing) => {
            const title = landing?.title ?? "(zonder titel)";
            const description = landing?.description ?? "";
            const getLink = (rel) => Array.isArray(landing?.links)
                ? landing.links.find((l) => l?.rel === rel)
                : undefined;
            return {
                title,
                description,
                links: {
                    apiDef: getLink("service-desc"),
                    apiDoc: getLink("service-doc"),
                    conformance: getLink("conformance"),
                    // NOSONAR: this is an URI, not a link
                    collections: getLink("http://www.opengis.net/def/rel/ogc/1.0/data"),
                    // NOSONAR: this is a URI, not a link
                    tilesetsVector: getLink("http://www.opengis.net/def/rel/ogc/1.0/tilesets-vector"),
                    // NOSONAR: this is an URI, not a link
                    styles: getLink("http://www.opengis.net/def/rel/ogc/1.0/styles")
                }
            };
        }));
        // 4) In cache stoppen vóór we hem teruggeven
        this.landingPagesMap.set(baseUrl, stream$);
        return stream$;
    }
    /*
     * Haalt informatie op van OGCAPI tiles
     * @param baseUrl - De URL naar de landingspagina van een OGCAPI service.
     * @returns Observable met een OGCAPITile object
     */
    getTiles(baseUrl) {
        return this.getTileLink(baseUrl).pipe(switchMap((tilesLink) => {
            if (!tilesLink?.href) {
                return throwError(() => new Error("Tiles-link niet gevonden in landing page."));
            }
            const tilesUrl = tilesLink.href;
            const cached = this.tilesMap.get(tilesUrl);
            if (cached) {
                return cached;
            }
            const stream$ = this.httpClient
                .get(tilesUrl, { headers: this.httpHeaders })
                .pipe(map((json) => this.parseTileJson(json)), catchError((err) => {
                // Voeg context toe, maar laat de fout door naar de caller.
                console.error(`Fout bij ophalen tile info van ${tilesUrl}`, err);
                throw err;
            }));
            this.tilesMap.set(baseUrl, stream$);
            return stream$;
        }));
    }
    /*
     * Haalt informatie op van OGCAPI styles
     * @param baseUrl - De URL naar de landingspagina van een OGCAPI service.
     * @returns Observable met een OGCAPIStyle array
     */
    getStyles(baseUrl) {
        return this.getStyleLink(baseUrl).pipe(switchMap((stylesLink) => {
            if (!stylesLink?.href) {
                return throwError(() => new Error("Styles-link niet gevonden in landing page."));
            }
            const stylesUrl = stylesLink.href;
            const cached = this.stylesMap.get(stylesUrl);
            if (cached) {
                return cached;
            }
            const stream$ = this.httpClient
                .get(stylesUrl, { headers: this.httpHeaders })
                .pipe(map((json) => this.parseStylesList(json)), catchError((err) => {
                // Voeg context toe, maar laat de fout door naar de caller.
                console.error(`Fout bij ophalen styles van ${stylesUrl}`, err);
                throw err;
            }));
            this.stylesMap.set(baseUrl, stream$);
            return stream$;
        }));
    }
    getSourcesForStyle(styleUrl) {
        /* Deze methode wordt momenteel niet gebruikt, wellicht is deze in de toekomst relevant
        om mapbox stylesheets aan vectorstylesets te koppelen. Voor nu gaan we er vanuit
        dat alle (RD)mapboxstylesheets kunnen worden toegepast op alle RD Tilesets */
        const headers = new HttpHeaders({
            Accept: "application/vnd.mapbox.style+json, application/json"
        });
        return this.httpClient
            .get(styleUrl, { headers })
            .pipe(map((style) => style.sources));
    }
    getStyleLink(baseUrl) {
        return this.getLandingPageInfo(baseUrl).pipe(map((landingPageInfo) => landingPageInfo.links.styles ?? undefined));
    }
    getTileLink(baseUrl) {
        return this.getLandingPageInfo(baseUrl).pipe(map((landingPageInfo) => landingPageInfo.links.tilesetsVector ?? undefined));
    }
    parseStylesList(json) {
        return Array.isArray(json?.styles)
            ? json.styles.map((s) => ({
                id: String(s?.id ?? ""),
                title: s?.title,
                description: s?.description,
                links: Array.isArray(s?.links) ? s.links : []
            }))
            : [];
    }
    parseTileJson(json) {
        const title = json.title;
        const description = json.description;
        return {
            title,
            description,
            tilesets: json?.tilesets
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiCapabilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiCapabilitiesService, providedIn: "root" }); }
};
CoreOgcApiCapabilitiesService = __decorate([
    Injectable({ providedIn: "root" })
], CoreOgcApiCapabilitiesService);
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoreOgcApiCapabilitiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }, {
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * Service voor het ophalen en vertalen van OGCAPI capabilities naar GGC objecten.
 */
class GgcOgcApiCapabilitiesService {
    constructor() {
        this.coreOgcApiCapabilitiesService = inject(CoreOgcApiCapabilitiesService);
    }
    /*
     * Haalt de serviceinformatie op voor OGCAPI met behulp van een basis url en
     * vertaald deze naar een CapabilitiesService object met layers (Tiles) en
     * styles.
     * NB alleen Tiles en Styles in het Rijksdriehoekstelsel(EPSG28992) worden meegenomen.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @returns Observable met een ServiceCapabilities object
     */
    getServiceCapabilitiesOgcApi(baseUrl) {
        return this.coreOgcApiCapabilitiesService.getLandingPageInfo(baseUrl).pipe(switchMap((landingPageInfo) => {
            // styles + tiles parallel ophalen
            return forkJoin({
                styles: this.getRDStyles(baseUrl).pipe(map((ogcApiStyles) => {
                    const styles = ogcApiStyles.map((s) => {
                        const legendURL = this.getmapBoxLinkFromOGCAPIStyle(s).href;
                        return { name: s.id, title: s.title, legendURL };
                    });
                    return styles;
                })),
                tiles: this.getRDTiles(baseUrl) // gebruikt de gecachte variant hierboven
            }).pipe(map(({ styles, tiles }) => {
                const layers = [];
                for (const tileset of tiles.tilesets ?? []) {
                    layers.push({
                        name: tiles.title,
                        title: tiles.title,
                        url: this.getTileUrlFromTileset(tileset),
                        styles: styles || [],
                        maxResolution: String(this.getResolutionsFromTileset(tileset).maxResolution),
                        minResolution: String(this.getResolutionsFromTileset(tileset).minResolution)
                    });
                }
                const service = {
                    title: landingPageInfo.title,
                    abstract: landingPageInfo.description,
                    url: baseUrl,
                    type: "OGCAPI",
                    layers
                };
                return service;
            }));
        }));
    }
    /*
     * Filtered uit een lijst van OGCAPIStyle objecten de stylen voor
     * het Rijksdriehoekstelsel(EPSG28992)
     * @param baseUrl - De URL van de capabilities endpoint.
     * @returns Observable met een OGCAPIStyle objecten
     */
    getRDStyles(baseUrl) {
        return this.coreOgcApiCapabilitiesService
            .getStyles(baseUrl)
            .pipe(map((styles) => styles.filter((s) => s.id.toLowerCase().includes("netherlandsrdnewquad"))));
    }
    /*
     * Filtered uit een lijst van OGCAPITile objecten de tilesets in
     * het Rijksdriehoekstelsel(EPSG28992)
     * @param baseUrl - De URL van de capabilities endpoint.
     * @returns Observable met een OGCAPITile objecten
     */
    getRDTiles(baseUrl) {
        return this.coreOgcApiCapabilitiesService.getTiles(baseUrl).pipe(map((tiles) => {
            // Verdedigende checks
            const filteredTilesets = (tiles?.tilesets ?? []).filter((t) => t.crs === "https://www.opengis.net/def/crs/EPSG/0/28992");
            // Retourneer een nieuw OGCAPITiles object met gefilterde tilesets
            return {
                ...tiles, // behoud alle andere properties
                tilesets: filteredTilesets
            };
        }));
    }
    /*
     * Berekend een min- en maxresolutie uit de limits van een OGCAPITileset
     * @param tileset - een OGCAPITileset Object.
     * @returns een object met min- en maxresolution
     */
    getResolutionsFromTileset(tileset) {
        let minlevel = 0;
        let maxlevel = 16;
        for (const limits of tileset.tileMatrixSetLimits ?? []) {
            const level = Number(limits.tileMatrix);
            // Clamp naar het toegestane bereik 0..16
            const clamped = Math.max(0, Math.min(16, level));
            // Werk min/max bij
            if (clamped > minlevel)
                minlevel = clamped;
            if (clamped < maxlevel)
                maxlevel = clamped;
        }
        return {
            // Tel voor de maxresolutie er 1 level bij op, zodat de laag zichtbaar
            // wordt van...tot (bij bijv alleen tilelevel 12 van 12 tot 13)
            minResolution: zoomlevelToResolution(maxlevel),
            maxResolution: zoomlevelToResolution(minlevel - 1)
        };
    }
    /*
     * Extracts een tileurl uit een OGCAPITileset object
     * @param tileset - een OGCAPITileset Object.
     * @returns url
     */
    getTileUrlFromTileset(tileset) {
        const tilesetItemLink = tileset.links.find((l) => l?.rel === "item")?.href;
        if (tilesetItemLink) {
            return tilesetItemLink.replace("{tileMatrix}/{tileRow}/{tileCol}", "{z}/{x}/{y}");
        }
        return tileset.tileMatrixSetURI + "/{z}/{x}/{y}?f=mvt";
    }
    /*
     * Extracts een mapbox styleurl uit een OGCAPIStyle object
     * @param styl - een OGCAPIStyle Object.
     * @returns een OGCAPILink object
     */
    getmapBoxLinkFromOGCAPIStyle(style) {
        return style.links?.find((l) => l.rel === "stylesheet" &&
            (l.type?.includes("application/vnd.mapbox.style+json") ?? true));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcOgcApiCapabilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcOgcApiCapabilitiesService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcOgcApiCapabilitiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Service voor het ophalen en verwerken van WMS/WMTS en OGCAPI capabilities.
 */
class GgcCapabilitiesService {
    constructor() {
        this.wmsWmtsCapabilitiesService = inject(GgcWmsWmtsCapabilitiesService);
        this.ogcApiCapabilitiesService = inject(GgcOgcApiCapabilitiesService);
    }
    /**
     * Geeft een CapabilitiesService Object terug voor verschillende service types
     * @param baseUrl - De URL van de capabilities endpoint van de WMS, WMTS
     * of landingspagina van een OGCAPI.
     * @param serviceType - het type van de service dit kan WMS, WMTS of OGCAPI zijn
     * @returns Observable van een CapabilitiesService Object
     */
    getServiceFromCapabilities(baseUrl, serviceType) {
        switch (serviceType) {
            case "WMS":
                return this.wmsWmtsCapabilitiesService.getServiceCapabilitiesWMS(baseUrl);
            case "WMTS":
                return this.wmsWmtsCapabilitiesService.getServiceCapabilitiesWMTS(baseUrl);
            case "OGCAPI":
                return this.ogcApiCapabilitiesService.getServiceCapabilitiesOgcApi(baseUrl);
        }
    }
    /**
     * Geeft een array van CapabilitiesServiceLayerStyle terug voor een bepaalde
     * laag binnen een service.
     * @param baseUrl - De URL van de capabilities endpoint van de WMS, WMTS
     * of landingspagina van een OGCAPI.
     * @param serviceType - het type van de service dit kan WMS, WMTS of OGCAPI zijn
     * @param layerName - de naam van een laag of tileset
     * @returns Observable van een lijst van CapabilitiesServiceLayerStyle Objecten
     */
    getServiceLayerStyles(baseUrl, serviceType, layerName) {
        return this.getServiceFromCapabilities(baseUrl, serviceType).pipe(map((s) => s?.layers.find((l) => l.name === layerName)?.styles ?? []));
    }
    /**
     * Haalt de capabilities op voor een gegeven WMS of WMTS service.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @param service - Het type service: `"WMTS"` of `"WMS"`.
     * @returns Observable met de capabilities data (ol capabilities).
     */
    getCapabilities(baseUrl, service) {
        return this.wmsWmtsCapabilitiesService.getCapabilities(baseUrl, service);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCapabilitiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCapabilitiesService, providedIn: "root" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcCapabilitiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root"
                }]
        }] });

/**
 * Component die een loader toont op basis van laadstatus
 * van een specifieke kaart.
 *
 * De loader luistert naar loading-events van {@link CoreMapEventsService}
 * en wordt automatisch bijgewerkt zodra de kaart start of stopt
 * met laden.
 *
 * @example
 * <ggc-loader [mapIndex]="'default'"></ggc-loader>
 */
class GgcLoaderComponent {
    constructor() {
        /**
         * Geeft aan of de kaart momenteel aan het laden is.
         * Wordt gebruikt door de template om de loader te tonen of verbergen.
         */
        this.isLoading = false;
        this.mapEventsService = inject(CoreMapEventsService);
    }
    /**
     * Index van de kaart waarvoor laad-events worden gevolgd.
     *
     * Bij wijziging wordt de bestaande subscription gestopt
     * en een nieuwe subscription opgezet voor de opgegeven kaart.
     */
    set mapIndex(value) {
        this._mapIndex = value;
        this.subscribe();
    }
    /**
     * Lifecycle hook die wordt aangeroepen wanneer
     * het component wordt vernietigd.
     *
     * Zorgt ervoor dat alle subscriptions correct worden opgeruimd.
     */
    ngOnDestroy() {
        this.unsubscribe();
    }
    /**
     * Abonneert zich op laad-events van de opgegeven kaart
     * en actualiseert de loader-status.
     */
    subscribe() {
        this.unsubscribe();
        this.loadEvents$ = this.mapEventsService
            .getLoadingObservableForMap(this._mapIndex)
            .subscribe((isLoading) => (this.isLoading = isLoading));
    }
    /**
     * Beëindigt de actieve subscription op laad-events,
     * indien aanwezig.
     */
    unsubscribe() {
        if (this.loadEvents$) {
            this.loadEvents$.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: GgcLoaderComponent, isStandalone: true, selector: "ggc-loader", inputs: { mapIndex: "mapIndex" }, ngImport: i0, template: "@if (isLoading) {\n  <span class=\"ggc-loader fa-spin fas fa-spinner\"></span>\n}\n", styles: [".ggc-loader{display:inline-flex}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-loader", template: "@if (isLoading) {\n  <span class=\"ggc-loader fa-spin fas fa-spinner\"></span>\n}\n", styles: [".ggc-loader{display:inline-flex}\n"] }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }] } });

/**
 * Containercomponent voor het tonen van detailinformatie
 * gerelateerd aan de kaart.
 *
 * Deze component fungeert als structurele wrapper en bevat
 * zelf geen logica. De inhoud wordt bepaald door de bijbehorende
 * template en eventueel ingesloten child‑componenten.
 *
 * @example
 * <ggc-map-details-container>
 *   <ggc-feature-info></ggc-feature-info>
 *   <ggc-selection-details></ggc-selection-details>
 * </ggc-map-details-container>
 */
class GgcMapDetailsContainerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapDetailsContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcMapDetailsContainerComponent, isStandalone: true, selector: "ggc-map-details-container", ngImport: i0, template: "<div #mapDetailsContainer class=\"ggc-map-details-container\">\n  <ng-content></ng-content>\n</div>\n", styles: [".ggc-map-details-container{display:inline-block}::ng-deep .ggc-mouse-position,::ng-deep .ggc-scale-denominator,::ng-deep .ggc-scale-line,::ng-deep .ggc-zoom-level{display:inline-block;float:left;position:relative;margin-right:10px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMapDetailsContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-map-details-container", template: "<div #mapDetailsContainer class=\"ggc-map-details-container\">\n  <ng-content></ng-content>\n</div>\n", styles: [".ggc-map-details-container{display:inline-block}::ng-deep .ggc-mouse-position,::ng-deep .ggc-scale-denominator,::ng-deep .ggc-scale-line,::ng-deep .ggc-zoom-level{display:inline-block;float:left;position:relative;margin-right:10px}\n"] }]
        }] });

/**
 * Pipe voor het formatteren van coördinaten naar een leesbare string.
 *
 * De pipe:
 * - formatteert x- en y‑waarden met een vast aantal decimalen
 * - gebruikt de Nederlandse locale (`nl-NL`)
 * - ondersteunt een configureerbaar formaat met placeholders `{x}` en `{y}`
 *
 * Voorbeeld output:
 * `RD: x = 123456.78 m; y = 456789.12 m`
 */
class CoordinateFormatPipe {
    /**
     * Transformeert een coördinaat naar een geformatteerde string.
     *
     * @param coord Coördinaat in de vorm `[x, y]`
     * @param decimals Aantal decimalen voor de coördinaatwaarden (default: 2)
     * @param format Formaatstring met `{x}` en `{y}` placeholders
     *
     * @returns De geformatteerde coördinaatstring of een lege string
     * wanneer de coördinaat niet is opgegeven.
     *
     * @example
     * ```html
     * {{ coord | coordinateFormat:2:'RD: x = {x} m; y = {y} m' }}
     * ```
     */
    transform(coord, decimals = 2, format = "RD: x = {x} m; y = {y} m") {
        if (!coord) {
            return "";
        }
        const numberFmt = new Intl.NumberFormat("nl-NL", {
            maximumFractionDigits: decimals,
            minimumFractionDigits: decimals,
            useGrouping: false
        });
        const [x, y] = [numberFmt.format(coord[0]), numberFmt.format(coord[1])];
        return format.replace("{x}", x).replace("{y}", y);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoordinateFormatPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.1.0", ngImport: i0, type: CoordinateFormatPipe, isStandalone: true, name: "coordinateFormat" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: CoordinateFormatPipe, decorators: [{
            type: Pipe,
            args: [{ name: "coordinateFormat" }]
        }] });

/**
 * Component dat de actuele muispositie op een OpenLayers‑kaart weergeeft.
 *
 * Ondersteunt:
 * - verschillende coördinatenstelsels
 * - string- of callback‑gebaseerde formattering
 * - optionele weergave binnen een MapDetailsContainer
 */
class GgcMousePositionComponent {
    constructor() {
        /**
         * Optionele injectie van de MapDetailsContainer.
         * Indien aanwezig wordt de mouse position daarin gerenderd.
         */
        this.mapDetailsContainer = inject(GgcMapDetailsContainerComponent, {
            optional: true
        });
        /** Aantal decimalen voor coördinaten */
        this.decimalDigits = 2;
        /** Index van de kaart waarop de mouse position wordt toegepast */
        this.mapIndex = DEFAULT_MAPINDEX;
        /** Placeholder tekst wanneer geen coördinaat beschikbaar is */
        this.placeholder = " ";
        /** Doelprojectie waarin de coördinaten worden getoond */
        this.projection = epsg28992;
        this.coreMapService = inject(CoreMapService);
        this.crsConfigService = inject(GgcCrsConfigService);
        this._format = "RD: x = {x} m; y = {y} m";
        this.mode = "string";
    }
    /** Geeft het huidige ingestelde coördinaatformaat terug */
    get format() {
        return this._format;
    }
    set format(value) {
        this.mode = typeof value === "string" ? "string" : "callback";
        this._format = value;
    }
    /** Initialiseert de MousePosition control en voegt deze toe aan de kaart */
    ngOnInit() {
        this.mousePositionControl = new MousePosition(this.createMousePositionOptions());
        this.setCoordinateFormatOnMousePositionControl();
        this.setMousePositionControlOnMap();
    }
    /** Verwijdert de MousePosition control bij component destruction */
    ngOnDestroy() {
        if (this.map !== undefined) {
            this.map.removeControl(this.mousePositionControl);
        }
    }
    /**
     * Maakt de configuratie-opties aan voor de MousePosition control.
     */
    createMousePositionOptions() {
        const options = {
            projection: this.crsConfigService.getRdNewCrsConfig().projectionCode,
            placeholder: this.placeholder
        };
        // when parent component MapDetailsContainerComponent is present, target for mouseposition is set to nativeElement
        // to show the mouse position within the parent component instead of the default location on the map
        if (this.mapDetailsContainer) {
            options.target = this.ggcMousePosition.nativeElement;
        }
        return options;
    }
    /**
     * Koppelt de coördinaatformatter aan de MousePosition control.
     */
    setCoordinateFormatOnMousePositionControl() {
        // 'bind' wordt hier gebruikt om de context van het component mee te geven
        // zodat de methode wordt uitgevoerd binnen de context van deze class in plaats van binnen OpenLayers.
        this.mousePositionControl.setCoordinateFormat(this.createCoordinateFormat.bind(this));
    }
    /**
     * Converteert en formatteert een coördinaat
     * naar een string geschikt voor weergave.
     */
    createCoordinateFormat(coord) {
        if (!coord) {
            return "";
        }
        if (this.projection !== epsg28992) {
            if (!get(this.projection)) {
                throw new Error(`Unknown projection '${this.projection}'`);
            }
            else {
                coord = transform(coord, epsg28992, this.projection);
            }
        }
        if (this.mode === "string") {
            return new CoordinateFormatPipe().transform(coord, this.decimalDigits, this._format);
        }
        else {
            return this._format(coord);
        }
    }
    /**
     * Voegt de MousePosition control toe aan de actuele kaart.
     */
    setMousePositionControlOnMap() {
        this.map = this.coreMapService.getMap(this.mapIndex);
        this.map.addControl(this.mousePositionControl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMousePositionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcMousePositionComponent, isStandalone: true, selector: "ggc-mouse-position", inputs: { decimalDigits: "decimalDigits", mapIndex: "mapIndex", placeholder: "placeholder", projection: "projection", format: "format" }, viewQueries: [{ propertyName: "ggcMousePosition", first: true, predicate: ["ggcMousePosition"], descendants: true, static: true }], ngImport: i0, template: "<div #ggcMousePosition class=\"ggc-mouse-position\"></div>\n", styles: ["::ng-deep .ggc-mouse-position .ol-mouse-position{position:unset;top:unset;right:unset}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcMousePositionComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-mouse-position", standalone: true, template: "<div #ggcMousePosition class=\"ggc-mouse-position\"></div>\n", styles: ["::ng-deep .ggc-mouse-position .ol-mouse-position{position:unset;top:unset;right:unset}\n"] }]
        }], propDecorators: { decimalDigits: [{
                type: Input
            }], mapIndex: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], projection: [{
                type: Input
            }], ggcMousePosition: [{
                type: ViewChild,
                args: ["ggcMousePosition", { static: true }]
            }], format: [{
                type: Input
            }] } });

/**
 * Component dat het actuele schaalgetal (scale denominator)
 * van een OpenLayers‑kaart berekent en beschikbaar stelt.
 *
 * Het schaalgetal wordt opnieuw berekend bij iedere `zoomend`‑event
 * van de gekoppelde kaart.
 *
 * Voorbeeld: 1 : 25.000
 */
class GgcScaleDenominatorComponent {
    constructor() {
        /**
         * Index van de kaart waarvoor het schaalgetal
         * berekend moet worden.
         */
        this.mapIndex = DEFAULT_MAPINDEX;
        this.coreMapService = inject(CoreMapService);
        this.mapEventsService = inject(CoreMapEventsService);
        this.INCHES_PER_METER = 39.37;
        this.POINTS_PER_INCH = 90.71446714322;
    }
    /**
     * Initialiseert het component:
     * - haalt de kaart op
     * - abonneert zich op zoom-events
     * - triggert herberekening van het schaalgetal
     */
    ngOnInit() {
        this.map = this.coreMapService.getMap(this.mapIndex);
        const zoomendObservable = this.mapEventsService.getZoomendObservableForMap(this.mapIndex);
        this.zoomendSubscription = zoomendObservable.subscribe(() => {
            this.calculateScaleDenominator();
        });
    }
    /**
     * Berekent het schaalgetal op basis van de huidige kaartresolutie.
     *
     * Formule:
     * schaal = resolutie (m/px) × inches/m × pixels/inch
     *
     * De PPI‑waarde is afgeleid van:
     * Nederlandse richtlijn tiling (bijlage B, Geonovum).
     */
    calculateScaleDenominator() {
        // aantal ppi berekend op basis van aanname van 0.28 mm per pixel uit de Nederlandse richtlijn tiling, bijlage B:
        // https://www.geonovum.nl/uploads/standards/downloads/nederlandse_richtlijn_tiling_-_versie_1.1.pdf
        // ppi = aantal mm per inch (= 25.4mm) / mm per pixel (0.28mm) = 90.7142857142857
        // Deze berekende ppi blijkt net niet nauwkeurig genoeg, bij de hoge resoluties wijkt het schaalgetal een klein beetje af
        // van de verwachte waarde. Daarom ppi berekend aan de hand van de zoomniveaus uit het document, bijv. zoomniveau 3:
        // 1536000 = 430.080 *  39.37 * ? >>> ? = 90.71446714322
        const resolution = this.map.getView().getResolution();
        // schaalgetal = resolutie (m/pixel) * inches/m * pixels/inch
        if (resolution) {
            this.currentScaleDenominator = Math.round(resolution * this.INCHES_PER_METER * this.POINTS_PER_INCH);
        }
        else {
            this.currentScaleDenominator = undefined;
        }
    }
    /**
     * Ruimt resources op door de subscription
     * op het zoom-event te beëindigen.
     */
    ngOnDestroy() {
        if (this.zoomendSubscription) {
            this.zoomendSubscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcScaleDenominatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: GgcScaleDenominatorComponent, isStandalone: true, selector: "ggc-scale-denominator", inputs: { mapIndex: "mapIndex" }, ngImport: i0, template: "@if (currentScaleDenominator) {\n  <div class=\"ggc-scale-denominator\">1:{{ currentScaleDenominator }}</div>\n}\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcScaleDenominatorComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-scale-denominator", template: "@if (currentScaleDenominator) {\n  <div class=\"ggc-scale-denominator\">1:{{ currentScaleDenominator }}</div>\n}\n" }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }] } });

/**
 * Component dat een OpenLayers ScaleLine (schaalbalk) toevoegt aan een kaart.
 *
 * De schaal kan:
 * - standaard op de kaart worden getoond
 * - of binnen een MapDetailsContainerComponent, indien deze als parent aanwezig is.
 */
/**
 * Optionele injectie van de MapDetailsContainer.
 * Indien aanwezig wordt de ScaleLine daarin gerenderd
 * in plaats van in de standaard kaartoverlay.
 */
class GgcScaleLineComponent {
    constructor() {
        this.mapDetailsContainer = inject(GgcMapDetailsContainerComponent, {
            optional: true
        });
        /**
         * Index van de kaart waaraan de schaalbalk
         * moet worden toegevoegd.
         */
        this.mapIndex = DEFAULT_MAPINDEX;
        /**
         * Eenheden waarin de schaal wordt weergegeven.
         * Standaard: metrisch.
         */
        this.units = "metric";
        this.coreMapService = inject(CoreMapService);
    }
    /**
     * Initialiseert de ScaleLine:
     * - maakt de control aan
     * - haalt de kaart op
     * - voegt de control toe aan de kaart
     */
    ngOnInit() {
        this.scaleControl = new ScaleLine(this.createScaleLineOptions());
        this.map = this.coreMapService.getMap(this.mapIndex);
        this.map.addControl(this.scaleControl);
    }
    /**
     * Maakt de configuratie‑opties aan voor de ScaleLine.
     *
     * Wanneer een MapDetailsContainer aanwezig is,
     * wordt het target gezet op het bijbehorende
     * native DOM‑element.
     */
    createScaleLineOptions() {
        const options = {
            units: this.units
        };
        // Wanneer de MapDetailsContainerComponent aanwezig is,
        // wordt de schaalbalk daarin gerenderd in plaats van
        // op de standaard kaartpositie.
        if (this.mapDetailsContainer) {
            options.target = this.ggcScaleLine.nativeElement;
        }
        return options;
    }
    /**
     * Verwijdert de ScaleLine control
     * van de kaart bij het vernietigen van het component.
     */
    ngOnDestroy() {
        if (this.map !== undefined) {
            this.map.removeControl(this.scaleControl);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcScaleLineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.0", type: GgcScaleLineComponent, isStandalone: true, selector: "ggc-scale-line", inputs: { mapIndex: "mapIndex", units: "units" }, viewQueries: [{ propertyName: "ggcScaleLine", first: true, predicate: ["ggcScaleLine"], descendants: true, static: true }], ngImport: i0, template: "<div #ggcScaleLine class=\"ggc-scale-line\"></div>\n", styles: ["::ng-deep .ggc-scale-line .ol-scale-line{bottom:unset;position:unset}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcScaleLineComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-scale-line", template: "<div #ggcScaleLine class=\"ggc-scale-line\"></div>\n", styles: ["::ng-deep .ggc-scale-line .ol-scale-line{bottom:unset;position:unset}\n"] }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }], units: [{
                type: Input
            }], ggcScaleLine: [{
                type: ViewChild,
                args: ["ggcScaleLine", { static: true }]
            }] } });

/**
 * Component dat het actuele zoomniveau van een OpenLayers‑kaart weergeeft.
 *
 * Het zoomniveau wordt bijgewerkt bij ieder`zoomend`‑event van
 * de gekoppelde kaart en afgerond op twee decimalen.
 */
class GgcZoomLevelComponent {
    constructor() {
        /**
         * Index van de kaart waarvan het zoomniveau
         * wordt weergegeven.
         */
        this.mapIndex = DEFAULT_MAPINDEX;
        this.coreMapService = inject(CoreMapService);
        this.mapEventsService = inject(CoreMapEventsService);
    }
    /**
     * Initialiseert het component:
     * - haalt de kaart op aan de hand van de mapIndex
     * - abonneert zich op zoom-events
     * - werkt het zoomniveau bij bij iedere zoomwijziging
     */
    ngOnInit() {
        this.map = this.coreMapService.getMap(this.mapIndex);
        const zoomendObservable = this.mapEventsService.getZoomendObservableForMap(this.mapIndex);
        this.zoomendSubscription = zoomendObservable.subscribe(() => {
            this.getZoomLevel();
        });
    }
    /**
     * Leest het huidige zoomniveau uit de kaart
     * en rondt dit af op twee decimalen.
     */
    getZoomLevel() {
        const zoomLevel = this.map.getView().getZoom();
        if (zoomLevel) {
            this.zoomLevel = Math.round(zoomLevel * 100) / 100;
        }
        else {
            this.zoomLevel = undefined;
        }
    }
    /**
     * Ruimt resources op door de subscription
     * op het zoom-event te beëindigen.
     */
    ngOnDestroy() {
        if (this.zoomendSubscription) {
            this.zoomendSubscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcZoomLevelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.0", type: GgcZoomLevelComponent, isStandalone: true, selector: "ggc-zoom-level", inputs: { mapIndex: "mapIndex" }, ngImport: i0, template: "@if (zoomLevel !== undefined) {\n  <div class=\"ggc-zoom-level\">\n    {{ zoomLevel }}\n  </div>\n}\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.0", ngImport: i0, type: GgcZoomLevelComponent, decorators: [{
            type: Component,
            args: [{ selector: "ggc-zoom-level", imports: [], template: "@if (zoomLevel !== undefined) {\n  <div class=\"ggc-zoom-level\">\n    {{ zoomLevel }}\n  </div>\n}\n" }]
        }], propDecorators: { mapIndex: [{
                type: Input
            }] } });

/*
 * Public API Surface of ggc-map
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ATTRIBUTION_OPTIONS, CoordinateFormatPipe, DrawInteractionEvent, DrawInteractionEventTypes, FeatureCollectionForCoordinate, FeatureCollectionForLayer, FormatType, GgcCapabilitiesService, GgcCrsConfigService, GgcDrawService, GgcGeojsonLayerComponent, GgcImageLayerComponent, GgcLayerBrtAchtergrondkaartComponent, GgcLayerService, GgcLoaderComponent, GgcMapComponent, GgcMapDetailsContainerComponent, GgcMapEventsService, GgcMapService, GgcMousePositionComponent, GgcScaleDenominatorComponent, GgcScaleLineComponent, GgcSelectionService, GgcSnapService, GgcVectorTileLayerComponent, GgcWmsLayerComponent, GgcWmtsLayerComponent, GgcZoomLevelComponent, MapComponentEvent, MapComponentEventTypes, MapViewState, ModifyInteractionEvent, ModifyInteractionEventTypes, ROTATE_OPTIONS, SelectionModeTypes, ZOOM_OPTIONS, declusterFeatures, drawTypeToGeometryType, epsg28992, extent, featureCollectionForLayerHasCluster, fromGeoJSONFeature, fromGeoJSONFeatures, matrixIds, matrixSizes, resolutionToZoomlevel, resolutions, scaleToResolution, toGeoJSONFeature, zoomlevelToResolution };
//# sourceMappingURL=kadaster-ggc-map.mjs.map
