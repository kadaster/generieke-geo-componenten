import { Coordinate, CoordinateFormat } from 'ol/coordinate';
import Feature from 'ol/Feature';
import { Geometry } from 'ol/geom';
import BaseLayer, { Options as Options$c } from 'ol/layer/Base';
import VectorLayer from 'ol/layer/Vector';
import OlMap from 'ol/Map';
import VectorSource, { Options as Options$2 } from 'ol/source/Vector';
import Style, { StyleLike, StyleFunction } from 'ol/style/Style';
import { Extent } from 'ol/extent';
import { FitOptions } from 'ol/View';
import * as rxjs from 'rxjs';
import { Observable, Subscription } from 'rxjs';
import { LayerChangedEvent, MapComponentEvent as MapComponentEvent$1, MapComponentDrawTypes, FeatureCollectionForLayer as FeatureCollectionForLayer$1, LegendType, Webservice2DType, MapViewState as MapViewState$1, LayerChangedEventTrigger, LegendAddedEvent, LegendRemovedEvent, LayerLegend } from '@kadaster/ggc-models';
import * as i0 from '@angular/core';
import { InjectionToken, AfterViewInit, OnDestroy, EventEmitter, OnInit, OnChanges, SimpleChanges, ElementRef, PipeTransform } from '@angular/core';
import MapEvent from 'ol/MapEvent';
import { Condition } from 'ol/events/condition';
import { DrawEvent } from 'ol/interaction/Draw';
import { Feature as Feature$1, MapBrowserEvent as MapBrowserEvent$1 } from 'ol';
import { ModifyEvent } from 'ol/interaction/Modify';
import { SnapEvent } from 'ol/events/SnapEvent';
import { Segmenters } from 'ol/interaction/Snap';
import { Options } from 'ol/control/Zoom';
import { Units } from 'ol/proj/Units';
import { Feature as Feature$2, FeatureCollection } from 'geojson';
import Geometry$1, { Type } from 'ol/geom/Geometry';
import { ObjectEvent } from 'ol/Object';
import RenderEvent from 'ol/render/Event';
import { Options as Options$1 } from 'ol/layer/BaseVector';
import { Options as Options$3 } from 'ol/source/Cluster';
import { Options as Options$4 } from 'ol/layer/BaseImage';
import ImageSource, { Options as Options$5 } from 'ol/source/ImageStatic';
import VectorTileLayer, { Options as Options$6 } from 'ol/layer/VectorTile';
import { Options as Options$7 } from 'ol/source/VectorTile';
import { Options as Options$8 } from 'ol/layer/BaseTile';
import TileSource, { Options as Options$a } from 'ol/source/TileWMS';
import ImageSource$1, { Options as Options$9 } from 'ol/source/ImageWMS';
import Source, { Options as Options$b } from 'ol/source/WMTS';
import ImageLayer from 'ol/layer/Image';
import TileLayer from 'ol/layer/Tile';
import MapBrowserEvent from 'ol/MapBrowserEvent';
import ImageSource$2 from 'ol/source/Image';
import TileSource$1 from 'ol/source/Tile';
import { Layer } from 'ol/layer';
import { Options as Options$d } from 'ol/control/MousePosition';
import { Units as Units$1, Options as Options$e } from 'ol/control/ScaleLine';

/**
 * Opties voor het zoomen of fitten(passen) van de kaart.
 *
 * Dit object wordt gebruikt bij zoom- en fit-operaties om
 * aanvullende kaart- en view-instellingen mee te geven.
 */
interface ZoomOptions {
    /**
     * Optionele index van de kaart waarop de zoomactie moet worden uitgevoerd.
     * Indien niet opgegeven wordt {@link DEFAULT_MAPINDEX} gebruikt.
     */
    mapIndex?: string;
    /**
     * Opties voor het fitten van de view, zoals padding, maxZoom of duration.
     *
     * @see FitOptions
     */
    fitOptions?: FitOptions;
}

/**
 * Ondersteunde formaten voor het aanleveren van geometrieën.
 *
 * Wordt gebruikt om te bepalen hoe string-geometrieën
 * geïnterpreteerd en geparsed moeten worden.
 */
declare enum FormatType {
    /** Well-Known Text (WKT) formaat */
    WKT = 0,
    /** GeoJSON formaat */
    GEOJSON = 1
}

/**
 * Service die kaartfunctionaliteit aanbiedt voor:
 *
 * - Opvragen van kaarten en lagen
 * - Zoomen naar coördinaten, geometrieën en extensies
 * - Highlight- en selection-lagen beheren
 * - Interactie met (PDOK) zoekresultaten
 *
 * Deze service abstraheert OpenLayers-details en zorgt voor consistente
 * {@link MapComponentEvent}-afhandeling.
 */
declare class GgcMapService {
    private readonly coreMapService;
    /**
     * Geeft een observable die notificaties uitstuurt wanneer lagen wijzigen.
     *
     * @returns Observable met {@link LayerChangedEvent}
     */
    getLayerChangedObservable(): Observable<LayerChangedEvent>;
    /**
     * Haalt een OpenLayers map op, op basis van mapIndex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns OpenLayers {@link OlMap}
     */
    getMap(mapIndex?: string): OlMap;
    /**
     * Haalt een kaartlaag op, op basis van layerID en mapIndex.
     *
     * @param layerId Unieke laag-id
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns De kaartlaag of `undefined` indien niet gevonden
     */
    getLayer(layerId: string, mapIndex?: string): BaseLayer | undefined;
    /**
     * Haalt een extra vectorlaag op (bijvoorbeeld highlight- of selectionlaag),
     * op basis van een layerName en mapIndex.
     *
     * @param layer Naam van de extra laag
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns VectorLayer of `undefined`
     */
    getExtraLayer(layer: string, mapIndex?: string): VectorLayer<VectorSource<Feature<Geometry>>> | undefined;
    /**
     * Bepaalt de hoogste z-index van zichtbare lagen binnen een kaart.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @returns Hoogste z-index
     */
    getMaxZIndex(mapIndex?: string): number;
    /**
     * Zoomt de kaart naar een specifieke coördinaat.
     * Wacht indien nodig tot de kaart volledig is gerenderd.
     *
     * @param coord Doelcoördinaat
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param maxZoom Optioneel maximum zoomniveau
     * @returns Promise met {@link MapComponentEvent}
     */
    zoomToCoordinate(coord: Coordinate, mapIndex?: string, maxZoom?: number): Promise<MapComponentEvent$1>;
    /**
     * Zoomt naar een geometrie met uitgebreide zoomopties.
     *
     * @param geometry Geometrie als WKT, GeoJSON of OpenLayers Geometry
     * @param zoomOptions Opties voor mapIndex en fit
     * @param formatType Formaat van string-geometrie
     * @returns {@link MapComponentEvent}
     */
    zoomToGeometryWithZoomOptions(geometry: string | Geometry, zoomOptions: ZoomOptions, formatType?: FormatType): MapComponentEvent$1;
    /**
     * Zoomt naar een gegeven bounding box (extent).
     *
     * @param bbox Extent in kaartprojectie
     * @param zoomOptions Optioneel Zoom- en fitopties
     * @returns {@link MapComponentEvent}
     */
    zoomToExtent(bbox: Extent, zoomOptions?: ZoomOptions): MapComponentEvent$1;
    /**
     * Markeert een geometrie op de highlightlaag.
     * Bestaande markeringen worden eerst verwijderd.
     *
     * @param geometry Geometrie als string of OpenLayers Geometry
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param formatType Formaat van de string-geometrie (enum FormatType)
     * @returns {@link MapComponentEvent}
     */
    markFeature(geometry: string | Geometry, mapIndex?: string, formatType?: FormatType): MapComponentEvent$1;
    /**
     * Voegt één of meerdere features toe aan de highlightlaag.
     * De features worden zichtbaar gemaakt met de huidige highlightstijl.
     *
     * @param features Array van OpenLayers features met geometrie
     * @param mapIndex Index van de kaart waarop de features worden
     * toegevoegd (default: DEFAULT_MAPINDEX)
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    addFeaturesToHighlightLayer(features: Feature<Geometry>[], mapIndex?: string): MapComponentEvent$1;
    /**
     * Verwijdert alle features uit de highlightlaag.
     *
     * @param mapIndex Index van de kaart waarvoor de highlightlaag wordt
     * geleegd (default: DEFAULT_MAPINDEX)
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    clearHighlightLayer(mapIndex?: string): MapComponentEvent$1;
    /**
     * Wijzigt de stijl die wordt gebruikt voor het renderen van features
     * in de highlightlaag.
     *
     * @param styleLike OpenLayers StyleLike
     * @param mapIndex Index van de kaart waarop de stijl wordt
     * aangepast (default: DEFAULT_MAPINDEX)
     */
    changeHighlightLayerStyle(styleLike: StyleLike, mapIndex?: string): void;
    /**
     * Voegt één of meerdere features toe aan de selectionlaag.
     * Deze laag wordt doorgaans gebruikt voor geselecteerde objecten.
     *
     * @param features Array van OpenLayers features met geometrie
     * @param mapIndex Index van de kaart waarop de features worden
     * toegevoegd (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    addFeaturesToSelectionLayer(features: Feature<Geometry>[], mapIndex?: string, selectIndex?: string): MapComponentEvent$1;
    /**
     * Controleert of een feature aanwezig is in de selectionlaag.
     *
     * Een feature wordt als aanwezig beschouwd wanneer:
     * - dezelfde feature‑referentie voorkomt in de selectionlaag, of
     * - een feature met hetzelfde id voorkomt in de selectionlaag
     *
     * @param feature OpenLayers feature die gecontroleerd wordt
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns `true` indien de feature in de selectionlaag zit, anders `false`
     */
    isFeatureInSelectionLayer(feature: Feature<Geometry>, mapIndex?: string, selectIndex?: string): boolean;
    /**
     * Verwijdert alle features uit de selectionlaag.
     *
     * @param mapIndex Index van de kaart waarvoor de selectionlaag wordt
     * geleegd (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     * @returns {@link MapComponentEvent} dat aangeeft of de actie succesvol was
     */
    clearSelectionLayer(mapIndex?: string, selectIndex?: string): MapComponentEvent$1;
    /**
     * Past de stijl aan waarmee features in de selectionlaag
     * worden weergegeven.
     *
     * @param styleLike OpenLayers stijl of stijl-functie
     * @param mapIndex Index van de kaart waarop de stijl wordt
     * aangepast (default: DEFAULT_MAPINDEX)
     * @param selectIndex de optionele selectIndex als deze is meegegeven bij het maken van de selectie
     */
    changeSelectionLayerStyle(styleLike: StyleLike | null, mapIndex?: string, selectIndex?: string): void;
    /**
     * Controleert of de kaart zich op het maximale zoomniveau bevindt.
     *
     * @param mapIndex Index van de kaart waarvoor het zoomniveau wordt
     * gecontroleerd (default: DEFAULT_MAPINDEX)
     * @returns `true` indien het huidige zoomniveau gelijk is aan het maximale
     * zoomniveau, anders `false`
     */
    isMaxZoomlevel(mapIndex?: string): boolean;
    /**
     * Geeft de geometrie of – indien niet aanwezig – het centroïde
     * uit een PDOK zoekresultaat.
     *
     * @param pdokDoc PDOK zoekresultaatdocument
     * @returns WKT-representatie van geometrie of centroïde, of `undefined`
     */
    private getGeometrieOrCentroide;
    /**
     * Haalt het eerste {@link SearchResultDoc} object uit een event.
     *
     * @param evt Event met PDOK zoekresultaten
     * @returns Het eerste zoekresultaatdocument of `undefined`
     */
    private getSearchResultDocFromEvent;
    /**
     * Zet een stringrepresentatie van een geometrie om naar een
     * OpenLayers Geometry.
     */
    private transformStringToGeometry;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcMapService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcMapService>;
}

/**
 * Service die kaartgerelateerde OpenLayers-events exposeert
 * via observables.
 *
 * Deze service fungeert als façade over {@link CoreMapEventsService}
 * en biedt een vereenvoudigde API voor het luisteren naar
 * kaartinteracties.
 */
declare class GgcMapEventsService {
    private coreMapEventsService;
    /**
     * Returned een observable die emit zodra een zoomactie
     * op de opgegeven kaart is beëindigd.
     *
     * @param mapName Index van de kaart
     * @returns Observable met {@link MapEvent} bij het einde van een zoomactie
     */
    getZoomendObservableForMap(mapName: string): Observable<MapEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcMapEventsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcMapEventsService>;
}

/**
 * Event types voor tekeninteracties.
 */
declare enum DrawInteractionEventTypes {
    /** Wordt getriggerd wanneer een tekening wordt afgerond. */
    DRAWEND = "drawend",
    /** Wordt getriggerd wanneer een tekening wordt afgerond. De eindstijl wordt
     * toegepast, worden validators gecontroleerd en wordt de berekende
     * meting als property op de feature gezet. */
    DRAWSTART = "drawstart"
}
/**
 * Event dat wordt uitgezonden bij teken-interacties op de kaart.
 *
 * @param type - Type van het tekeninteractie-event.
 * @param drawType - Type tekening dat getekend wordt of is afgerond.
 * @param mapIndex - Index van de kaart waarop het event plaatsvindt.
 * @param message - Beschrijvend bericht bij het event.
 * @param event - Het onderliggende OpenLayers `DrawEvent`.
 * @param valid - Geeft aan of de tekening geldig is conform de ingestelde validatiefuncties. Default: `true`.
 * @param measurement - Optioneel: de berekende oppervlakte of lengte als string.
 */
declare class DrawInteractionEvent {
    type: DrawInteractionEventTypes;
    drawType: MapComponentDrawTypes;
    mapIndex: string;
    message: string;
    event: DrawEvent;
    valid: boolean;
    measurement?: string | undefined;
    constructor(type: DrawInteractionEventTypes, drawType: MapComponentDrawTypes, mapIndex: string, message: string, event: DrawEvent, valid?: boolean, measurement?: string | undefined);
}
/**
 * Map met tekenstijlen voor de tekeninteractie.
 * Wordt meegegeven aan `setDrawStyle`.
 *
 * De `drawingDrawStyle` wordt toegepast tijdens het tekenen,
 * de `finishDrawStyle` nadat de tekening is afgerond.
 * Als er geen eigen stijl wordt meegegeven, wordt de standaard OpenLayers-styling gebruikt.
 */
interface StyleLikeMap {
    /** Stijl voor de geometrie tijdens het tekenen. */
    drawingDrawStyle?: StyleLike;
    /** Stijl voor de geometrie na het afronden van de tekening. */
    finishDrawStyle?: StyleLike;
    /** Stijlfunctie voor een ongeldige geometrie na het afronden van de tekening. */
    invalidFinishDrawStyle?: StyleFunction;
    /** Stijl voor een ongeldige geometrie tijdens het tekenen. */
    invalidDrawStyle?: StyleLike;
    /** Stijl voor het oppervlaktelabel. Bestaat standaard uit een `textStyle` en een `imageStyle` voor de achtergrond. */
    areaLabelStyle?: Style;
    /** Stijl voor het totale lengte-label. Bestaat standaard uit een `textStyle` en een `imageStyle` voor de achtergrond. */
    lengthLabelStyle?: Style;
    /** Stijl voor de lengte-labels per segment. Bestaat standaard uit een `textStyle` en een `imageStyle` voor de achtergrond. */
    segmentLengthLabelStyle?: Style;
    /** Stijl voor de crosshair op de cursor. */
    crossHairStyle?: Style;
}

/**
 * Validatiefunctie voor een getekende feature.
 * Wordt aangeroepen bij elke muisbeweging tijdens het tekenen.
 *
 * @param feature - De getekende feature om te valideren.
 * @returns `true` als de feature geldig is, anders `false`.
 */
type ValidationFunction = (feature: Feature$1<Geometry>) => boolean;
/**
 * Opties voor het configureren van een tekeninteractie.
 * Wordt meegegeven aan `startDraw`, `startModify` en `startMove`.
 *
 * Een aantal opties kan ook achteraf voor reeds afgeronde tekeningen worden
 * toegepast via `resetDrawStyle`: `showSegmentLength`, `showTotalLength`,
 * `showArea`, `areaM2ToTextFunction` en `validators`.
 */
interface DrawOptions {
    /**
     * Het maximale aantal punten van het object.
     * Bij het bereiken van het maximum wordt de tekening automatisch afgerond.
     */
    maxPoints?: number;
    /**
     * Een array van validatiefuncties die het getekende object controleren.
     */
    validators?: ValidationFunction[];
    /**
     * Activeert tekenen via het middelpunt van de kaart in plaats van met de muis of touch-events.
     */
    centerDraw?: boolean;
    /**
     * Toont de lengte van elk afzonderlijk segment tijdens en na het tekenen.
     */
    showSegmentLength?: boolean;
    /**
     * Toont de totale lengte van alle segmenten samen tijdens en na het tekenen.
     */
    showTotalLength?: boolean;
    /**
     * Toont de oppervlakte van het polygoon tijdens en na het tekenen.
     */
    showArea?: boolean;
    /**
     * Overschrijft de standaardweergave van oppervlaktelabels bij het tekenen van polygonen.
     *
     * @param area - Oppervlakte in m².
     * @returns Weer te geven tekst voor het oppervlaktelabel.
     */
    areaM2ToTextFunction?: (area: number) => string;
    /**
     * Schakelt trace-functionaliteit in tijdens het tekenen.
     *
     * Wanneer deze optie op `true` staat, kan de gebruiker
     * bestaande geometrieën volgen (tracen) tijdens het tekenen
     * van een nieuwe feature. Dit is handig om nieuwe geometrieën
     * nauwkeurig uit te lijnen met bestaande objecten.
     *
     * @defaultValue false
     *
     */
    trace?: boolean;
    /**
     * De ID van de vector source die gebruikt wordt voor tracing.
     *
     * Wanneer tracing is ingeschakeld (`trace: true`), bepaalt deze
     * optie welke bron de features bevat die gevolgd kunnen worden
     * tijdens het tekenen.
     */
    traceSourceId?: string;
    /**
     * De snapping-tolerantie (in pixels) bij tracing.
     *
     * @defaultValue 12
     */
    traceSnapTolerance?: number;
}

declare enum ModifyInteractionEventTypes {
    MODIFYEND = "modifyend",
    MOVEEND = "moveend"
}
declare class ModifyInteractionEvent {
    type: ModifyInteractionEventTypes;
    mapIndex: string;
    message: string;
    event: ModifyEvent;
    valid: boolean;
    constructor(type: ModifyInteractionEventTypes, mapIndex: string, message: string, event: ModifyEvent, valid?: boolean);
}

interface CenterBaseOptions {
    crossHairStyle?: StyleLike;
}

interface CenterModifyOptions extends CenterBaseOptions {
    targetSource: VectorSource;
    modifyStyle?: StyleLike;
    selectedPointStyle?: StyleLike;
    pixelTolerance?: number;
    customKeyNextPoint?: string;
    customKeyPrevPoint?: string;
}

/**
 * Service voor het beheren van teken- en bewerkingsinteracties op de kaart.
 *
 * Deze service biedt methoden voor het starten, stoppen en configureren van
 * teken-, bewerk- en verplaatsingsinteracties, en het beheren van tekenlagen en features.
 */
declare class GgcDrawService {
    private readonly coreDrawService;
    private readonly coreDrawLayerService;
    /**
     * Start een interactie met het midden van de kaart (draw of modify),
     * toont een crosshair
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param croshairStyle - Optioneel: een alternatieve stijl voor de crosshair
     */
    startCenterInteraction(mapIndex?: string, croshairStyle?: StyleLike): void;
    /**
     * Stopt een Centerinteraction, de bestaande center interactie (draw of modify)
     * wordt gestopt en de crosshair verwijderd.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopCenterInteractions(mapIndex?: string): void;
    /**
     * Start het wijzigen van objecten met behulp van het centrum van de kaart.
     *
     * @param layerName - Naam van de laag met de te wijzigen objecten.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param options - Optioneel: options voor:
     *    - de laag,
     *    - de stijl voor het highlighten van objecten,
     *    - de stijl voor het highlighten van een te wijzigen punt van een object
     *    - de toetsenbordknoppen voor het tabben door punten van een object
     */
    startCenterModify(layerName: string, mapIndex?: string, options?: CenterModifyOptions): void;
    /**
     * Start het wijzigen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    startCenterModifyCurrentPoint(): void;
    /**
     * Stopt het wijzigen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    stopCenterModifyCurrentPoint(): void;
    /**
     * Verwijderen van een punt (highlighted vertex of tussenpunt)
     * van een object in de te wijzigen laag met behulp van het centrum van de kaart.
     */
    removeCenterModifyCurrentPoint(): void;
    /**
     * Voegt een feature toe aan een bestaande tekenlaag.
     *
     * @param layerName - Naam van de laag waaraan de feature toegevoegd wordt.
     * @param feature - Toe te voegen `ol/Feature`.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `MapComponentEvent` als bevestiging van de toevoeging.
     */
    addFeatureToLayer(layerName: string, feature: Feature<Geometry>, mapIndex?: string): MapComponentEvent$1;
    removeFeatureFromLayer(layerName: string, feature: Feature<Geometry>, mapIndex?: string): void;
    /**
     * Voegt een coördinaat toe aan de huidige actieve tekening.
     *
     * @param coordinates - Toe te voegen coördinaat.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    appendCoordinates(coordinates: Coordinate, mapIndex?: string): void;
    /**
     * Verwijdert het laatste toegevoegde punt van de huidige actieve tekening.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    removeLastPoint(mapIndex?: string): void;
    /**
     * Geeft de coördinaten terug van de huidige actieve tekening, exclusief de positie van de cursos.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns Array van `Coordinate` of `undefined` als er geen actieve tekening is.
     */
    getSketchCoordinates(mapIndex?: string): Coordinate[] | undefined;
    /**
     * Verwijdert alle features uit de opgegeven laag.
     *
     * @param layerName - Naam van de te legen laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    clearLayer(layerName: string, mapIndex?: string): void;
    /**
     * Verwijdert de opgegeven laag van de kaart.
     *
     * @param layerName - Naam van de te verwijderen laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    deleteLayer(layerName: string, mapIndex?: string): void;
    /**
     * Rondt de huidige actieve tekening af.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    finishCurrentDraw(mapIndex?: string): void;
    /**
     * Geeft een `Observable` terug met tekeninteractie-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van `DrawInteractionEvent`.
     */
    getDrawEventsObservable(mapIndex?: string): Observable<DrawInteractionEvent>;
    /**
     * Geeft een `Observable` terug met bewerkingsinteractie-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van `ModifyInteractionEvent`.
     */
    getModifyEventsObservable(mapIndex?: string): Observable<ModifyInteractionEvent>;
    /**
     * Haalt alle features op uit de opgegeven tekenlaag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns Array van `Feature<Geometry>`.
     */
    getFeaturesFromLayer(layerName: string, mapIndex?: string): Feature<Geometry>[];
    /**
     * Controleert of de opgegeven laag zichtbaar is.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `true` als de laag zichtbaar is, anders `false`.
     */
    isLayerVisible(layerName: string, mapIndex?: string): boolean;
    /**
     * Stelt de tekenstijl in voor de opgegeven laag.
     *
     * @param layerName - Naam van de laag.
     * @param styleLikeMap - Toe te passen stijl als `StyleLikeMap`.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setDrawStyle(layerName: string, styleLikeMap: StyleLikeMap, mapIndex?: string): void;
    /**
     * Stelt de zichtbaarheid van een laag in.
     *
     * @param layerName - Naam van de laag.
     * @param visible - `true` om de laag zichtbaar te maken, `false` om te verbergen.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setLayerVisibility(layerName: string, visible: boolean, mapIndex?: string): void;
    /**
     * Stelt de z-index in van de opgegeven laag.
     *
     * @param zIndex - Gewenste z-index waarde.
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    setLayerZIndex(zIndex: number, layerName: string, mapIndex?: string): void;
    /**
     * Start het tekenen van objecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop getekend wordt.
     * @param drawType - Type tekening (bijv. punt, lijn, polygoon).
     * @param drawOptions - Opties voor de tekeninteractie.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    startDraw(layerName: string, drawType: MapComponentDrawTypes, drawOptions: DrawOptions, mapIndex?: string): void;
    /**
     * Start het bewerken van opbjecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop bewerkt wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de bewerkingsinteractie. Default: leeg object.
     * @param deleteCondition - Optioneel: ol/Condition om een vertex te verwijderen. Default: never.
     * @param insertVertexCondition - Optioneel: ol/Condition om een vertex in te voegen. Default: never.
     */
    startModify(layerName: string, mapIndex?: string, drawOptions?: DrawOptions, deleteCondition?: Condition, insertVertexCondition?: Condition): void;
    /**
     * Start het verplaatsen van objecten op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop verplaatst wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de verplaatsingsinteractie. Default: leeg object.
     */
    startMove(layerName: string, mapIndex?: string, drawOptions?: DrawOptions): void;
    /**
     * Stopt het verplaatsen van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopMove(mapIndex?: string): void;
    /**
     * Stopt het tekenen van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopDraw(mapIndex?: string): void;
    /**
     * Stopt het tekenen, leegt de laag en verwijdert daarna de laag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopDrawAndClearLayer(layerName: string, mapIndex?: string): void;
    /**
     * Stopt het bewerken van objecten.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopModify(mapIndex?: string): void;
    /**
     * Wisselt de zichtbaarheid van de opgegeven laag.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    toggleLayer(layerName: string, mapIndex?: string): void;
    /**
     * Reset de tekenstijl van de opgegeven laag naar de standaardstijl.
     *
     * @param layerName - Naam van de laag.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param drawOptions - Opties voor de tekenstijl. Default: leeg object.
     */
    resetDrawStyle(layerName: string, mapIndex?: string, drawOptions?: DrawOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcDrawService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcDrawService>;
}

declare class SnapExtendedEvent {
    action: "snap" | "unsnap";
    snappedTo: "vertex" | "line" | undefined;
    snapEvent: SnapEvent;
}

interface SnapOptions {
    pixelTolerance?: number;
    snapLayers?: string[];
    snapDrawLayers?: string[];
    vertex?: boolean;
    edge?: boolean;
    intersection?: boolean;
    segmenters?: Segmenters;
}

/**
 * Service voor het beheren van snap-interacties op de kaart.
 *
 * Deze service biedt methoden voor het starten en stoppen van snap-interacties,
 * en het ophalen van snap-events.
 */
declare class GgcSnapService {
    private readonly coreSnapService;
    /**
     * Start snappen op de opgegeven laag.
     *
     * @param layerName - Naam van de laag waarop gesnapped wordt.
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @param snapOptions - Opties voor de snap-interactie. Default: leeg object.
     */
    startSnap(layerName: string, mapIndex?: string, snapOptions?: SnapOptions): void;
    /**
     * Stopt snappen.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     */
    stopSnap(mapIndex?: string): void;
    /**
     * Geeft een `Observable` terug met uitgebreide snap-events voor de opgegeven kaart.
     *
     * @param mapIndex - Index van de kaart. Default: `DEFAULT_MAPINDEX`.
     * @returns `Observable` van snap-events.
     */
    getSnapExtendedEventsObservable(mapIndex?: string): rxjs.Observable<SnapExtendedEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcSnapService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcSnapService>;
}

/**
 * @deprecated verhuisd naar models
 * Mogelijke types voor kaartevents.
 *
 * Deze enum wordt gebruikt in {@link MapComponentEvent} om het type
 * gebeurtenis eenduidig te identificeren, zoals zoomacties,
 * klikinteracties en selection-updates.
 */
declare enum MapComponentEventTypes {
    /** Kaart is succesvol geïnitialiseerd */
    MAPINITIALIZED = "mapInitialized",
    /** Zoomactie is beëindigd */
    ZOOMEND = "zoomEnd",
    /** Zoomactie naar een specifieke locatie is beëindigd */
    ZOOMENDLOCATION = "zoomEndLocation",
    /** Enkelvoudige klik op de kaart */
    SINGLECLICK = "singleClick",
    /** WMS capabilities zijn opgehaald */
    WMSCAPABILITIES = "WmsCapabilities",
    /** WMS feature-informatie is opgehaald */
    WMSFEATUREINFO = "WmsFeatureInfo",
    /** WMTS capabilities zijn opgehaald */
    WMTSCAPABILITES = "WmtsCapabilites",
    /** WMTS feature-informatie is opgehaald*/
    WMTSFEATUREINFO = "WmtsFeatureInfo",
    /** feature-informatie van een vector laag is opgehaald*/
    VECTORFEATUREINFO = "vectorFeatureInfo",
    /** feature-informatie van een GeoJson vector laag is opgehaald*/
    GEOJSONFEATUREINFO = "geoJsonFeatureInfo",
    /** Actie is succesvol uitgevoerd */
    SUCCESSFUL = "successful",
    /** Actie is niet succesvol uitgevoerd */
    UNSUCCESSFUL = "unsuccessful",
    /** Kaart of laag is aan het laden */
    LOADING = "loading",
    /** Kaartklik afkomstig van de selection service */
    SELECTIONSERVICE_MAPCLICKED = "selectionServiceMapClicked",
    /** Selection service heeft de selectie gewist */
    SELECTIONSERVICE_CLEARSELECTION = "selectionServiceClearSelection",
    /** Selection service heeft een nieuwe selectie gezet */
    SELECTIONSERVICE_SELECTIONUPDATED = "selectionServiceSelectionUpdated"
}
/**
 * @deprecated verhuisd naar models
 * Standaard event-object voor communicatie vanuit kaartcomponenten
 * en kaartservices.
 *
 * Wordt gebruikt om kaartinteracties, statusupdates en resultaten
 * eenduidig door te geven aan afnemende componenten.
 */
declare class MapComponentEvent {
    type: MapComponentEventTypes;
    mapIndex: string;
    message: string;
    layerName?: string | undefined;
    value?: any | undefined;
    /**
     *
     * Maakt een nieuw MapComponentEvent aan.
     *
     * @param type Type van het event (zie MapComponentEventTypes)
     * @param mapIndex Index of naam van de kaart waarop het event betrekking heeft
     * @param message Beschrijvende tekst van het event (het zoomen is beeindingd, ...)
     * @param layerName (optioneel) Naam van de laag die het event heeft veroorzaakt
     * @param value (optioneel) het oorspronkelijke event indien aanwezig
     */
    constructor(type: MapComponentEventTypes, mapIndex: string, message: string, layerName?: string | undefined, value?: any | undefined);
}
/**
 * @deprecated
 * Beschrijft de huidige status van een kaartview.
 *
 * Wordt gebruikt om de centrering en het zoomniveau van een kaart
 * vast te leggen of te herstellen.
 */
declare class MapViewState {
    center: Coordinate;
    zoom: number;
    constructor(center: Coordinate, zoom: number);
}

/**
 * Configuratie voor het starten van een Select interaction
 */
interface SelectOptions {
    /**
     * OL condition waarop de selectie wordt gemaakt (bijv. singleclick, pointerMove, etc.)
     * Als deze waarde wordt leeggelaten, dan wordt de standaard condition gebruikt van de verschillende select modes.
     * WMS/WMTS kaartlagen werken alleen met een enkele klik en deze optie doet in dat geval niets.
     */
    condition?: Condition;
    /**
     * Een filter voor de selectielagen. Dit is een lijst van layerIds waarop de selecties worden toegepast.
     * Als deze leeg is, dan worden alle layers gebruikt voor selecties waar dit kan.
     */
    layerIds?: string[];
    /**
     * Style voor geselecteerde features.
     * Bij de waarde null zal geen andere style worden toegepast op de selectie.
     */
    style?: StyleLike | null;
    /**
     * De pixel tolerantie voor het selecteren van een feature. Default is 0.
     * Werkt niet met WMS/WMTS kaartlagen.
     */
    hitTolerance?: number;
    /**
     * De select mode van de selectie.
     * Single (default) - 1 feature wordt geselecteerd met een single click
     * Multi - meerdere feature worden geselecteerd met een single click
     * OpenlayersDefault - met singleclick is er een single select, met shift-click is er een multi select
     */
    selectMode?: "single" | "multi" | "openlayersDefault";
}

/**
 * Beschrijft de mogelijke selectiemodi voor het selecteren
 * van objecten op de kaart.
 */
declare enum SelectionModeTypes {
    /** Selectie van één enkel object tegelijk */
    SINGLE_SELECT = "singleselect",
    /** Selectie van meerdere objecten tegelijk */
    MULTI_SELECT = "multiselect"
}

/**
 * InjectionToken voor optionele configuratie van de OpenLayers zoomcontrol.
 *
 * Kan worden gebruikt om standaard zoomopties te overschrijven bij
 * het initialiseren van de kaart.
 *
 * @see Options
 */
declare const ZOOM_OPTIONS: InjectionToken<Options | undefined>;
/**
 * InjectionToken voor optionele configuratie van de OpenLayers rotatecontrol.
 *
 * Hiermee kunnen instellingen zoals zichtbaarheid en gedrag van
 * de rotatieknop worden aangepast.
 *
 * @see Options
 */
declare const ROTATE_OPTIONS: InjectionToken<Options | undefined>;
/**
 * InjectionToken voor optionele configuratie van de OpenLayers attributioncontrol.
 *
 * Wordt gebruikt om attributie-instellingen (zoals collapsible of custom labels)
 * te configureren.
 *
 * @see Options
 */
declare const ATTRIBUTION_OPTIONS: InjectionToken<Options | undefined>;

/**
 * Configuratie voor een coördinatenreferentiesysteem (CRS).
 *
 * Dit interface beschrijft alle benodigde eigenschappen om een
 * kaartprojectie en bijbehorende WMTS-/tile-instellingen te configureren.
 */
interface CrsConfig {
    /**
     * EPSG-code of projectie-identificatie (bijv. "EPSG:28992").
     */
    projectionCode: string;
    /**
     * Geldige extent van de projectie.
     */
    extent: Extent;
    /**
     * Resoluties per zoomniveau.
     */
    resolutions: number[];
    /**
     * Identifier van de matrixset.
     */
    matrixSet: string;
    /**
     * Matrix-identifiers per zoomniveau.
     */
    matrixIds: string[];
    /**
     * Matrixgroottes per zoomniveau.
     */
    matrixSizes: number[];
    /**
     * Eenheid van de projectie (bijv. meters of graden).
     */
    units: Units;
}

/**
 * Service die configuratie levert voor het RD New
 * coördinatenreferentiesysteem (EPSG:28992).
 *
 * Deze service bouwt en cachet een {@link CrsConfig} die wordt gebruikt
 * voor kaartprojectie, resoluties en WMTS-matrixinstellingen.
 */
declare class GgcCrsConfigService {
    /**
     * Maximale ondersteunde zoomlevel voor RD New.
     */
    static MAX_ZOOMLEVEL: number;
    /**
     * Interne cache van de RD New CRS-configuratie.
     */
    rdNewCrsConfig: CrsConfig;
    /**
     * Geeft de configuratie voor het RD New coördinatenreferentiesysteem (EPSG:28992).
     *
     * De configuratie wordt lazy geïnitialiseerd en hergebruikt bij volgende aanroepen.
     *
     * @returns {@link CrsConfig} voor RD New
     */
    getRdNewCrsConfig(): CrsConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcCrsConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcCrsConfigService>;
}

/**
 * Service voor het selecteren en highlighten van features op de kaart.
 *
 * De {@link GgcSelectionService} biedt ondersteuning voor selectie‑interacties
 * op verschillende typen kaartlagen en abstracteert de onderliggende
 * OpenLayers‑selectielogica via de {@link CoreSelectionService}.
 *
 * ## Ondersteunde kaartlagen
 *
 * De service ondersteunt selecties op alle kaartlagen, maar het gebruik van
 * **WFS‑ of OGC‑kaartlagen** wordt sterk aanbevolen. Deze lagen bevatten features
 * als vector‑data in de front‑end, wat uitgebreidere en stabielere selectiemogelijkheden
 * biedt.
 *
 * Selecties op **WMS/WMTS‑kaartlagen** worden ook ondersteund, maar kennen
 * functionele beperkingen (zie hieronder).
 *
 * ## Selectiemodi voor WFS en OGC kaartlagen
 *
 * Voor WFS‑ en OGC‑kaartlagen zijn de volgende selectiemodi beschikbaar:
 *
 * - **Single select**
 *   Door te klikken wordt één feature geselecteerd. Een nieuwe selectie
 *   vervangt de bestaande selectie.
 *
 * - **Multi select**
 *   Meerdere features kunnen geselecteerd worden. Door op een reeds
 *   geselecteerde feature te klikken, wordt deze uit de selectie verwijderd.
 *
 * - **OpenLayers default**
 *   Standaard OpenLayers‑gedrag:
 *   - normale klik → single select
 *   - shift‑klik → multi select
 *
 * ## Selecties op WMS en WMTS kaartlagen
 *
 * Selecties op WMS‑ en WMTS‑kaartlagen werken anders dan bij vector‑lagen,
 * omdat de features niet permanent in de front‑end beschikbaar zijn.
 *
 * Voor WMS/WMTS‑selecties gelden de volgende vereisten en beperkingen:
 *
 * - De kaartlaag moet de property `getFeatureInfoOnSingleclick` op `true` hebben.
 * - Selecties werken alleen via **singleclick** in:
 *   - single select modus
 *   - multi select modus
 * - De GetFeatureInfo‑response **moet een geometry bevatten**,
 *   anders kan de feature niet worden gehighlight.
 *
 * Buiten deze beperkingen gedragen WMS‑ en WMTS‑kaartlagen zich verder hetzelfde
 * binnen de {@link GgcSelectionService} en kunnen zij:
 *
 * - gecombineerd worden met andere kaartlagen;
 * - gelijktijdig gebruikt worden met WFS/OGC‑lagen;
 * - gefilterd worden via `layerIds` bij het starten van een selectie.
 *
 * ## Events en observables
 *
 * De service throws selectie‑events via een {@link Observable} van
 * {@link MapComponentEvent}. Deze events kunnen gebruikt worden om
 * selectie‑wijzigingen te volgen en te synchroniseren met andere componenten.
 *
 * @see {@link SelectOptions}
 */
declare class GgcSelectionService {
    private readonly coreSelectionService;
    /**
     * @deprecated
     * Zet de selectiemodus van de kaart op **single select**.
     * Hierbij kan steeds slechts één object tegelijk geselecteerd worden.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectiemodus wordt ingesteld.
     */
    setSingleselectMode(mapIndex?: string): void;
    /**
     * @deprecated
     * Zet de selectiemodus van de kaart op **multi select**.
     * Hierbij kunnen meerdere objecten tegelijk geselecteerd worden.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectiemodus wordt ingesteld.
     */
    setMultiselectMode(mapIndex?: string): void;
    /**
     * Start een selectie‑interactie op de kaart.
     *
     * @param options Configuratie voor de selectie, zoals selectiemodus
     * en aanvullende selectie‑opties.
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt gestart.
     * @param selectIndex Optionele selectIndex (default: undefined) waarmee een
     * select interaction wordt geïdentificeerd. Als undefined, dan wordt de mapIndex gebruikt voor de selectIndex.
     * Met selectIndex kunnen meerdere select interactions actief zijn op 1 kaart.
     */
    startSelect(options: SelectOptions, mapIndex?: string, selectIndex?: string | undefined): void;
    /**
     * Stopt de actieve selectie‑interactie op de kaart.
     *
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt gestopt.
     */
    stopSelect(selectIndex?: string): void;
    /**
     * Verwijdert alle huidige selecties van de opgegeven kaart.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de selectie wordt gewist.
     * @param selectIndex Optionele selectIndex waarvoor
     * de selectie wordt gewist.
     */
    clearSelection(mapIndex?: string, selectIndex?: string): void;
    /**
     * Cleart alle selecties voor de opgegeven kaartindex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX)
     * waarvoor alle selecties worden gewist.
     */
    clearAllSelectionsForMapIndex(mapIndex?: string): void;
    /**
     * @deprecated
     * Zet een selectie voor een specifieke kaartlaag.
     * Bestaande selecties voor deze laag worden overschreven.
     *
     * @param features Array van OpenLayers features die geselecteerd moeten worden.
     * @param layerName Naam van de kaartlaag waarop de selectie betrekking heeft.
     * @param mapIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt toegepast.
     */
    setSelectionForLayer(features: Feature<Geometry>[], layerName: string, mapIndex?: string): void;
    /**
     * Overschrijft de bestaande selectie met de meegegeven features.
     *
     * @param features De nieuwe OpenLayers features die geselecteerd worden.
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarop
     * de selectie wordt overschreven.
     */
    setSelection(features: Feature<Geometry>[], selectIndex?: string): void;
    /**
     * Geeft de actieve selectie van de opgegeven kaart.
     *
     * @param selectIndex Optionele selectIndex/kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * de huidige selectie wordt opgehaald.
     * @returns De huidige selectie voor de opgegeven kaart.
     */
    getCurrentSelection(selectIndex?: string): Feature<Geometry, {
        [x: string]: any;
    }>[];
    /**
     * Geeft een observable die selectie‑gerelateerde events emit
     * voor de opgegeven kaart. De mapIndex in het event refereert naar de selectIndex als die is opgegeven, anders de mapIndex.
     *
     * @param mapIndex Optionele kaartindex (default: DEFAULT_MAPINDEX) waarvoor
     * selectie‑events worden gevolgd.
     * @param selectIndex Optionele selectIndex waarvoor
     * selectie‑events worden gevolgd.
     * @returns Observable met {@link MapComponentEvent} selectie‑events.
     */
    getObservable(mapIndex?: string, selectIndex?: string): Observable<MapComponentEvent$1>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcSelectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcSelectionService>;
}

/**
 * @deprecated verhuisd naar ggc-models
 * Verzameling van features die behoren tot één specifieke kaartlaag.
 */
declare class FeatureCollectionForLayer {
    /**
     * @deprecated
     * Naam van de laag waartoe de features behoren.
     */
    layerName?: string;
    /**
     * LayerId van de laag waartoe de features behoren.
     */
    layerId: string;
    /**
     * Title van de laag waartoe de features behoren, indien opgegeven.
     */
    layerTitle?: string;
    /**
     * Lijst van OpenLayers features met geometrie.
     */
    features: Feature<Geometry>[];
}
/**
 * @deprecated verhuisd naar ggc-models
 * Verzameling van features gegroepeerd per laag voor een specifieke
 * kaartcoördinaat.
 *
 * Wordt bijvoorbeeld gebruikt bij feature-informatie of
 * selectieresultaten op een kaartlocatie.
 */
declare class FeatureCollectionForCoordinate {
    /**
     * Coördinaat waarop de featurecollecties betrekking hebben.
     */
    coordinate?: Coordinate;
    /**
     * Verzameling van featurecollecties per kaartlaag.
     */
    featureCollectionForLayers: FeatureCollectionForLayer[];
    /**
     * @param coord Optionele kaartcoördinaat
     */
    constructor(coord?: Coordinate);
}

/**
 * Converteert een OpenLayers feature naar een GeoJSON feature.
 *
 * De geometrie wordt getransformeerd van de kaartprojectie
 * (EPSG:28992) naar de opgegeven data-projectie.
 *
 * @param feature OpenLayers feature met geometrie
 * @param dataProjection Doelprojectie voor de GeoJSON output
 * (default "EPSG:4326")
 * @returns GeoJSON {@link Feature}
 */
declare const toGeoJSONFeature: (feature: Feature<Geometry$1>, dataProjection?: string) => Feature$2;
/**
 * Converteert een GeoJSON feature naar één of meerdere
 * OpenLayers features.
 *
 * De geometrie wordt getransformeerd van de data-projectie
 * naar de kaartprojectie (EPSG:28992).
 *
 * @param feature GeoJSON feature
 * @param dataProjection Projectie van de GeoJSON input
 *                       (default "EPSG:4326")
 * @returns Eén of meerdere OpenLayers features
 */
declare const fromGeoJSONFeature: (feature: Feature$2, dataProjection?: string) => Feature<Geometry$1> | Feature<Geometry$1>[];
/**
 * Converteert een GeoJSON FeatureCollection naar
 * OpenLayers features.
 *
 * De geometrieën worden getransformeerd van de data-projectie
 * naar de kaartprojectie (EPSG:28992).
 *
 * @param features GeoJSON FeatureCollection
 * @param dataProjection Projectie van de GeoJSON input
 *                       (default "EPSG:4326")
 * @returns Array van OpenLayers features
 */
declare const fromGeoJSONFeatures: (features: FeatureCollection, dataProjection?: string) => Feature<any>[];
/**
 * Zet een draw-interactietype om naar een OpenLayers
 * geometrie-type.
 *
 * Wordt gebruikt bij het configureren van draw-interacties
 * en geometrie-afhankelijke logica.
 *
 * @param drawType Type van de draw-interactie
 * @returns OpenLayers geometrie-type
 */
declare const drawTypeToGeometryType: (drawType: MapComponentDrawTypes) => Type;

/**
 * Geldige extent (bounding box) voor het RD New
 * coördinatenreferentiesysteem (EPSG:28992).
 *
 * Wordt gebruikt om de kaart- en tegelgrenzen te bepalen.
 */
declare const extent: number[];
/**
 * Resoluties per zoomniveau voor EPSG:28992.
 *
 * De index in deze array komt overeen met het zoomniveau.
 */
declare const resolutions: number[];
/**
 * Matrixgroottes per zoomniveau voor tiles in EPSG:28992.
 *
 * Elke waarde vertegenwoordigt het aantal tegels
 * per richting (x en y) op dat zoomniveau.
 */
declare const matrixSizes: number[];
/**
 * EPSG-code voor het RD New coördinatenreferentiesysteem.
 */
declare const epsg28992 = "EPSG:28992";
/**
 * Matrix-identifiers per zoomniveau.
 *
 * De identifiers zijn opgebouwd uit de EPSG-code en het bijbehorende zoomniveau.
 */
declare const matrixIds: string[];
/**
 * Zet een resolutie voor EPSG:28992 om naar een zoomniveau.
 *
 * @param resolution resolutie voor EPSG:28992
 * @returns Zoomniveau behorend bij het resolutie
 */
declare function resolutionToZoomlevel(resolution: number): number;
/**
 * Zet een zoomniveau om naar een resolutie voor EPSG:28992.
 *
 * @param zoomlevel Zoomniveau
 * @returns Resolutie behorend bij het zoomniveau
 */
declare function zoomlevelToResolution(zoomlevel: number): number;
/**
 * Zet een kaartschaal om naar een resolutie.
 *
 * Gebaseerd op de standaard pixelgrootte van
 * 0.28 mm per pixel (diagonaal).
 *
 * @param scale Kaartschaal
 * @returns Resolutie
 */
declare function scaleToResolution(scale: number): number;

/**
 * Controleert of een featurecollectie voor een laag één of meerdere
 * geclusterde features bevat (features in een feature).
 *
 * Een clusterfeature wordt herkend aan de aanwezigheid
 * van een `features` property met meer dan één onderliggend feature.
 *
 * @param featureinfo Featurecollectie voor een specifieke laag
 * @returns `true` indien er minimaal één clusterfeature aanwezig is,
 *          anders `false`
 */
declare const featureCollectionForLayerHasCluster: (featureinfo: FeatureCollectionForLayer$1) => boolean;
/**
 * Haalt de onderliggende features uit geclusterde features
 * en geeft deze terug als een vlakke lijst.
 *
 * Deze functie wordt gebruikt om clusterfeatures te
 * "declusteren" naar losse OpenLayers features.
 *
 * @param features Array van (cluster)features
 * @returns Array met individuele OpenLayers features
 */
declare const declusterFeatures: (features: Feature<Geometry>[]) => Feature<Geometry>[];

/**
 * Basale laagopties die gebruikt worden om een laag aan een specifieke kaart te koppelen.
 */
interface AbstractBaseLayerOptions {
    /**
     * De naam van de kaart waarop de laag moet worden toegevoegd.
     */
    mapIndex?: string;
    /**
     * Optioneel: Een unieke identifier voor deze layer.
     * Kan gebruikt worden om via MapService.getLayer() de laag te verkrijgen.
     */
    layerId?: string;
    /**
     * Optioneel: de weergavenaam van de kaartlaag.
     */
    title?: string;
    /**
     * Optioneel: wanneer true, dan is de kaartlaag initieel zichtbaar op de kaart.
     */
    visible?: boolean;
    /**
     * Optioneel: wanneer true, dan wordt deze layer niet meer verwijderd als deze wordt uitgezet met de dataset-tree,
     * maar wordt de laag onzichtbaar gemaakt, waardoor deze intern wel blijft bestaan.
     * Met deze optie worden bijvoorbeeld features die op een later moment handmatig zijn toegevoegd ook bewaard op de laag als deze wordt uitgezet.
     */
    persistent?: boolean;
}
/**
 * Uitgebreide configuratieopties voor een laag.
 * Breidt AbstractBaseLayerOptions uit.
 */
interface AbstractConfigurableLayerOptions extends AbstractBaseLayerOptions {
    /**
     * Optioneel: Instellen van de naam van de kaartlaag. Deze naam wordt ook meegegeven
     * in de events vanuit de kaartlaag, zodat herkend kan worden welke kaartlaag
     * het event heeft gegooid.
     */
    layerName?: string;
    /**
     * Optioneel: Instellen van de minimale resolutie waarbij de kaartlaag zichtbaar is
     * en er op de beschikbare featureInfo kan worden geklikt.
     */
    minResolution?: number;
    /**
     * Optioneel: Instellen van de maximale resolutie waarbij de kaartlaag zichtbaar is
     * en er op de beschikbare featureInfo kan worden geklikt.
     */
    maxResolution?: number;
    /**
     * Optioneel: Instellen van het minimale zoomniveau waarbij de kaartlaag zichtbaar is.
     * Wordt overschreven door maxResolution als deze is opgegeven.
     */
    minZoomLevel?: number;
    /**
     * Optioneel: Instellen van het maximale zoomniveau waarbij de kaartlaag zichtbaar is.
     * Wordt overschreven door minResolution als deze is opgegeven.
     */
    maxZoomLevel?: number;
    /**
     * Optioneel: Instellen van de z-index voor de volgorde waarin de layer in de kaart
     * weergegeven wordt. Wanneer er meerdere layers zijn met dezelfde z-index, is de
     * volgorde waarin de layer aan de kaart is toegevoegd bepalend. Wanneer er geen
     * z-index is ingesteld, krijgt deze de default waarde 0.
     * Niet beschikbaar voor de ggc-layer-brt-achtergrondkaart.
     */
    zIndex?: number;
    /**
     * Optioneel: Tekst die kan worden meegegeven aan de kaartlaag waarin bijvoorbeeld
     * copyright wordt verleend. Deze tekst wordt onderin de kaart in open-klapbare info
     * dialoog weergeven. Wanneer de attributions bij meerdere kaartlagen is ingesteld,
     * worden deze naast elkaar getoond in de dialoog. Wanneer bij verschillende
     * kaartlagen dezelfde tekst is ingesteld, wordt deze eenmaal weergegeven in de dialoog.
     */
    attributions?: string;
    /**
     * URL voor het invoeren van de WMS / WMTS / GeoJSON / Vector Tile / Image url.
     */
    url?: string;
    /**
     * Optioneel: Het legenda object voor deze laag.
     */
    activeLegend?: LegendType;
    /**
     * Optioneel: De legendIndex bepaalt de volgorde waarin de legenda in het
     * legendcomponent getoond wordt.
     */
    legendIndex?: number;
    /**
     * Optioneel: de opacity van de kaartlaag
     */
    opacity?: number;
}
/**
 * Extra opties voor lagen die klikbare functionaliteit ondersteunen.
 * Breidt AbstractConfigurableLayerOptions uit.
 */
interface AbstractClickableLayerOptions extends AbstractConfigurableLayerOptions {
    /**
     * Optioneel: Instellen dat er op de kaartlaag geklikt kan worden,
     * waardoor er informatie door middel van een 'GetFeatureInfo' request wordt opgehaald.
     * De FeatureInfo is ook afhankelijk van de ingestelde [minResolution] en
     * [maxResolution] of deze beschikbaar is.
     */
    getFeatureInfoOnSingleclick?: boolean;
    /**
     * Optioneel: Instellen van het maximaal op te halen aantal geografische objecten
     * bij het gebruik van _ getFeatureInfoOnSingleclick_. Bij het niet instellen
     * van de property worden default maximaal 8 objecten per request opgehaald.
     */
    maxFeaturesOnSingleclick?: number;
}

/**
 * Interface voor het configureren van webservices.
 */
interface Webservice {
    /** Type service */
    type: Webservice2DType;
    /** Optioneel: titel van de service */
    title?: string;
    /** URL van de service */
    url: string;
    /** extra http headers zoals bijvoorbeeld een API-key bij het opvragen van een webservice */
    customHeaders?: [string, string][];
    /** Kaartlagen die van de service opgehaald worden */
    layers: AbstractConfigurableLayerOptions[];
}

/**
 * `<ggc-map></ggc-map>` toont een 2D kaart waar verschillende lagen aan toegevoegd
 * kunnen worden.
 *
 * Let op: om de kaarten te tonen, moet het `ggc-map` element een specifieke
 * hoogte meekrijgen vanuit CSS, zoals in het voorbeeld hieronder.
 *
 * Dit component vormt het hart van de GGC kaartarchitectuur en is
 *  verantwoordelijk voor:
 *   - initialisatie en vernietiging van de OpenLayers Map
 *   - koppelen van kaart‑events aan GGC‑events
 *   - laden van webservices en lagen
 *   - selectie, tekenen en loading‑status
 *
 * @example
 * kaartConfig = [
 *     {
 *       url: "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0?",
 *       type: "wmts",
 *       layers: [
 *         {
 *           layerId: "brtAchtergrondkaartStandaard",
 *           title: "BRT achtergrond kaart Standaard (WMTS)",
 *           layerName: "standaard",
 *           visible: true,
 *           zIndex: 0
 *         }
 *       ]
 *     }
 * ];
 *
 * <div style="height: 500px">
 *   <ggc-map [webServices]="kaartConfig"></ggc-map>
 * </div>
 */
declare class GgcMapComponent implements AfterViewInit, OnDestroy {
    /** Unieke naam/index van de kaart */
    mapIndex: string;
    /** tabIndex t.b.v. toetsenbordnavigatie */
    mapTabIndex: number | undefined;
    /** ARIA role voor accessibility */
    ariaRole: string;
    /** ARIA label voor screenreaders */
    ariaLabel: string;
    /**
     * Output event‑stream van het kaartcomponent.
     *
     * Emit o.a.:
     * - MAPINITIALIZED
     * - SINGLECLICK
     * - ZOOMEND / ZOOMENDLOCATION
     * - LOADING
     */
    events: EventEmitter<MapComponentEvent$1>;
    /** DOM‑element waarin de kaart gerenderd wordt */
    private readonly mapElement;
    private readonly eventsMap;
    private _minZoomlevel;
    private _maxZoomlevel;
    private lastChangeResolutionEvent;
    private readonly coreMapService;
    private readonly mapEventsService;
    private readonly coreLoadingService;
    private readonly coreSelectionService;
    private readonly coreDrawService;
    private readonly ggcLayerService;
    private readonly OL_MOVEEND;
    private readonly OL_SINGLECLICK;
    private readonly OL_CHANGE_RESOLUTION;
    private readonly OL_PRECOMPOSE;
    private readonly OL_RENDERCOMPLETE;
    private isLoading$;
    private _webServices;
    /**
     * Webservices met lagen die op de kaart geladen moeten worden.
     */
    set webServices(webservices: Webservice[]);
    /**
     * minZoomlevel van de kaart
     * Waarde wordt geclamped binnen CRS‑limieten.
     */
    set minZoomlevel(value: number);
    get minZoomlevel(): number;
    /**
     * Maximum zoomlevel van de kaart.
     * Waarde wordt geclamped binnen CRS‑limieten.
     */
    set maxZoomlevel(value: number);
    get maxZoomlevel(): number;
    /**
     * Initialiseert de kaart nadat de view beschikbaar is.
     *
     * - valideert zoomlevels
     * - creëert de OpenLayers map
     * - koppelt OL‑events aan GGC‑events
     */
    ngAfterViewInit(): void;
    /**
     * Verwerkt alle OpenLayers events en vertaalt deze
     * naar GGC MapComponent events.
     */
    processEvent(mapEvent: MapEvent | RenderEvent | ObjectEvent): void;
    /**
     * Laadt webservices en hun lagen via de LayerService.
     */
    private loadWebservices;
    /**
     * Haalt huidige kaartpositie en zoomniveau op.
     */
    getLocationFromMapEvent(mapEvent: MapEvent): MapViewState$1;
    /**
     * Opruimen van events, subscriptions en map‑resources.
     */
    ngOnDestroy(): void;
    /**
     * Initialiseert de loader‑events van de kaart.
     */
    private initializeLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcMapComponent, "ggc-map", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; "mapTabIndex": { "alias": "mapTabIndex"; "required": false; }; "ariaRole": { "alias": "ariaRole"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "webServices": { "alias": "webServices"; "required": false; }; "minZoomlevel": { "alias": "minZoomlevel"; "required": false; }; "maxZoomlevel": { "alias": "maxZoomlevel"; "required": false; }; }, { "events": "events"; }, never, never, true, never>;
}

/**
 * Opties voor het configureren van een Geojson laag binnen een kaartapplicatie.
 */
interface GeojsonLayerOptions extends AbstractClickableLayerOptions {
    /**
     * Optioneel: instellen van de layerOptions voor de OpenLayers Layer.
     * Hiermee kunnen onder andere `zIndex`, `minResolution` en `maxResolution` worden ingesteld.
     * Zie de OpenLayers documentatie voor meer informatie: [VectorLayer](https://openlayers.org/en/latest/apidoc/module-ol_layer_Vector-VectorLayer.html)
     */
    layerOptions?: Options$1<Feature<Geometry>, VectorSource<Feature<Geometry>>>;
    /**
     * Optioneel: instellen van de sourceOptions voor de OpenLayers Source.
     * Hier kan onder andere de zIndex, minResolution en maxResolution worden ingesteld.
     * Voor alle opties zie: [VectorLayer](https://openlayers.org/en/latest/apidoc/module-ol_layer_Vector-VectorLayer.html)
     */
    sourceOptions?: Partial<Options$2>;
    /**
     * Optioneel: instellen van de sourceOptions voor de OpenLayers Source.
     * Dit is alleen van toepassing wanneer clusterDistance is ingesteld
     * Zie de OpenLayers documentatie voor alle opties [CLustersource](https://openlayers.org/en/latest/apidoc/module-ol_source_Cluster-Cluster.html).
     */
    sourceClusterOptions?: Partial<Options$3<Feature<Geometry>>>;
    /**
     * Optioneel: instellen van een straal in pixels rond de plek waar in de kaart
     * geklikt wordt bij getFeatureInfoOnSingleclick.
     * Met deze optie wordt het makkelijker om bijvoorbeeld op een lijn te klikken.
     */
    hitTolerance?: number;
    /**
     * Optioneel: instellen van geografische objecten (features) op deze laag,
     * zonder gebruik te maken van een (externe) url.
     */
    features?: Feature<Geometry>[];
    /**
     * Optioneel: meegeven van een OpenLayers-stijlobject of stijlfunctie aan
     * de weergegeven data.
     * Als er geen eigen stijlfunctie of stijlobjecten worden meegegeven wordt de
     * standaard OpenLayers styling gebruikt.
     */
    styleLike?: StyleLike;
    /**
     * Optioneel: instellen dat de GeoJSON objecten geclusterd weergegeven worden op de kaart.
     * De clusterDistance is de minimale afstand in pixels tussen de clusters.
     * Let op: clusteren werkt op dit moment alleen bij een GeoJSON kaartlaag met punt geometrieën,
     * maar dit kan uitgebreid worden voor andere types geometrieën.
     */
    clusterDistance?: number;
    /**
     * Optioneel: instellen van het aantal OGC API Features dat per batch (pagina) opgehaald wordt.
     * Alleen van toepassing bij het ophalen van OGC API Features.
     * Default: 100
     */
    limit?: 10 | 100 | 1000;
    /**
     * Optioneel: instellen van het maximaal aantal OCG API Features dat opgehaald wordt.
     * Alleen van toepassing bij het ophalen van OGC API Features.
     * Default: 5000
     */
    maxFeatures?: number;
    /**
     * Optioneel: instellen van extra http headers zoals bijvoorbeeld een API-key
     * bij het opvragen van een webservice.
     */
    customHeaders?: [string, string][];
}

/**
 * Opties voor het configureren van een afbeeldingslaag binnen een kaartapplicatie.
 */
interface ImageLayerOptions extends AbstractConfigurableLayerOptions {
    /**
     * De extent (bereik) van de afbeelding in kaartcoördinaten.
     * Dit is een array van vier getallen: `[minX, minY, maxX, maxY]`.
     *
     * @example
     * [0, 0, 1024, 768]
     */
    imageExtent?: [number, number, number, number];
    /**
     * Optioneel: Instellen van de layerOptions voor de OpenLayers Layer.
     * Hiermee kunnen onder andere `zIndex`, `minResolution` en `maxResolution` worden ingesteld.
     * Zie de OpenLayers documentatie voor meer informatie. [ImageLayer](https://openlayers.org/en/latest/apidoc/module-ol_layer_Image-ImageLayer.html)
     */
    layerOptions?: Options$4<ImageSource>;
    /**
     * Optioneel: Instellen van de sourceOptions voor de OpenLayers layer.
     * Hier kan onder andere de url worden ingesteld.
     * Voor alle opties zie: [ImageStatic-Static](https://openlayers.org/en/latest/apidoc/module-ol_source_ImageStatic-Static.html)
     */
    sourceOptions?: Partial<Options$5>;
}

/**
 * Opties voor het configureren van een VectorTile-laag.
 */
interface VectorTileLayerOptions extends AbstractClickableLayerOptions {
    /**
     * Optioneel: Instellen van de layerOptions voor de Openlayers Layer,
     * onder andere zIndex, minResolution en maxResolution kunnen worden ingesteld.
     * Zie Vector Tile Layer voor alle opties. [VectorTileLayer](https://openlayers.org/en/latest/apidoc/module-ol_layer_VectorTile-VectorTileLayer.html)
     */
    layerOptions?: Options$6;
    /**
     * Optioneel: Instellen van de sourceOptions voor de Openlayers Source.
     * Hier kan onder andere de url worden ingesteld.
     * Zie Vector [Tile Source](https://openlayers.org/en/latest/apidoc/module-ol_source_VectorTile-VectorTile.html) voor alle opties.
     */
    sourceOptions?: Partial<Options$7>;
    /**
     * Optioneel: Voor het meegeven van een OpenLayers-stijlobject, stijlfunctie of url
     * met json styles aan de weergegeven data. Denk hierbij aan het meegeven van kleur,
     * dikte van een strook of een eigen icoon. Voor extra info zie: [OpenLayers StyleLike](https://openlayers.org/en/latest/apidoc/module-ol_style_Style.html#~StyleLike)
     */
    style?: StyleLike | string;
    /**
     * Optioneel: Instellen van een straal in pixels rond de plek waar in de kaart
     * geklikt wordt bij getFeatureInfoOnSingleclick. Met deze optie wordt het makkelijker
     * om bijvoorbeeld op een lijn te klikken.
     */
    hitTolerance?: number;
    /**
     * Optioneel: Grootte van de tiles in pixels, default waarde is [256, 256].
     */
    tileSize?: [number, number];
    /**
     * Optioneel: Met deze optie kan je overzoom aanzetten, default waarde is false.
     * Om overzoom goed te laten werken, moet de maxzoom van de kaartlaag worden bepaald
     * (het bepalen van de minzoom is niet nodig voor overzoom). Deze maxzoom wordt
     * automatisch bepaald aan de hand van de (style)url. Wanneer de maxzoom niet is
     * ingevuld in de style json of in de metadata van de API tiles of je wilt deze
     * waarde zelf overschrijven, dan kan je deze handmatig via de maxzoom optie in de
     * sourceOptions meegeven. De overzoom werkt tot de ingestelde minResolution
     * van de kaartlaag; je kan de minResolution ook weglaten, dan wordt er automatisch
     * doorgezoomd tot het maximale zoomniveau van de kaart.
     */
    enableOverzoom?: boolean;
}

/**
 * Interface voor het configureren van een WMS-laagcomponent.
 */
interface WmsLayerOptions extends AbstractClickableLayerOptions {
    /**
     * Optioneel: Instellen van de layerOptions voor de Openlayers Layer, onder andere
     * zIndex, minResolution en maxResolution kunnen worden ingesteld. Zie (Image Layer)[https://openlayers.org/en/latest/apidoc/module-ol_layer_Image-ImageLayer.html]
     * voor alle opties van reguliere WMS-kaarten.
     * Kijk bij TileLayer wanneer de kaartlaag als tiled-WMS wordt opgehaald (tiled: true).
     */
    layerOptions?: Options$4<ImageSource$1> | Options$8<TileSource>;
    /**
     * Optioneel: Instellen van de sourceOptions voor de OpenLayers Source.
     * Hier kan onder andere de url worden ingesteld. Zie (ImageWms)[https://openlayers.org/en/latest/apidoc/module-ol_source_ImageWMS-ImageWMS.html]
     * Source voor alle opties van reguliere WMS-kaartlagen.
     */
    sourceOptions?: Partial<Options$9 | Options$a>;
    /**
     * Optioneel: Voor het aangeven van specifieke kaartlagen waarop geklikt kan worden,
     * default worden alle kaartlagen uit [layers] gebruikt.
     */
    getFeatureInfoQueryLayers?: string[];
    /**
     * Optioneel: Geeft aan of de WMS-laag als tiled moet worden opgehaald.
     */
    tiled?: boolean;
    /**
     * Optioneel: Instellen dat de WMS-capabilities worden opgehaald.
     * Standaard worden de WMS-capabilities opgehaald,
     * tenzij hier de waarde false wordt ingesteld.
     */
    getCapabilities?: boolean;
    /**
     * De naam of namen van de lagen die moeten worden weergegeven.
     * Kan een string of een array van strings zijn.
     */
    layers?: string[] | string;
    /**
     * Gutterwaarde voor de WMS-laag.
     * Wordt gebruikt om extra marge rond tiles te renderen om artefacten te voorkomen.
     */
    gutter?: number;
}

/**
 * Interface voor configuratieopties van een WMTS-laag.
 */
interface WmtsLayerOptions extends AbstractClickableLayerOptions {
    /**
     * Optioneel: Instellen van de layerOptions voor de Openlayers Layer,
     * onder andere zIndex, minResolution en maxResolution kunnen worden ingesteld.
     * Zie Tile Layer voor alle opties. [TileLayer](https://openlayers.org/en/latest/apidoc/module-ol_layer_Tile-TileLayer.html)
     */
    layerOptions?: Options$8<Source>;
    /**
     * Optioneel: Instellen van de sourceOptions voor de Openlayers Source.
     * Hier kan onder andere de url worden ingesteld.
     * Zie Wmts Source voor alle opties. [WMTS](https://openlayers.org/en/latest/apidoc/module-ol_source_WMTS-WMTS.html)
     */
    sourceOptions?: Partial<Options$b>;
    /**
     * Naam van de WMTS-laag zoals gedefinieerd in de capabilities.
     */
    layer?: string;
}

declare class CoreMapEventsService {
    private coreLoadingServiceService;
    private singleclickMap;
    private zoomendMap;
    destroyEventsForMap(mapIndex: string): void;
    emitSingleclickEventForMap(evt: MapBrowserEvent, mapIndex: string): void;
    getSingleclickObservableForMap(mapIndex: string): Observable<MapBrowserEvent>;
    destroySingleclickForMap(mapIndex: string): void;
    emitZoomendEventForMap(evt: MapEvent, mapIndex: string): void;
    getZoomendObservableForMap(mapIndex: string): Observable<MapEvent>;
    destroyZoomendForMap(mapIndex: string): void;
    getLoadingObservableForMap(mapIndex: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMapEventsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMapEventsService>;
}

declare class CoreMapService {
    private readonly GEOLOCATION_LAYER_ID;
    private readonly crsConfigService;
    private readonly coreLoadingService;
    private readonly zoomOptions;
    private readonly rotateOptions;
    private readonly attributionOptions;
    private readonly rdNewProjection;
    private readonly olMaps;
    private readonly rdNewConfig;
    private extraLayers;
    private readonly extraLayersMap;
    private readonly layerChangedSubject;
    constructor();
    getLayerChangedObservable(): Observable<LayerChangedEvent>;
    emitLayerChangedEvent(layerId: string, mapIndex: string, eventTrigger: LayerChangedEventTrigger): void;
    createAndGetMap(mapIndex?: string, minZoomLevel?: number, maxZoomLevel?: number): OlMap;
    createLayerAndAddToMap(mapIndex: string, style?: StyleLike): VectorLayer<VectorSource<Feature<Geometry>>>;
    getMap(mapIndex?: string): OlMap;
    getLayer(layerId: string, mapIndex?: string): BaseLayer | undefined;
    getExtraLayer(layer: string, mapIndex?: string): VectorLayer<VectorSource<Feature<Geometry>>> | undefined;
    checkMapIndex(mapIndex?: string): boolean;
    destroyMap(mapIndex: string): void;
    decideMapComponentEventType(mapExists: boolean, mapIndex?: string): MapComponentEvent$1;
    addFeaturesToHighlightLayer(features: Feature<Geometry>[], mapIndex: string): MapComponentEvent$1;
    clearHighlightLayer(mapIndex: string): MapComponentEvent$1;
    changeHighlightLayerStyle(styleLike: StyleLike, mapIndex: string): void;
    addFeaturesToSelectionLayer(features: Feature<Geometry>[], mapIndex: string, selectIndex?: string): MapComponentEvent$1;
    /**
     * Controleert of een feature aanwezig is in de selectionlaag.
     *
     * Een feature wordt als aanwezig beschouwd wanneer:
     * - dezelfde feature‑referentie voorkomt in de selectionlaag, of
     * - een feature met hetzelfde id voorkomt in de selectionlaag
     *
     * @param feature OpenLayers feature die gecontroleerd wordt
     * @param mapIndex Index van de kaart (default: DEFAULT_MAPINDEX)
     * @param selectIndex Optionele index van de selectie
     * @returns `true` indien de feature in de selectionlaag zit, anders `false`
     */
    isFeatureInSelectionLayer(feature: Feature<Geometry>, mapIndex?: string, selectIndex?: string): boolean;
    clearSelectionLayer(mapIndex: string, selectIndex?: string): MapComponentEvent$1;
    changeSelectionLayerStyle(styleLike: StyleLike | null, mapIndex: string, selectIndex?: string): void;
    changeLayerStyle(styleLike: StyleLike | null, mapIndex: string, layername: string, selectIndex?: string): void;
    setExtraLayers(layers: string[]): void;
    private createGeolocationLayer;
    private createNewOlMap;
    addSelectLayer(mapIndex: string, selectIndex: string): void;
    removeSelectLayer(mapIndex: string, selectIndex: string): void;
    private readdHighlightLayer;
    private getControls;
    private clone;
    private getHighlightLayerSource;
    private getSelectionLayerSource;
    private createExtraLayers;
    private setDefaultHighlightLayerStyle;
    private setDefaultSelectionLayerStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMapService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMapService>;
}

declare class CoreSelectionService {
    static readonly messageClearSelection = "Selectie is gewist";
    static readonly messageMapClicked = "Er is geklikt in de kaart en de feature info wordt opgehaald.";
    static readonly messageSelectionUpdated = "Nieuwe feature info van een kaartlaag toegevoegd aan de selectie.";
    static readonly messageCoordinateDoesNotMatch: string;
    private readonly subjectSelectEvents;
    private readonly activeSelectInteractions;
    private readonly activeMapClickEventsKeys;
    private readonly activeSelectEventsKeys;
    private readonly GGC_LAYER_IDS;
    private readonly GGC_SELECT_MODE;
    private readonly ggcMapService;
    private readonly coreMapService;
    constructor();
    getObservableForMap(mapIndex: string, selectIndex?: string): Observable<MapComponentEvent$1>;
    startSelect(options: SelectOptions, mapIndex: string, selectIndex: string | undefined): void;
    stopSelect(selectIndex: string): void;
    clearSelection(mapIndex: string, selectIndex?: string): void;
    /**
     * Verwijdert alle selecties voor alle actieve select interactions
     * die gekoppeld zijn aan de opgegeven mapIndex.
     *
     * @param mapIndex De kaartindex waarvoor alle selecties worden gewist.
     */
    clearAllSelectionsForMapIndex(mapIndex: string): void;
    setSelection(features: Feature<Geometry>[], selectIndex: string): void;
    getCurrentSelection(selectIndex: string): Feature[];
    handleFeatureInfoForLayer(mapIndex: string, features: Feature<Geometry>[], layerId: string): void;
    private getActiveSelectInteraction;
    /**
     * Maakt een filterfunctie voor de OpenLayers Select‑interaction.
     *
     * De filter:
     * - controleert of de feature afkomstig is van een geldige layer
     * - accepteert alle layers indien `layerIds` undefined is
     * - voegt altijd de property `layer_id` toe aan de feature
     *
     * De `layer_id` wordt gelezen uit de layer property `ggc-layer-id`.
     *
     * @param layerIds Optionele lijst met toegestane layer‑IDs
     * @returns Filterfunctie voor Select‑interaction
     */
    private createSelectionFilterFunction;
    private connectSelectEvents;
    private emitEvent;
    private emitSelectionUpdatedEvent;
    private updateSelectionLayer;
    private handleNewFeaturesForSelection;
    private toggleFeatures;
    private buildFeatureCollectionForCoordinateFromFeatures;
    /**
     * Build a layerId to features mapping
     * @param features
     * @private
     */
    private buildLayerFeatureMap;
    private addFeaturesToCollection;
    private getMapIndexFromSelectIndex;
    private getAllActiveSelectIndicesOnMapIndex;
    private getEqualFeatureFromCollection;
    private areFeaturesEqual;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreSelectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreSelectionService>;
}

declare class AbstractBaseLayerComponent<T extends Layer> implements OnInit, OnDestroy {
    protected mapIndex: string;
    protected coreMapService: CoreMapService;
    protected coreSelectionService: CoreSelectionService;
    protected crsConfig: GgcCrsConfigService;
    protected map: OlMap;
    protected olLayer: T;
    protected layerOptions: Options$c;
    protected rdNewConfig: CrsConfig;
    protected options?: AbstractBaseLayerOptions;
    ngOnInit(): void;
    ngOnDestroy(): void;
    disable(): void;
    enable(): void;
    getLayerId(): string;
    protected setLayer(layer: T): void;
    private generateLayerId;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractBaseLayerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AbstractBaseLayerComponent<any>, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class AbstractConfigurableLayerComponent<T> extends AbstractBaseLayerComponent<any> implements OnInit, OnDestroy {
    events: EventEmitter<MapComponentEvent$1>;
    protected attributions: string | undefined;
    protected layerName: string | undefined;
    protected options?: AbstractConfigurableLayerOptions;
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected setLayer(layer: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractConfigurableLayerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AbstractConfigurableLayerComponent<any>, "ggc-abstract-configurable-layer", never, {}, { "events": "events"; }, never, never, true, never>;
}

declare class AbstractClickableLayerComponent<T> extends AbstractConfigurableLayerComponent<any> implements OnInit, OnDestroy {
    protected maxFeaturesOnSingleclick: number;
    protected options?: AbstractClickableLayerOptions;
    protected mapEventsService: CoreMapEventsService;
    protected singleclick: Subscription;
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected getFeatureInfo(_event: MapBrowserEvent$1): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractClickableLayerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AbstractClickableLayerComponent<any>, "ng-component", never, {}, {}, never, never, true, never>;
}

/**
 * Door `<ggc-wms-layer></ggc-wms-layer>` op te nemen in de HTML kunnen WMS-kaarten
 * worden toegevoegd, bijvoorbeeld afkomstig van PDOK. Binnen deze tags kunnen
 * onder andere de WMS url, de gewenste kaartlagen en de minimale- en maximale
 * resolutie worden ingesteld en events worden opgevangen. Ook kan ingesteld worden
 * dat de WMS-kaart als tiled-WMS wordt weergegeven.
 *
 * @example
 * <ggc-wms-layer [options]="wmsLayerOptions"></ggc-wms-layer>
 */
declare class GgcWmsLayerComponent extends AbstractClickableLayerComponent<ImageLayer<ImageSource$2> | TileLayer<TileSource$1>> implements OnInit, OnDestroy {
    /** Opties voor de WMS-laag. */
    options?: WmsLayerOptions;
    /** Interne referentie naar de WMS-bron. */
    private wmsSource;
    private readonly capabilitiesService;
    private readonly httpClient;
    /** Initialiseert de WMS-laag en haalt optioneel capabilities op. */
    ngOnInit(): void;
    /**
     * Voert een `GetFeatureInfo` request uit op basis van een klik op de kaart.
     * @param evt Het MapBrowserEvent met kliklocatie.
     */
    getFeatureInfo(evt: MapBrowserEvent): void;
    /** Verwijdert de laag en voert opruimacties uit. */
    ngOnDestroy(): void;
    /**
     * Past meerdere stijlen toe op de WMS-laag.
     * @param styles Een array van stijlstrings.
     */
    setStyles(styles: string[]): void;
    /**
     * Past een specifieke stijl toe op een specifieke sublaag.
     * @param style De stijlnaam.
     * @param layerName De naam van de sublaag waarop de stijl moet worden toegepast.
     */
    setStyle(style: string, layerName: string): void;
    enable(): void;
    disable(): void;
    private subscribeOnClickEvent;
    private unsubscribeOnClickEvent;
    /** Werkt de lokale sourceOptions.params bij op basis van de WMS-bron. */
    private updateLocalSourceOptionsFromWmsSource;
    /**
     * Emit een feature info event met de opgehaalde features.
     * @param features De gevonden features.
     * @param coordinate De kliklocatie.
     * @param message Optioneel bericht.
     */
    private emitFeatureInfoEvent;
    /**
     * Voegt DPI-gerelateerde parameters toe aan de WMS-request.
     * @param params De bestaande WMS-parameters.
     * @param DEVICE_PIXEL_RATIO De pixelratio van het apparaat.
     */
    private addDpiToParams;
    /**
     * Zet alle keys van de WMS-parameters om naar hoofdletters.
     * @param params De originele parameters.
     * @returns De aangepaste parameters met hoofdletter-keys.
     */
    private makeParamsKeysUppercase;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcWmsLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcWmsLayerComponent, "ggc-wms-layer", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Door `<ggc-wmts-layer></ggc-wmts-layer>` op te nemen in de HTML kunnen WMTS-kaarten
 * worden toegevoegd, bijvoorbeeld afkomstig van PDOK. Binnen deze tags kunnen onder
 * andere de WMTS url, de gewenste kaartlaag en de minimale- en maximale resolutie
 * worden ingesteld.
 *
 * @example
 * <ggc-wmts-layer [options]="wmtsOptions"></ggc-wmts-layer>
 */
declare class GgcWmtsLayerComponent extends AbstractClickableLayerComponent<TileLayer<TileSource$1>> implements OnInit, OnDestroy {
    /**
     * Opties voor het configureren van de WMTS-laag.
     */
    options?: WmtsLayerOptions;
    /**
     * Interne instantie van de WMTS source.
     */
    private wmtsSource;
    /**
     * Subscription voor het ophalen van capabilities.
     */
    private capabilitiesSubscription;
    /**
     * Opgehaalde capabilities van de WMTS-laag.
     */
    private capabilities;
    /**
     * Injectie van de CoreWmsWmtsCapabilitiesService.
     */
    private readonly capabilitiesService;
    /**
     * Angular lifecycle hook die wordt aangeroepen bij initialisatie van de component.
     * Haalt WMTS-capabilities op en configureert de laag op basis van de opgehaalde gegevens.
     */
    ngOnInit(): void;
    /**
     * Verwerkt een klik op de kaart en haalt feature info op via WMTS indien beschikbaar.
     *
     * @param evt - Het MapBrowserEvent dat de klik representeert.
     */
    getFeatureInfo(evt: MapBrowserEvent): void;
    /**
     * Emit een event met de opgehaalde features en coördinaten.
     *
     * @param features - De gevonden features.
     * @param coordinate - De locatie van de klik.
     */
    emitFeatureInfoEvent(features: Feature<Geometry>[], coordinate: Coordinate): void;
    /**
     * Angular lifecycle hook die wordt aangeroepen bij het vernietigen van de component.
     * Zorgt voor het opruimen van subscriptions.
     */
    ngOnDestroy(): void;
    enable(): void;
    disable(): void;
    private subscribeOnClickEvent;
    private unsubscribeOnClickEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcWmtsLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcWmtsLayerComponent, "ggc-wmts-layer", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Door `<ggc-image-layer></ggc-image-layer>` op te nemen in de HTML kan een image
 * worden weergegeven als kaartlaag.
 *
 * @example
 * import { ImageLayerOptions } from "@kadaster/ggc-map";
 *
 * const imageLayerOptions: ImageLayerOptions = {
 *     url: "/assets/image1.png",
 *     zIndex: 4,
 *     attributions: "Attributie voor Image",
 *     mapIndex: "een",
 *     layerName: "Image kaartlaag"
 * };
 *
 * <ggc-image-layer [options]="imageLayerOptions"> </ggc-image-layer>
 */
declare class GgcImageLayerComponent extends AbstractConfigurableLayerComponent<ImageLayer<ImageSource$2>> implements OnInit, OnDestroy {
    /**
     * Opties voor het configureren van de afbeeldingslaag.
     * Bevat instellingen voor de bron en de laag zelf.
     */
    options?: ImageLayerOptions;
    private imageSource;
    /**
     * Initialiseert de afbeeldingslaag bij het laden van de component.
     * De afbeelding wordt geladen via ImageStatic en gekoppeld aan een ImageLayer.
     */
    ngOnInit(): void;
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcImageLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcImageLayerComponent, "ggc-image-layer", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Door `<ggc-geojson-layer></ggc-geojson-layer>` op te nemen in de HTML kunnen
 * kaartlagen worden getoond die GeoJSON data bevatten. Dit kan bijvoorbeeld een
 * losse file zijn die GeoJSON-objecten bevat of een WFS-kaartlaag die JSON als
 * outputformat heeft. Bij deze kaartlaag is de variabele url optioneel.
 *
 * @example
 * import { GeojsonLayerOptions } from "@kadaster/ggc-map";
 * import Style from "ol/style/Style";
 *
 * const stylePointObjectShapeTriangle = new Style();
 *
 * const geojsonLayerOptions: GeojsonLayerOptions = {
 *     url: "/assets/GeoJSONTest.json",
 *     minResolution: 100,
 *     maxResolution: 861,
 *     zIndex: 3,
 *     getFeatureInfoOnSingleclick: true,
 *     maxFeaturesOnSingleclick: 15,
 *     hitTolerance: 6,
 *     styleLike: stylePointObjectShapeTriangle,
 *     attributions: "Attributie voor deze GeoJSON kaartlaag",
 *     mapIndex: "geojson",
 *     layerName: "GeoJSON kaartlaag"
 * };
 *
 * <ggc-geojson-layer [options]="geojsonLayerOptions" (events)="logGetFeatureInfoEvents($event)">
 *   </ggc-geojson-layer>
 *
 */
declare class GgcGeojsonLayerComponent extends AbstractClickableLayerComponent<VectorLayer<VectorSource<Feature<Geometry>>>> implements OnInit, OnDestroy, OnChanges {
    /**
     * Opties voor het configureren van de GeoJSON-laag.
     * Bevat instellingen voor bron, stijl, clustering en features.
     */
    options?: GeojsonLayerOptions;
    private vectorSource;
    private clusterSource;
    private foundFeatures;
    private geoJsonFormat;
    private readonly ggcOgcApiFeaturesService;
    /**
     * Initialiseert de GeoJSON-laag bij het laden van de component.
     * Bouwt de vectorbron en eventueel een clusterbron op basis van de opgegeven opties.
     */
    ngOnInit(): void;
    /**
     * Reageert op wijzigingen in de input properties.
     * Ondersteunt dynamische updates van URL en features.
     *
     * @param changes - De gewijzigde inputs.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Verwerkt een klik op de kaart en haalt relevante features op.
     * Stuurt een MapComponentEvent met de gevonden features.
     *
     * @param event - Het MapBrowserEvent van de klik.
     */
    getFeatureInfo(event: MapBrowserEvent): void;
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy(): void;
    /**
     * Update de URL van de vectorbron en forceert een refresh.
     *
     * @param url - De nieuwe GeoJSON URL.
     */
    private updateUrl;
    /**
     * Update de features van de vectorbron.
     *
     * @param features - De nieuwe lijst van Feature objecten.
     */
    private updateFeatures;
    /**
     * Beperkt het aantal gevonden features bij een klik.
     *
     * @param feature - Het gevonden FeatureLike object.
     */
    private limitFeatures;
    /**
     * Filtert lagen om te bepalen of ze relevant zijn voor feature info.
     *
     * @param layerCandidate - De kandidaat BaseLayer.
     * @returns `true` als de laag overeenkomt met deze component.
     */
    private decideLayerCandidate;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcGeojsonLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcGeojsonLayerComponent, "ggc-geojson-layer", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

declare class GgcVectorTileLayerComponent extends AbstractClickableLayerComponent<VectorTileLayer> implements OnChanges, OnDestroy, OnInit {
    /**
     * Opties voor configuratie van de vector tile laag.
     * Zie VectorTileLayerOptions voor beschikbare instellingen.
     */
    options?: VectorTileLayerOptions;
    /**
     * Angular HttpClient voor het ophalen van externe JSON-bestanden zoals stijl- of tile-informatie.
     */
    private readonly httpClient;
    /**
     * De bron van de vector tile laag, geconfigureerd met tileGrid en andere instellingen.
     * Zie VectorTileSource.
     */
    private vectorTileSource;
    /**
     * Interne lijst van gevonden features bij een klik op de kaart.
     * Wordt gebruikt voor het genereren van feature info events.
     */
    private foundFeatures;
    /**
     * Angular lifecycle hook die wordt aangeroepen bij initialisatie van de component.
     * Initialiseert de vector tile source en laag.
     */
    ngOnInit(): void;
    /**
     * Maakt een nieuwe VectorTileLayer instantie met configuratieopties.
     * Wordt gebruikt als renderlaag in de kaart.
     */
    private createVectorTileLayer;
    /**
     * Genereert een TileGrid op basis van resoluties en extent.
     * Ondersteunt overzoom indien geactiveerd.
     */
    private createTileGrid;
    /**
     * Update de vector tile source van de laag indien overzoom is ingeschakeld.
     * Wordt aangeroepen bij stijlwijzigingen.
     */
    private updateOverzoomSettings;
    /**
     * Maakt een nieuwe VectorTileSource op basis van configuratieopties.
     * Ondersteunt attributies, URL en tileGrid.
     */
    private createVectorTileSource;
    /**
     * Genereert een lijst van resoluties voor overzoom op basis van maxZoom.
     * Filtert resoluties lager dan de minimale resolutie.
     */
    private createOverzoomResolutions;
    /**
     * Bepaalt de maximale zoomwaarde uit configuratie, tile URL of stijl URL.
     * Wordt gebruikt voor overzoom functionaliteit.
     */
    private getMaxZoom;
    /**
     * Haalt de maximale zoomwaarde op uit een tile URL via een tilejson request.
     *
     * @param tileUrl - De URL van de tile endpoint (bijv. met /{z}/{x}/{y}).
     * @returns De maximale zoomwaarde indien beschikbaar, anders undefined.
     */
    private getMaxZoomFromUrl;
    /**
     * Haalt de minimale maxzoom op uit alle bronnen in een Mapbox stijlbestand.
     *
     * @param styleUrl - De URL naar het Mapbox stijlbestand.
     * @returns De laagste maxzoom waarde van alle bronnen indien beschikbaar, anders undefined.
     */
    private getMaxZoomFromStyleUrl;
    /**
     * Voert een HTTP GET request uit naar een URL en retourneert de JSON response.
     * Wordt gebruikt voor tilejson en stijlbestanden.
     */
    private getJsonFromUrl;
    /**
     * Filterfunctie om te bepalen of een laag overeenkomt met de huidige OpenLayers laag.
     * Wordt gebruikt bij feature selectie.
     */
    private decideLayerCandidate;
    /**
     * Verwerkt een klik op de kaart en haalt feature informatie op.
     * Emit een MapComponentEvent met gevonden features.
     */
    getFeatureInfo(event: MapBrowserEvent): void;
    /**
     * Beperkt het aantal geselecteerde features bij een klik tot een maximum.
     * Voegt geldige features toe aan de interne lijst.
     */
    private limitFeatures;
    /**
     * Laadt een Mapbox stijlbestand en past de stijl toe op de vector tile laag.
     * Ondersteunt meerdere bronnen in het stijlbestand.
     */
    private loadStyle;
    /**
     * Past de stijl toe op de vector tile layer. Ondersteunt zowel string URL als OL stijlobject.
     *
     * @param layer - De VectorTileLayer waarop de stijl wordt toegepast.
     * @param updateOverzoomSettings - Of overzoom instellingen moeten worden bijgewerkt.
     */
    private setStyle;
    /**
     * Angular lifecycle hook die wordt aangeroepen bij het vernietigen van de component.
     * Roept de parent destructor aan.
     */
    ngOnDestroy(): void;
    /**
     * Angular lifecycle hook die wordt aangeroepen bij wijzigingen in input properties.
     * Past stijl aan indien opties of stijl zijn gewijzigd.
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcVectorTileLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcVectorTileLayerComponent, "ggc-vector-tile-layer", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Door `<ggc-layer-brt-achtergrondkaart></ggc-layer-brt-achtergrondkaart>` op te
 * nemen in de HTML wordt de brt achtergrondkaart toegevoegd aan de kaart.
 *
 * @example
 * <ggc-layer-brt-achtergrondkaart [mapIndex]="'kaart1'"></ggc-layer-brt-achtergrondkaart>
 */
declare class GgcLayerBrtAchtergrondkaartComponent extends AbstractBaseLayerComponent<any> implements OnInit, OnDestroy {
    /**
     * Naam van de kaart waarin deze laag wordt geplaatst.
     */
    mapIndex: string;
    /**
     * Initialisatie van de WMTS-laag bij het laden van de component.
     * De BRT Achtergrondkaart wordt geconfigureerd met een tileGrid op basis van RD-coördinaten.
     */
    ngOnInit(): void;
    /**
     * Opruimen van resources bij het vernietigen van de component.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcLayerBrtAchtergrondkaartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcLayerBrtAchtergrondkaartComponent, "ggc-layer-brt-achtergrondkaart", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Service voor het ophalen en verwerken van WMS/WMTS en OGCAPI capabilities.
 */
declare class GgcCapabilitiesService {
    private readonly wmsWmtsCapabilitiesService;
    private readonly ogcApiCapabilitiesService;
    /**
     * Geeft een CapabilitiesService Object terug voor verschillende service types
     * @param baseUrl - De URL van de capabilities endpoint van de WMS, WMTS
     * of landingspagina van een OGCAPI.
     * @param serviceType - het type van de service dit kan WMS, WMTS of OGCAPI zijn
     * @returns Observable van een CapabilitiesService Object
     */
    getServiceFromCapabilities(baseUrl: string, serviceType: "WMS" | "WMTS" | "OGCAPI"): Observable<ServiceCapabilities | undefined>;
    /**
     * Geeft een array van CapabilitiesServiceLayerStyle terug voor een bepaalde
     * laag binnen een service.
     * @param baseUrl - De URL van de capabilities endpoint van de WMS, WMTS
     * of landingspagina van een OGCAPI.
     * @param serviceType - het type van de service dit kan WMS, WMTS of OGCAPI zijn
     * @param layerName - de naam van een laag of tileset
     * @returns Observable van een lijst van CapabilitiesServiceLayerStyle Objecten
     */
    getServiceLayerStyles(baseUrl: string, serviceType: "WMS" | "WMTS" | "OGCAPI", layerName: string): Observable<CapabilitiesServiceLayerStyle[]>;
    /**
     * Haalt de capabilities op voor een gegeven WMS of WMTS service.
     * @param baseUrl - De URL van de capabilities endpoint.
     * @param service - Het type service: `"WMTS"` of `"WMS"`.
     * @returns Observable met de capabilities data (ol capabilities).
     */
    getCapabilities(baseUrl: string, service: "WMTS" | "WMS"): Observable<Record<string, any> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcCapabilitiesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcCapabilitiesService>;
}
/**
 * ServiceCapabilities object bevat de layers van een WMS, WMTS of OGCAPI service.
 */
type ServiceCapabilities = {
    /** Titel van de service */
    title?: string;
    /** Abstract, korte omschrijving van de service */
    abstract?: string;
    /** URL van de service */
    url: string;
    /** Type van de service: WMS, WMTS of OGCAPI */
    type: string;
    /** Layers van de service */
    layers: CapabilitiesServiceLayer[];
};
/**
 * CapabilitiesServiceLayer object is een enkele laag van een WMS, WMTS of
 * OGCAPI service en bevat één of meerdere Styles.
 */
type CapabilitiesServiceLayer = {
    /** Naam van de layer */
    name: string;
    /** Titel van de layer */
    title: string;
    /** URL van de layer (optioneel)*/
    url?: string;
    /** Minimale resolutie van de layer (optioneel)*/
    minResolution?: string;
    /** Maximale resolutie van de layer (optioneel)*/
    maxResolution?: string;
    /** Stijlen van de layer */
    styles: CapabilitiesServiceLayerStyle[];
};
/**
 * CapabilitiesServiceLayerStyle object bevat de stijl die wordt getoond voor een
 * OGCAPI (vector)tileset of voor WMS en WMTS de URL van de legenda (bij de stijl)
 * als deze wordt aangeboden.
 */
type CapabilitiesServiceLayerStyle = {
    /** Naam van de stijl */
    name: string;
    /** Titel van de stijl (optioneel) */
    title?: string;
    /** URL van de legenda afbeelding (optioneel) */
    legendURL: string;
};

/**
 * Component die een loader toont op basis van laadstatus
 * van een specifieke kaart.
 *
 * De loader luistert naar loading-events van {@link CoreMapEventsService}
 * en wordt automatisch bijgewerkt zodra de kaart start of stopt
 * met laden.
 *
 * @example
 * <ggc-loader [mapIndex]="'default'"></ggc-loader>
 */
declare class GgcLoaderComponent implements OnDestroy {
    /**
     * Geeft aan of de kaart momenteel aan het laden is.
     * Wordt gebruikt door de template om de loader te tonen of verbergen.
     */
    protected isLoading: boolean;
    private mapEventsService;
    private loadEvents$;
    private _mapIndex;
    /**
     * Index van de kaart waarvoor laad-events worden gevolgd.
     *
     * Bij wijziging wordt de bestaande subscription gestopt
     * en een nieuwe subscription opgezet voor de opgegeven kaart.
     */
    set mapIndex(value: string);
    /**
     * Lifecycle hook die wordt aangeroepen wanneer
     * het component wordt vernietigd.
     *
     * Zorgt ervoor dat alle subscriptions correct worden opgeruimd.
     */
    ngOnDestroy(): void;
    /**
     * Abonneert zich op laad-events van de opgegeven kaart
     * en actualiseert de loader-status.
     */
    private subscribe;
    /**
     * Beëindigt de actieve subscription op laad-events,
     * indien aanwezig.
     */
    private unsubscribe;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcLoaderComponent, "ggc-loader", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Containercomponent voor het tonen van detailinformatie
 * gerelateerd aan de kaart.
 *
 * Deze component fungeert als structurele wrapper en bevat
 * zelf geen logica. De inhoud wordt bepaald door de bijbehorende
 * template en eventueel ingesloten child‑componenten.
 *
 * @example
 * <ggc-map-details-container>
 *   <ggc-feature-info></ggc-feature-info>
 *   <ggc-selection-details></ggc-selection-details>
 * </ggc-map-details-container>
 */
declare class GgcMapDetailsContainerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcMapDetailsContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcMapDetailsContainerComponent, "ggc-map-details-container", never, {}, {}, never, ["*"], true, never>;
}

declare class GgcMousePositionComponent implements OnInit, OnDestroy {
    /**
     * Optionele injectie van de MapDetailsContainer.
     * Indien aanwezig wordt de mouse position daarin gerenderd.
     */
    mapDetailsContainer: GgcMapDetailsContainerComponent | null;
    /** Aantal decimalen voor coördinaten */
    decimalDigits: number;
    /** Index van de kaart waarop de mouse position wordt toegepast */
    mapIndex: string;
    /** Placeholder tekst wanneer geen coördinaat beschikbaar is */
    placeholder: string;
    /** Doelprojectie waarin de coördinaten worden getoond */
    projection: string;
    private readonly coreMapService;
    private readonly crsConfigService;
    private _format;
    private map;
    private mode;
    private mousePositionControl;
    /**
     * Referentie naar het HTML-element
     * waarin de mouse position wordt gerenderd.
     */
    private readonly ggcMousePosition;
    /** Geeft het huidige ingestelde coördinaatformaat terug */
    get format(): string | CoordinateFormat;
    set format(value: string | CoordinateFormat);
    /** Initialiseert de MousePosition control en voegt deze toe aan de kaart */
    ngOnInit(): void;
    /** Verwijdert de MousePosition control bij component destruction */
    ngOnDestroy(): void;
    /**
     * Maakt de configuratie-opties aan voor de MousePosition control.
     */
    createMousePositionOptions(): Options$d;
    /**
     * Koppelt de coördinaatformatter aan de MousePosition control.
     */
    private setCoordinateFormatOnMousePositionControl;
    /**
     * Converteert en formatteert een coördinaat
     * naar een string geschikt voor weergave.
     */
    private createCoordinateFormat;
    /**
     * Voegt de MousePosition control toe aan de actuele kaart.
     */
    private setMousePositionControlOnMap;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcMousePositionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcMousePositionComponent, "ggc-mouse-position", never, { "decimalDigits": { "alias": "decimalDigits"; "required": false; }; "mapIndex": { "alias": "mapIndex"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "projection": { "alias": "projection"; "required": false; }; "format": { "alias": "format"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Component dat het actuele schaalgetal (scale denominator)
 * van een OpenLayers‑kaart berekent en beschikbaar stelt.
 *
 * Het schaalgetal wordt opnieuw berekend bij iedere `zoomend`‑event
 * van de gekoppelde kaart.
 *
 * Voorbeeld: 1 : 25.000
 */
declare class GgcScaleDenominatorComponent implements OnInit, OnDestroy {
    /**
     * Index van de kaart waarvoor het schaalgetal
     * berekend moet worden.
     */
    mapIndex: string;
    protected currentScaleDenominator: number | undefined;
    private readonly coreMapService;
    private readonly mapEventsService;
    private readonly INCHES_PER_METER;
    private readonly POINTS_PER_INCH;
    private map;
    private zoomendSubscription;
    /**
     * Initialiseert het component:
     * - haalt de kaart op
     * - abonneert zich op zoom-events
     * - triggert herberekening van het schaalgetal
     */
    ngOnInit(): void;
    /**
     * Berekent het schaalgetal op basis van de huidige kaartresolutie.
     *
     * Formule:
     * schaal = resolutie (m/px) × inches/m × pixels/inch
     *
     * De PPI‑waarde is afgeleid van:
     * Nederlandse richtlijn tiling (bijlage B, Geonovum).
     */
    private calculateScaleDenominator;
    /**
     * Ruimt resources op door de subscription
     * op het zoom-event te beëindigen.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcScaleDenominatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcScaleDenominatorComponent, "ggc-scale-denominator", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Component dat een OpenLayers ScaleLine (schaalbalk) toevoegt aan een kaart.
 *
 * De schaal kan:
 * - standaard op de kaart worden getoond
 * - of binnen een MapDetailsContainerComponent, indien deze als parent aanwezig is.
 */
declare class GgcScaleLineComponent implements OnInit, OnDestroy {
    mapDetailsContainer: GgcMapDetailsContainerComponent | null;
    /**
     * Index van de kaart waaraan de schaalbalk
     * moet worden toegevoegd.
     */
    mapIndex: string;
    /**
     * Eenheden waarin de schaal wordt weergegeven.
     * Standaard: metrisch.
     */
    units: Units$1;
    /**
     * Referentie naar het HTML‑element
     * dat als target dient voor de ScaleLine.
     */
    ggcScaleLine: ElementRef;
    private map;
    private scaleControl;
    private readonly coreMapService;
    /**
     * Initialiseert de ScaleLine:
     * - maakt de control aan
     * - haalt de kaart op
     * - voegt de control toe aan de kaart
     */
    ngOnInit(): void;
    /**
     * Maakt de configuratie‑opties aan voor de ScaleLine.
     *
     * Wanneer een MapDetailsContainer aanwezig is,
     * wordt het target gezet op het bijbehorende
     * native DOM‑element.
     */
    createScaleLineOptions(): Options$e;
    /**
     * Verwijdert de ScaleLine control
     * van de kaart bij het vernietigen van het component.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcScaleLineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcScaleLineComponent, "ggc-scale-line", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; "units": { "alias": "units"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Component dat het actuele zoomniveau van een OpenLayers‑kaart weergeeft.
 *
 * Het zoomniveau wordt bijgewerkt bij ieder`zoomend`‑event van
 * de gekoppelde kaart en afgerond op twee decimalen.
 */
declare class GgcZoomLevelComponent implements OnInit, OnDestroy {
    /**
     * Index van de kaart waarvan het zoomniveau
     * wordt weergegeven.
     */
    mapIndex: string;
    protected zoomLevel: number | undefined;
    private map;
    private zoomendSubscription;
    private readonly coreMapService;
    private readonly mapEventsService;
    /**
     * Initialiseert het component:
     * - haalt de kaart op aan de hand van de mapIndex
     * - abonneert zich op zoom-events
     * - werkt het zoomniveau bij bij iedere zoomwijziging
     */
    ngOnInit(): void;
    /**
     * Leest het huidige zoomniveau uit de kaart
     * en rondt dit af op twee decimalen.
     */
    private getZoomLevel;
    /**
     * Ruimt resources op door de subscription
     * op het zoom-event te beëindigen.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcZoomLevelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GgcZoomLevelComponent, "ggc-zoom-level", never, { "mapIndex": { "alias": "mapIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Pipe voor het formatteren van coördinaten naar een leesbare string.
 *
 * De pipe:
 * - formatteert x- en y‑waarden met een vast aantal decimalen
 * - gebruikt de Nederlandse locale (`nl-NL`)
 * - ondersteunt een configureerbaar formaat met placeholders `{x}` en `{y}`
 *
 * Voorbeeld output:
 * `RD: x = 123456.78 m; y = 456789.12 m`
 */
declare class CoordinateFormatPipe implements PipeTransform {
    /**
     * Transformeert een coördinaat naar een geformatteerde string.
     *
     * @param coord Coördinaat in de vorm `[x, y]`
     * @param decimals Aantal decimalen voor de coördinaatwaarden (default: 2)
     * @param format Formaatstring met `{x}` en `{y}` placeholders
     *
     * @returns De geformatteerde coördinaatstring of een lege string
     * wanneer de coördinaat niet is opgegeven.
     *
     * @example
     * ```html
     * {{ coord | coordinateFormat:2:'RD: x = {x} m; y = {y} m' }}
     * ```
     */
    transform(coord: number[], decimals?: number, format?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoordinateFormatPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CoordinateFormatPipe, "coordinateFormat", true>;
}

/**
 * Centrale service voor het beheren van kaartlagen binnen GGC.
 *
 * Verantwoordelijkheden:
 * - Laden en configureren van webservices en lagen
 * - Dynamisch toevoegen/verwijderen van kaartlagen
 * - Synchroniseren van layer‑wijzigingen en legenda‑events
 * - Bieden van query‑API’s voor zichtbaarheid, status en metadata
 *
 * Deze service fungeert als orchestrator tussen:
 * - configuratie (Webservice / LayerOptions)
 * - OpenLayers Map
 * - UI‑componenten (legenda, toggles)
 */
declare class GgcLayerService {
    private readonly mapService;
    private readonly appRef;
    private readonly layerChangedSubject;
    private readonly legendAddedSubject;
    private readonly legendRemovedSubject;
    private readonly mapConfigurations;
    private readonly mapLayerComponents;
    /**
     * Initialiseert de service en luistert naar
     * layer changes vanuit de GgcMapService.
     */
    constructor();
    /**
     * Observable voor layer change events.
     */
    getLayerChangedObservable(): Observable<LayerChangedEvent>;
    /**
     * Observable die wordt getriggerd
     * wanneer een legenda wordt toegevoegd.
     */
    getLegendAddedObservable(): Observable<LegendAddedEvent>;
    /**
     * Observable die wordt getriggerd
     * wanneer een legenda wordt verwijderd.
     */
    getLegendRemovedObservable(): Observable<LegendRemovedEvent>;
    /**
     * Geeft alle actieve legenda‑items terug voor de opgegeven kaart.
     */
    getCurrentActiveLegends(mapIndex: string): LayerLegend[];
    /**
     * Laadt een lijst van webservices
     * en voegt hun zichtbare lagen toe aan de kaart.
     */
    loadWebservices(services: Webservice[], mapIndex: string): void;
    /**
     * Voegt een BRT achtergrondkaart toe aan de kaart.
     */
    addBrtAchtergrondkaartLayer(layerOptions: AbstractConfigurableLayerOptions): string | undefined;
    /**
     * Voegt een laag toe aan de kaart op basis van het webservice‑type.
     */
    addLayer(layerOptions: AbstractConfigurableLayerOptions, webserviceType: Webservice2DType): string | undefined;
    /**
     * Voegt een geojson laag toe aan de kaart.
     */
    addGeojsonLayer(layerOptions: GeojsonLayerOptions): string | undefined;
    /**
     * Voegt een image laag toe aan de kaart.
     */
    addImageLayer(layerOptions: ImageLayerOptions): string | undefined;
    /**
     * Voegt een vector tile laag toe aan de kaart.
     */
    addVectorTileLayer(layerOptions: VectorTileLayerOptions): string | undefined;
    /**
     * Voegt een wms laag toe aan de kaart.
     */
    addWmsLayer(layerOptions: WmsLayerOptions): string | undefined;
    /**
     * Voegt een wmts laag toe aan de kaart.
     */
    addWmtsLayer(layerOptions: WmtsLayerOptions): string | undefined;
    /**
     * Verwijdert een laag van de kaart en triggert een layer removed event.
     * Als er een selectie actief is in de SelectionService, wordt deze ook leeggehaald.
     */
    removeLayer(mapIndex: string, layerId: string): void;
    /**
     * Vraagt een laag op van de kaart.
     */
    getLayer(layerId: string, mapIndex?: string): BaseLayer | undefined;
    /**
     * Geeft de titel van een laag terug op basis van de configuratie.
     */
    getTitle(layerId: string, mapIndex?: string): string | undefined;
    /**
     * Geeft de legenda‑index van een laag terug.
     *
     * De legenda‑index bepaalt de volgorde waarin legenda‑items
     * worden weergegeven in de gebruikersinterface.
     */
    getLegendIndex(layerId: string, mapIndex?: string): number | undefined;
    /**
     * Controleert of een laag zichtbaar is.
     */
    isVisible(layerId: string, mapIndex?: string): boolean;
    /**
     * Wisselt de zichtbaarheid van een laag.
     */
    toggleVisibility(layerId: string, mapIndex?: string): boolean;
    /**
     * Bepaalt of een laag momenteel *enabled* is op basis van resolutie.
     *
     * Een laag wordt als enabled beschouwd wanneer de huidige kaartresolutie
     * binnen de minimale en maximale resolutiegrenzen van de laag valt.
     *
     * De resolutiegrenzen worden:
     * - bij voorkeur gehaald uit de actieve OpenLayers layer
     * - anders uit de laagconfiguratie
     */
    getEnabled(layerId: string, mapIndex?: string): boolean | undefined;
    /**
     * Zet de zichtbaarheid van meerdere lagen tegelijkertijd.
     *
     * Per laag wordt gecontroleerd of:
     * - deze toegevoegd moet worden (visible = true)
     * - of verwijderd moet worden (visible = false)
     *
     * De methode is idempotent: er worden geen dubbele add/remove acties uitgevoerd.
     */
    setVisibilityLayers(layerIds: string[], visible: boolean, mapIndex?: string): void;
    /**
     * Geeft het webservice‑type van een laag terug.
     *
     * Het type wordt bepaald aan de hand van de configuratie
     * van de webservice waarin de laag is gedefinieerd.
     */
    getTypeOfLayer(layerId: string, mapIndex: string): Webservice2DType | undefined;
    /**
     * Haalt de configuratie van een laag op.
     *
     * De configuratie bevat metadata zoals:
     * - titel
     * - legendainformatie
     * - resolutie‑instellingen
     */
    getLayerConfig(layerId: string, mapIndex: string): AbstractConfigurableLayerOptions | undefined;
    /**
     * Initialiseert lagen van één webservice en voegt deze toe aan de kaart
     */
    private loadWebservice;
    private removeCurrentLayers;
    /**
     * Emit een event dat aangeeft dat een legenda is toegevoegd.
     */
    private emitLegendAddedEvent;
    /**
     * Bouwt een legenda‑object op basis van de actuele laagstatus.
     *
     * Het resultaat combineert configuratie‑informatie
     * met runtime‑status (enabled / zichtbaar).
     */
    private buildLayerLegend;
    /**
     * Geeft de titel terug van de webservice waartoe een laag behoort.
     */
    private getServiceTitleOfLayer;
    /**
     * Emit een event dat aangeeft dat een legenda is verwijderd.
     */
    private emitLegendRemovedEvent;
    /**
     * Voegt een laag toe op basis van de kaartconfiguratie.
     *
     * Wordt gebruikt bij:
     * - togglen van zichtbaarheid
     * - batch‑operaties
     */
    private addLayerFromMapConfig;
    /**
     * Emit een layer changed event
     * en synchroniseert legenda‑events.
     */
    private emitLayerChanged;
    private addLayerComponentToMapLayerComponents;
    /**
     * Bouwt een unieke key voor het opslaan van layer componenten
     * op basis van mapIndex en layerId.
     */
    private buildLayerComponentKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<GgcLayerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GgcLayerService>;
}

export { ATTRIBUTION_OPTIONS, CoordinateFormatPipe, DrawInteractionEvent, DrawInteractionEventTypes, FeatureCollectionForCoordinate, FeatureCollectionForLayer, FormatType, GgcCapabilitiesService, GgcCrsConfigService, GgcDrawService, GgcGeojsonLayerComponent, GgcImageLayerComponent, GgcLayerBrtAchtergrondkaartComponent, GgcLayerService, GgcLoaderComponent, GgcMapComponent, GgcMapDetailsContainerComponent, GgcMapEventsService, GgcMapService, GgcMousePositionComponent, GgcScaleDenominatorComponent, GgcScaleLineComponent, GgcSelectionService, GgcSnapService, GgcVectorTileLayerComponent, GgcWmsLayerComponent, GgcWmtsLayerComponent, GgcZoomLevelComponent, MapComponentEvent, MapComponentEventTypes, MapViewState, ModifyInteractionEvent, ModifyInteractionEventTypes, ROTATE_OPTIONS, SelectionModeTypes, ZOOM_OPTIONS, declusterFeatures, drawTypeToGeometryType, epsg28992, extent, featureCollectionForLayerHasCluster, fromGeoJSONFeature, fromGeoJSONFeatures, matrixIds, matrixSizes, resolutionToZoomlevel, resolutions, scaleToResolution, toGeoJSONFeature, zoomlevelToResolution };
export type { AbstractBaseLayerOptions, AbstractClickableLayerOptions, AbstractConfigurableLayerOptions, CapabilitiesServiceLayer, CapabilitiesServiceLayerStyle, CrsConfig, DrawOptions, GeojsonLayerOptions, ImageLayerOptions, SelectOptions, ServiceCapabilities, SnapOptions, StyleLikeMap, ValidationFunction, VectorTileLayerOptions, Webservice, WmsLayerOptions, WmtsLayerOptions, ZoomOptions };
